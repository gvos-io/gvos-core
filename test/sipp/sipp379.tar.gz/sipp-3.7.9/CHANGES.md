# Changelog

All notable changes to SIPp are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Changes that may break existing scenarios, command lines or builds are
marked **Breaking**.

## [3.7.9] - 2026-09-30

### Fixed

- Attribute values are XML-decoded once again, as before 3.7.8, so
  `&amp;lt;` gives `&lt;` (#1062, #1098, by Orgad Shaneh)
- A memory leak in every MD5 digest, since 3.7.8 (#884, by Orgad Shaneh)
- AKAv1-MD5 with wolfSSL lost the last byte of a padded nonce, since
  3.7.8 (#1014, by Orgad Shaneh)
- Configuring without GTest failed, since 3.7.8 (#891, by Orgad Shaneh)
- CMake takes any boolean for `USE_SYSTEM_PUGIXML` and
  `USE_SYSTEM_GTEST`, such as the Fedora package's `1` (#1060, by Peter
  Lemenkov)
- Building with GCC 16: the bundled pugixml is updated to 1.16 (#1047,
  by Orgad Shaneh)

## [3.7.8] - 2026-09-23

### Added

- `-cid_type` selects a built-in Call-ID generator: `uuid`,
  `uuid-compact`, `random` or `timestamp`. The default keeps using
  `-cid_str` (#869, by Darwvin)
- An interactive wizard that builds a command line when SIPp is started
  without arguments on a terminal (#868, by Darwvin)
- `sipp-multi.py`, a helper that starts and supervises several SIPp
  instances described in a CSV file (#873, by Darwvin)
- CMake `USE_SYSTEM_GTEST` builds the unit tests against a system-wide
  GTest (#836, by Peter Lemenkov)
- clang-format configuration and CONTRIBUTING.md (#855, by Peter Lemenkov)

### Changed

- **Breaking:** The scenario XML parser is now pugixml. It is bundled as
  a git submodule (clone with `--recursive`), or taken from the system
  with `-DUSE_SYSTEM_PUGIXML=ON`. Scenario files are no longer limited
  to 64 KB (#858, by Peter Lemenkov)
- Timing uses `std::chrono` (#854, by Peter Lemenkov)

### Removed

- **Breaking:** SIPp's bundled MD5, AKA and base64 code. Building now
  requires OpenSSL (1.1.1 or later) or wolfSSL (#827, #828, #842, by
  Peter Lemenkov)
- The `-c` compression plugin option, for which no plugin was ever
  distributed (#853, by Peter Lemenkov)

### Fixed

- Every call with `-t t1`, `tn`, `l1` or `ln` failed with "Unable to bind
  TCP socket": the 3.7.0 `[local_port]` fix for TCP and TLS is reverted
  (#830, by Orgad Shaneh)
- The BYE of an aborted call follows the dialog's route set (#851, by
  Daniel Donoghue)
- SDP is found in multipart/mixed message bodies (#862, by Mark T)
- Heap-use-after-free when a UDP retransmission fails to send (#876, by
  Orgad Shaneh)
- `get_header()` writes are bounded by its buffer (#881, by Peter Lemenkov)
- Use-after-free and no-op bugs when clearing maps (#839, by Peter Lemenkov)
- Data race in the debug files (#859, by Peter Lemenkov)
- RTP debug dumps of several sessions (#848, by Orgad Shaneh)
- An infinite loop in the build with the bundled gtest (#845, by Orgad
  Shaneh)

## [3.7.7] - 2025-12-30

### Fixed

- Const-correctness of an argument that is modified (#826, by Peter
  Lemenkov)

## [3.7.6] - 2025-12-22

### Added

- `%r` in `-cid_str` inserts a random number, for unique Call-IDs when
  several instances run in parallel (#810, by Maksim Nesterov)
- The `sipp` executable exports its symbols, so that plugins can use
  them (#820, by Orgad Shaneh)

### Changed

- **Breaking:** Building requires a C++17 compiler (by Orgad Shaneh)
- Bundled gtest updated to 1.17 (by Orgad Shaneh)

### Fixed

- SRTP: a buffer overrun and a missing null termination when parsing
  received crypto lines, and mis-parsing of a long input line (#822, by
  Orgad Shaneh)
- The `-trace_logs` file name (by Orgad Shaneh)

## [3.7.5] - 2025-08-19

### Added

- Enable a mixture of server-mode and client-mode operation simultaneously (by Matthew Briggs)
- Support for regexp matching on response codes (by Petr Cisar)
- Support RFC3339 timestamp format and timezone offset (by Costis)
- Send the SNI in the TLS client hello (#754, by Jean-Christophe Grondin)
- Replay raw IP pcap files (#763, by Jérôme Poulin)
- Seed the random generator with the host name and PID too, so that
  instances started together differ (#738, by FalacerSelene)
- A Debian-based Dockerfile (#759, by Orgad Shaneh)

### Fixed

- Out-of-bounds read on invalid XML (#747, by Orgad Shaneh)
- `<nop>` overrides the last action result only if it is a failure
  (#766, by Tolga)
- Fix RTPCHECK functionality regressions (by Jeannot Langlois)
- Fix SRTPCheck testing on unlimited number of calls (by Michal Hajek)
- Use random SSRC for SRTP instead of hardcoded value (by Orgad Shaneh)
- Fix RTPStream crash on thread exit and reduce mutex scope (by Orgad Shaneh)
- Fix memory leaks and file handle leaks (by Orgad Shaneh)
- Fix CSV reports to use fixed precision for floats (by Costis)
- Fix quit behavior to properly terminate (by Orgad Shaneh)
- Mark aborted calls as failed (by Orgad Shaneh)
- Various stability and build fixes (by Orgad Shaneh, Jaco Kroon, Michal Hajek)

## [3.7.4] - 2024-09-10

### Fixed

- Build with wolfSSL (by Orgad Shaneh)
- Docker: update Alpine to 3.20 and fix the version resolving (#749, by
  Orgad Shaneh)

## [3.7.3] - 2024-08-07

### Added

- SHA-256 Digest authentication (RFC 8760) (#676, by Marat Gareev)
- TLS 1.3 (#695, by Orgad Shaneh)
- `-bind_to_device` option (#630, by Ivan Gankevich)
- Comfort noise (audio/CN) media support (#687, by Rafael Vargas)
- TLS verification without a CRL file (#663, by Ivan Ribakov)
- Random SSRC for RTP streams (#599, by Stefan Mititelu)
- `hide` and `display` attributes (#718, by Michael Stovenour)
- A define to use local IP hints (#598, by Stefan Mititelu)
- pcap file paths that start with `~` (#607, by Rajesh Singh)

### Changed

- Bundled gtest updated to 1.14.0; building requires C++14 and CMake 3.5
  (#649, #651, by Orgad Shaneh)

### Removed

- **Breaking:** Remove support for variables in PCAP filenames, originally introduced in 3.7.0. See #673

### Fixed

- Recovered `-mp` and `[auto_media_port]` to maintain backwards compatibility (by Orgad Shaneh)
- Fix crash when using PCAP play with more than one call (by Pete O'Neill)
- Fix pager on macOS by trying less and more too (by Walter Doekes)
- `[next_url]` could return garbage (#724, by Michael Stovenour)
- rtp_stream failed to bind on macOS, and CRLF in injection files (#729,
  by Zac He)
- rtpstream local port allocation (#734, by viktike), and the next RTP
  port was always reset to the minimum (#635, by Stefan Mititelu)
- The RTP playback thread blocked on `select()` (#690, by Shona McNeill)

## [3.7.2] - 2023-11-16

### Fixed

- Remove excessive log

## [3.7.1] - 2023-05-19

### Fixed

- Correctly open the control socket
- The SIPp binary can now be built even when the `gtest` checkout is missing
- rtpstream files are now also found next to the scenario. If it is not found there, it will be treated as a relative path as usual.

## [3.7.0] - 2023-04-02

### Added

- RTPstream can now handle .wav files with a WAV header (by Orgad Shaneh)

### Fixed

- RTPCHECK stability fixes (by Jeannot Langlois)
- Support CRLF-format injection files (by Orgad Shaneh)
- Fix to [next_url] when a display name is present in the contact (by enneig)
- Add 'transport' to the Contact header for UAC scenarios (by Martin Flaska)
- Update built-in scenarios to Copy Record-Route from INVITE to 200OK to comply with RFC 3261 (by kadabusha)
- Fix for local_port keyword using TCP or TLS (by Felippe Silvestre)
- Correct handling of IMS-AKA RES values containing null bytes (by Sergey Zyrianov)
- Fix potential overwrite of auth value when calculating auth (by ZhaohuiLiu)
- Diagnostics improvements:
  - Print, rather than lose, any buffered response time data on exit (by Orgad Shaneh)
  - Add the IPs and remote address family to 'Network family mismatch' log  (by Rob Day)
  - Print OpenSSL error reason when certificate load fails (by Rajesh Singh)
  - Give clear error if multiple command-line parameters are being interpreted as remote_host
- Prevent clock_tick moving backwards (and getting behind wheel_base and causing an assert) (by Rob Day)
- Ensure that sockets are marked as non-blocking before OpenSSL calls are made (by Rob Day)
- Prevent RTPStream crash due to a thread ID of 0 (by Rob Day)
- Cygwin, FreeBSD and Hurd build fixes (by Orgad Shaneh, kadabusha and Zopolis4)
- Static build fixes (by  Aaron Meriwether)

## [3.7.0-rc1] - 2021-10-26

### Added

- B2BUA Media Gateway RTP/SRTP bit pattern testing -- see
  `docs/rtpcheck_xml_syntax_reference.pdf`. Command line examples:
    ```
    # UAS (RTP)
    ./sipp -m 1 -sf sipp_scenarios/pfca_uas.xml \
      -i 127.0.0.3 -t u1 -p 5060 -rtp_echo

    # UAC (RTP)
    ./sipp -m 1 -sf sipp_scenarios/pfca_uac_apattern.xml \
      -t u1 -i 127.0.0.2 -p 5060 127.0.0.3:5060
    ```
    ```
    # UAS (audio SRTP)
    ./sipp -m 1 -sf sipp_scenarios/pfca_uas_audio_crypto_simple.xml \
      -t u1 -i 127.0.0.3 -p 5060 -srtpcheck_debug

    # UAC (audio SRTP)
    ./sipp -m 1 -sf sipp_scenarios/pfca_uac_apattern_crypto_simple.xml \
      -t u1 -i 127.0.0.2 -p 5060 -rtpcheck_debug -srtpcheck_debug \
      127.0.0.3:5060
    ```
  By Jeannot Langlois.
- URL encode/decode `<action>` for scenarios (by Jérôme Poulin).
- Variables in the rtpstream/pcap filenames (by Orgad Shaneh).
- WolfSSL/WolfCrypt library support (as alternative to OpenSSL, by
  Thomas Uhle).

### Removed

- Removed `-mp` in favor of `-min_rtp_port` and `-max_rtp_port`. Also
  removed `[auto_media_port]`. There are way too many (conflicting)
  options to specify ports here.

### Fixed

- Documentation updates. Code cleanups. Build fixes. (By Walter Doekes,
  Thomas Uhle, ChanderG, Lin Sun, Markus Goetzl, Rob Day, Stefan
  Mititelu, Orgad Shaneh, Karn Saheb).
- Fix socket/tcp refcount/order issue (by Orgad Shaneh).
- Fix timezone in [date] on FreeBSD (by kadabusha).
- Track auto-answered messages as a visible counter rather than an error
  log (by Rob Day).
- Unconditionally show index in scenario screen (by Rob Day).

## [3.6.2-rc1] - 2021-10-25

### Removed

- Remove RTP\_STREAM define. The code is always included. (By Orgad Shaneh.)

### Fixed

- Fix crash when abusing authentication method (#503, by Markus).
- Fix crash when trying to change an unset ooc scenario (#463, by
  @jquinn60137).
- Fix various build issues with CMake and/or missing version.h and/or
  compiler warnings. By Walter Doekes, by Silver Chan, Thomas Uhle,
  Orgad Shaneh.
- Various minor documentation fixes. By Walter Doekes, kadabusha, Thomas
  Uhle, Alexander Traud.

## [3.6.1] - 2020-09-16

### Changed

- **Breaking:** CMake is now used as build environment: autoconf and friends are gone
  (#430, by Rob Day (@rkday)). See `build.sh` for CMake invocations.
  For a full build, do:
    ```
    cmake . -DUSE_GSL=1 -DUSE_PCAP=1 -DUSE_SSL=1 -DUSE_SCTP=1
    make -j4
    ```
- Make it easier to deal with large SIP packets by adding an optional
  `-DSIPP_MAX_MSG_SIZE=262144` to the `cmake` command (#422, by Cody Herzog
  (@codyherzog)).

### Fixed

- Consistently unescape XML attributes when loading scenario (#458, by
  Steve Frécinaux (@nud)).
- Fix buffer overflow in screen output (#479, reported by @brettowe).
- Fix nonce count in auth headers (#421, by Cody Herzog (@codyherzog)).
- Fix parser warning when trying to access 0-byte SDP body (by Lin Sun
  (@sunlin7)).
- Fix pcapplay on FreeBSD (#434, by Rob Day (@rkday)).
- Improve build validation (#424, by Stanislav Litvinenko (@dolk13)), a
  few compiler fixes, a few ncurses fixes (including #436, reported by
  @TamerL), build cleanup after CMake (#443, #442, by Orgad Shaneh
  (@orgads)) and libtinfo linker issues (Jeannot Langlois
  (@jeannotlanglois)).
- Improve provided sipp.dtd file (#425, by David M. Lee (@leedm777)),
  and XML fixes by Rob Day.

## [3.6.0] - 2019-06-18

### Added

- Add `play_dtmf` code originally from
  https://sourceforge.net/p/sipp/patches/50/ (Dmitry Kunilov), then
  pull #82 (@horacimacias) and then #141 (@vodik). Compile with
  pcap-play support, and use it by adding `<exec play_dtmf="1234*#"/>`
  similar to how you use `play_pcap_audio`.
  - Add RTP payload 96 in your SDP:
    m=audio [media_port] RTP/AVP 0 96 97
    a=rtpmap:0 PCMU/8000
    a=rtpmap:96 telephone-event/8000
    a=fmtp:96 0-15
    a=rtpmap:97 no-op/8000
  - Exec syntax is `<exec play_dtmf="digits[,length]"/>` where digits
    can be one or more of "0123456789#*ABCD" and length defaults to 200
    and must be between 50 and 2000.
  - Instead of digits a `[field...]` keyword is also accepted.
  - Make sure you add enough `<pause/>` after `play_dtmf`.
- Add `rtp_echo` action (pull #259 by Snom Technology). Compile with
  `--with-rtpstream` and use it by adding `<rtp_echo value="0">` to stop
  the RTP echo enabled via `-rtp_echo`. RTP echo can be restarted via
  `<rtp_echo value="1">` action. Usage example in `regress/github-#0259/uas.xml`
- Added the required constants for G722 (payload 9) and iLBC at 30ms per frame
  to rtp\_stream media actions. (PR #366, by Jasper Hafkenscheid @hafkensite.)
- Add quick and dirty detection of invalid XML (issue #322).
- Added PAGER by default to the extremely large sipp help output.

### Changed

- **Breaking:** Automatic filenames (trace files, error files, etc..) are now created in
  the current working directory instead of in the directory of the scenario
  file. (Issue #399, reported by @sergey-safarov.)
- **Breaking:** Only validates SSL certificate if CA-file is separately specified!
  (PR #335, by Patrick Wildt @bluerise.)
- **Breaking:** Angle brackets `<` and `>` need to be escaped inside XML attributes.
  See #414. So, not `regexp="<(sip:.*)>"` but `regexp="&lt;(sip:.*)&gt;"`.
- Clarify that `-infindex` should takes a basename only (issue #395, reported
  by @sergey-safarov).

### Removed

- Removed unused RTPStream code concerning video streams. Also
  consolidated the rtpstream audio port usage to reuse the global
  `[media_port]` instead of the `[rtpstream_audio_port]`.
  Also the `-min_rtp_port` and `-max_rtp_port` options have been
  removed. Advantages: cleaner code, fewer scenario variables.
  Drawbacks: possible ICMP port unreachable messages for RCTP and video.
  Also, no easy way to discern different streams if you want to bombard
  a single UAS with multiple RTP streams. (Issue #192, reported by
  @atsakiridis.)

### Fixed

- Fix `[routes]` header in UAS scenario's. (Issue #262, reported by
  Stefan Mititelu (@smititelu).)
- last\_Keyword does not search in SIP body anymore (#207, reported by Zoltan).

## [3.5.3] - 2019-06-18

### Fixed

- Fix `[routes]` header in UAS scenario's. (Issue #262, reported by
  Stefan Mititelu (@smititelu).)
  (Backported from b6c7b209 from 3.6.)
- Fix bad Content-Length calculation when whitespace was between the CRLF
  pairs that separate the body. (Issue #337, fixed by Serg Stetsuk
  (@sergstetsuk)).
- Fix crash in pcap play on send failure because of pthread\_cleanup macros.
  (Issue #74, #370, reported by various people.)

## [3.5.2] - 2018-07-13

### Changed

- Document `search_in="hdr"` test.
- Also test without `HAVE_EPOLL`.

### Fixed

- Build issues:
  - Improve ncurses/gsl detection and linkage on various platforms.
    (Issue #205, #271, #275, reported by Paul Malpass, AlexB, Leon Roy,
    Victor Seva.)
  - Fix compile issues on old CentOS and Solaris. (Issue #211, #245, #252,
    reported by sjthomason, mscdex.)
  - Fix newer openssl detection. (Issue #302, #304, #315, #328.)
  - Recompile entire source after a reconfigure.
  - Reduce confusion when someone downloads a tag from git instead of the tar.gz
    with the autogenerated files and valid version.h (#270, reported by AlexB).
  - Remove hardcoded build datetime from binary, for "reproducible builds".
    (#286, by Victor Seva.)
  - Replace underscore in tag-name with tilde, for debian-style "~rc1" version
    suffix.
- Handle Contact header with extra angle brackets ('<...>') outside of the
  uri-parameters (in the contact-params). The contact params should not be
  used in the `next_url`. (Issue #234, reported by Justin Zimmer.)
- Fix TLS issues for during high load. (Issue #241, #243, reported by sgel83,
  and fixes by Rob Day.)
- Fix problem with `get_inet_address` on FreeBSD (#331, reported by tsgan.)
- Retry video RTP bind if port is taken (#276, thanks Corey Farrell).

## [3.5.1] - 2016-03-17

### Fixed

- Fix qop-value in authorization Digest. It can only hold a single value
  (auth, auth-int, ...) and does not take double quotes, in contrast to
  the challenge. Some servers returned a 400 upon receiving this.
  (Issue #191, reported by @artlov.)
- Fix compile error on Cygwin. (Issue #193, reported by @Gankarloo.)

## [3.5.0] - 2016-02-08

### Added

- Clean up source code, fix typo's, alter warning and error messages,
  fix pedantic coding style. Add gtest framework and tests. Add regression
  tests. Fix and improve build scripts (see also: `build.sh`).
- Use better timing with `clock_gettime` (or `clock_get_time` on OSX).
- Don't complain about the dummy variable `_` being used only once.
- Ignore 4x NUL keepalive (next to ignoring the CRLF CRLF keepalive).
- Add `[date]` keyword.
- Add `-trace_screen` option to log screen output in a file.
- Add `-rate_increase` option to increase load periodically.
- Add `-callid_slash_ign` to disable the magic triple slash behaviour.a
- Alter `-aa` to also reply to OPTIONS.
- Allow replaying pcaps with `LINUX_SLL`, `EN10MB` and 802.11 (and ratiotap)
  link layer types. Handle 802.1Q tagged frames.
- Allow starting SIPp without a TERM setting (a "working" terminal).
- Allow m=image in SDP to pcapplay faxes/images.
- `<exec play_pcap_audio="..."/>` and friends:
  - If the argument is not an absolute path, the pcap is searched next
    to the scenario, before falling back to checking the current
    working directory.
  - The argument may be enclosed in brackets, in which case it is
    interpreted as a keyword value; set through the `-key` command line
    option. Example: `<exec play_pcap_audio="[file1]"/>` with option
    `-key file1 /path/to/pcap`.

### Fixed

- Start SDP search in body instead of in header. Fix IPv6 media address in SDP.
- Allow single CR and single LF in SDP.
- Don't confuse cnonce with nonce, improve other auth parsing.
- Don't abort SIPp if the To header is missing.
- Fixes to XML parser; improve `get_peer_tag` behaviour.
- Fix jump recursion crashes.
- Fix a few (potential) memory leaks and dangerous code.
- Remove a few autogenerated files from tree (configure, manpage).
- Fix digest calculation when `qop` is given.

## [3.4.1] - 2014-03-09

Not documented here.

[3.7.9]: https://github.com/SIPp/sipp/releases/tag/v3.7.9
[3.7.8]: https://github.com/SIPp/sipp/releases/tag/v3.7.8
[3.7.7]: https://github.com/SIPp/sipp/releases/tag/v3.7.7
[3.7.6]: https://github.com/SIPp/sipp/releases/tag/v3.7.6
[3.7.5]: https://github.com/SIPp/sipp/releases/tag/v3.7.5
[3.7.4]: https://github.com/SIPp/sipp/releases/tag/v3.7.4
[3.7.3]: https://github.com/SIPp/sipp/releases/tag/v3.7.3
[3.7.2]: https://github.com/SIPp/sipp/releases/tag/v3.7.2
[3.7.1]: https://github.com/SIPp/sipp/releases/tag/v3.7.1
[3.7.0]: https://github.com/SIPp/sipp/releases/tag/v3.7.0
[3.7.0-rc1]: https://github.com/SIPp/sipp/releases/tag/v3.7.0_rc1
[3.6.2-rc1]: https://github.com/SIPp/sipp/releases/tag/v3.6.2_rc1
[3.6.1]: https://github.com/SIPp/sipp/releases/tag/v3.6.1
[3.6.0]: https://github.com/SIPp/sipp/releases/tag/v3.6.0
[3.5.3]: https://github.com/SIPp/sipp/releases/tag/v3.5.3
[3.5.2]: https://github.com/SIPp/sipp/releases/tag/v3.5.2
[3.5.1]: https://github.com/SIPp/sipp/releases/tag/v3.5.1
[3.5.0]: https://github.com/SIPp/sipp/releases/tag/v3.5.0
[3.4.1]: https://github.com/SIPp/sipp/releases/tag/v3.4.1
