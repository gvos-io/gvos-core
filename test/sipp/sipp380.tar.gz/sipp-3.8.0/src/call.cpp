/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Author : Richard GAYRAUD - 04 Nov 2003
 *           Olivier Jacques
 *           From Hewlett Packard Company.
 *           Shriram Natarajan
 *           Peter Higginson
 *           Eric Miller
 *           Venkatesh
 *           Enrico Hartung
 *           Nasir Khan
 *           Lee Ballard
 *           Guillaume Teissier from FTR&D
 *           Wolfgang Beck
 *           Venkatesh
 *           Vlad Troyanker
 *           Charles P Wright from IBM Research
 *           Amit On from Followap
 *           Jan Andres from Freenet
 *           Ben Evans from Open Cloud
 *           Marc Van Diest from Belgacom
 *           Michael Dwyer from Cibation
 *           Roland Meub
 *           Andy Aicken
 *           Martin H. VanLeeuwen
 */

#include <algorithm>
#include <charconv>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <assert.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/wait.h>

#ifdef PCAPPLAY
#include "send_packets.h"
#endif

#include "sipp.hpp"
#include "auth.hpp"
#include "urlcoder.hpp"
#include "deadcall.hpp"
#include "luascript.hpp"
#include "config.h"
#include "version.h"

template<typename Out>
void split(const std::string &s, char delim, Out result) {
    std::stringstream ss;
    ss.str(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        *(result++) = item;
    }
}

std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> elems;
    split(s, delim, std::back_inserter(elems));
    return elems;
}

std::string join(const std::vector<std::string> &s, std::string_view delim) {
    std::ostringstream imploded;
    for (auto it = s.begin(); it != s.end(); ++it) {
        if (it != s.begin()) {
            imploded << delim;
        }
        imploded << *it;
    }
    return imploded.str();
}

std::string_view trim(std::string_view s) {
    size_t first = s.find_first_not_of(' ');
    if (first == std::string::npos) {
        return s;
    }
    size_t last = s.find_last_not_of(' ');
    return s.substr(first, (last - first + 1));
}

#define callDebug(...) do { if (useCallDebugf) { _callDebug( __VA_ARGS__ ); } } while (0)

extern  std::map<std::string, SIPpSocket *>     map_perip_fd;

/* The <exec verify> commands running, by pid: the call that waits for
 * each, nullptr once that call is gone, and the command for the logs */
struct verify_command {
    call *waiting;
    std::string command;
};
static std::map<pid_t, verify_command> verify_commands;

int call::dynamicId       = 0;
int call::maxDynamicId    = 10000+2000*4;      // FIXME both param to be in command line !!!!
int call::startDynamicId  = 10000;             // FIXME both param to be in command line !!!!
int call::stepDynamicId   = 4;                // FIXME both param to be in command line !!!!

/* What peekCold() reads in a call that has no cold state */
const call::call_cold call::no_cold_state;

/************** Call map and management routines **************/
static const int SM_UNUSED = -1;

static unsigned int next_number = 1;

/* The calls whose scenario has a <recv request> of a dialog that may be
 * new, in the order they came */
static std::list<call *> new_dialog_calls;

/* out += std::to_string(n), without the temporary string */
template <typename T> static void append_number(std::string &out, T n)
{
    static_assert(std::is_integral_v<T>);
    char buf[24];
    out.append(buf, std::to_chars(buf, buf + sizeof(buf), n).ptr - buf);
}

class CallIdBuilder {
public:
    explicit CallIdBuilder(unsigned int call_number)
        : call_number(call_number)
    {
    }

    void build(char *call_id)
    {
        switch (call_id_mode) {
        case CID_MODE_UUID:
            build_uuid(false);
            break;
        case CID_MODE_UUID_COMPACT:
            build_uuid(true);
            break;
        case CID_MODE_RANDOM:
            build_random();
            break;
        case CID_MODE_TIMESTAMP:
            build_timestamp();
            break;
        case CID_MODE_FORMAT:
        default:
            build_format();
            break;
        }

        copy_to(call_id);
    }

private:
    void build_format()
    {
        const char *src = call_id_string;

        while (*src) {
            if (*src != '%') {
                output += *src++;
                continue;
            }

            ++src;
            if (*src == '\0') {
                output += '%';
                break;
            }

            switch (*src) {
            case 'u':
                append_number(output, call_number);
                break;
            case 'p':
                append_number(output, pid);
                break;
            case 's':
                output += local_ip;
                break;
            case 'r':
                append_number(output, rand());
                break;
            case '%':
                output += '%';
                break;
            default:
                /* Not a conversion: keep it as it is. */
                output += '%';
                output += *src;
                break;
            }
            ++src;
        }
    }

    void build_uuid(bool compact)
    {
        unsigned char bytes[16];

        fill_bytes(bytes, sizeof(bytes));
        bytes[6] = static_cast<unsigned char>((bytes[6] & 0x0f) | 0x40);
        bytes[8] = static_cast<unsigned char>((bytes[8] & 0x3f) | 0x80);

        append_hex_bytes(bytes, 4);
        if (!compact) {
            output += '-';
        }
        append_hex_bytes(bytes + 4, 2);
        if (!compact) {
            output += '-';
        }
        append_hex_bytes(bytes + 6, 2);
        if (!compact) {
            output += '-';
        }
        append_hex_bytes(bytes + 8, 2);
        if (!compact) {
            output += '-';
        }
        append_hex_bytes(bytes + 10, 6);
        output += '@';
        output += local_ip;
    }

    void build_random()
    {
        unsigned char bytes[16];

        fill_bytes(bytes, sizeof(bytes));
        append_number(output, call_number);
        output += '-';
        append_hex_bytes(bytes, sizeof(bytes));
        output += '@';
        output += local_ip;
    }

    void build_timestamp()
    {
        append_number(output, timestamp_micros());
        output += '-';
        append_number(output, call_number);
        output += '-';
        append_number(output, pid);
        output += '@';
        output += local_ip;
    }

    void fill_bytes(unsigned char *bytes, size_t size) const
    {
        uint64_t seed = timestamp_micros();

        seed ^= static_cast<uint64_t>(call_number) << 32;
        seed ^= static_cast<uint64_t>(pid) << 8;

        for (size_t i = 0; i < size; ++i) {
            seed ^= static_cast<uint64_t>(rand()) << ((i % 4) * 8);
            seed = seed * 2862933555777941757ULL + 3037000493ULL + i;
            bytes[i] = static_cast<unsigned char>((seed >> ((i % 8) * 8)) & 0xff);
        }
    }

    void append_hex_bytes(const unsigned char *bytes, size_t size)
    {
        static const char hex[] = "0123456789abcdef";

        for (size_t i = 0; i < size; ++i) {
            output += hex[bytes[i] >> 4];
            output += hex[bytes[i] & 0x0f];
        }
    }

    static uint64_t timestamp_micros()
    {
        using clock = std::chrono::system_clock;
        return static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::microseconds>(
                clock::now().time_since_epoch()).count());
    }

    void copy_to(char *call_id) const
    {
        size_t length = std::min(output.size(), static_cast<size_t>(MAX_HEADER_LEN - 1));
        memcpy(call_id, output.data(), length);
        call_id[length] = '\0';
    }

    unsigned int call_number;
    std::string output;
};

static void build_call_id(char *call_id, unsigned int call_number)
{
    CallIdBuilder(call_number).build(call_id);
}

static unsigned int get_tdm_map_number()
{
    unsigned int nb = 0;
    unsigned int i=0;
    unsigned int interval=0;
    unsigned int random=0;
    bool found = false;

    /* Find a number in the tdm_map which is not in use */
    interval = (tdm_map_a+1) * (tdm_map_b+1) * (tdm_map_c+1);
    random = rand() % interval;
    while ((i<interval) && (!found)) {
        if (tdm_map[(random + i) % interval] == false) {
            nb = (random + i) % interval;
            found = true;
        }
        i++;
    }

    if (!found) {
        return 0;
    } else {
        return nb+1;
    }
}

/* When should this call wake up? */
unsigned int call::wake()
{
    unsigned int wake = 0;

    if (zombie) {
        return wake;
    }

    if (paused_until) {
        wake = paused_until;
    }

    if (next_retrans && (!wake || (next_retrans < wake))) {
        wake = next_retrans;
    }

    if (recv_timeout && (!wake || (recv_timeout < wake))) {
        wake = recv_timeout;
    }

    if (rtpstream_wait_check && (!wake || (rtpstream_wait_check < wake))) {
        wake = rtpstream_wait_check;
    }

    return wake;
}

/* Is the media type of a Content-Type application/sdp? Its case does not
 * matter, nor its blanks, and parameters (";charset=utf-8") may follow. */
static bool is_sdp_content_type(std::string_view ct)
{
    const char *sdp = "application/sdp";

    for (const char c : ct) {
        if (c == ';') {
            break;
        }
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
            continue;
        }
        if (!*sdp || tolower((unsigned char)c) != *sdp) {
            return false;
        }
        sdp++;
    }
    return !*sdp;
}

static std::string find_in_sdp(std::string_view pattern, std::string_view msg)
{
    std::string_view::size_type begin, end;

    begin = msg.find(pattern);
    if (begin == std::string_view::npos) {
        return "";
    }

    begin += pattern.size();
    /* A port count ("m=audio 30000/2") or a TTL ("c=IN IP4 224.2.1.1/127")
     * follows a slash. */
    end = msg.find_first_of(" /\r\n", begin);
    if (end == std::string_view::npos || begin == end) {
        return "";
    }

    return std::string(msg.substr(begin, end - begin));
}

/* The address of the c= line of a part of an SDP, "" if it has none; ipv6
 * tells whether it is an IPv6 one. */
static std::string sdp_connection(std::string_view part, bool &ipv6)
{
    std::string host = find_in_sdp("c=IN IP4 ", part);
    ipv6 = host.empty();
    if (ipv6) {
        host = find_in_sdp("c=IN IP6 ", part);
    }
    return host;
}

/* The media section of an SDP from its m= line at pos to the next one */
static std::string_view sdp_media_section(std::string_view sdp, size_t pos)
{
    const size_t end = sdp.find("\nm=", pos + 1);
    return sdp.substr(pos, end == std::string_view::npos ? end : end - pos);
}

/* The connection address of a media section of an SDP: that of its own c=
 * line, else that of the session part before the first m= line (RFC 4566
 * 5.7). */
static std::string sdp_media_connection(std::string_view sdp, std::string_view section, bool &ipv6)
{
    std::string host = sdp_connection(section, ipv6);
    if (host.empty()) {
        host = sdp_connection(sdp.substr(0, sdp.find("\nm=")), ipv6);
    }
    return host;
}

#ifdef PCAPPLAY
/* A stream's own, made on its first use: most calls have only audio */
play_args_t& call::playArgs(rtpstream_pcap_t stream)
{
    std::unique_ptr<play_args_t>& args = pcap_play_args[stream];
    if (!args) {
        args.reset(new play_args_t());
        if (stream == RTPSTREAM_PCAP_AUDIO) {
            args->last_seq_no = 1200;
        } else if (stream == RTPSTREAM_PCAP_VIDEO) {
            args->last_seq_no = 2400;
        }
    }
    return *args;
}

void call::get_remote_media_addr(std::string const &msg)
{
    if (find_in_sdp(media_ip_is_ipv6 ? "c=IN IP6 " : "c=IN IP4 ", msg).empty()) {
        return;
    }

    hasMediaInformation = 1;
    /* where pcap plays go: none to keep without them */
    if (!pcap_plays) {
        return;
    }
    const int family = media_ip_is_ipv6 ? AF_INET6 : AF_INET;

    static const struct {
        const char* prefix;
        rtpstream_pcap_t stream;
    } media[] = {
        {"\nm=audio ", RTPSTREAM_PCAP_AUDIO},
        {"\nm=image ", RTPSTREAM_PCAP_IMAGE},
        {"\nm=video ", RTPSTREAM_PCAP_VIDEO},
        {"\nm=text ", RTPSTREAM_PCAP_TEXT},
    };
    for (const auto& m : media) {
        /* If the first m-line of the kind has port ZERO (a stream
         * refused, RFC 3264 6), use the second one, as rtp_stream does. */
        std::string port;
        std::string_view section;
        size_t pos = msg.find(m.prefix);
        for (int i = 0; i < 2 && pos != std::string::npos; i++) {
            section = sdp_media_section(msg, pos);
            port = find_in_sdp(m.prefix + 1, section);
            if (port != "0") {
                break;
            }
            pos = msg.find(m.prefix, pos + 1);
        }
        if (port.empty() || port == "0") {
            continue;
        }
        bool ipv6;
        const std::string host = sdp_media_connection(msg, section, ipv6);
        /* none to play to on an address of the other IP version */
        if (host.empty() || ipv6 != media_ip_is_ipv6) {
            continue;
        }
        gai_getsockaddr(&playArgs(m.stream).to, host.c_str(), port.c_str(),
                        AI_NUMERICHOST | AI_NUMERICSERV, family);
        rtpstream_update_pcap(&rtpstream_callinfo, m.stream, &playArgs(m.stream));
    }
}
#endif

/******* Extract RTP remote media infomartion from SDP  *******/
/***** Similar to the routines used by the PCAP play code *****/

#define SDP_AUDIOPORT_PREFIX "\nm=audio"
#define SDP_VIDEOPORT_PREFIX "\nm=video"

/* Port of the first media line with the given prefix at or after pos, or 0,
 * and its media section. Leaves pos after that port, so that the next call
 * finds the next line. */
static int sdp_media_port(std::string_view sdp, std::string_view prefix, size_t &pos,
                          std::string_view &section)
{
    pos = sdp.find(prefix, pos);
    if (pos == std::string_view::npos) {
        return 0;
    }
    section = sdp_media_section(sdp, pos);
    pos += prefix.size() + 1; /* skip the prefix and the whitespace after it */
    const size_t end = sdp.find(' ', pos);
    int port = 0;
    if (end != std::string_view::npos) {
        std::from_chars(sdp.data() + pos, sdp.data() + end, port);
    }
    pos = end;
    return port;
}

/* The connection address and the port of the media of a kind, "" and 0 if
 * there is none. If the first m-line of the kind has port ZERO, use the
 * second one. */
static std::string sdp_media_remote(std::string_view sdp, std::string_view prefix, int &port)
{
    size_t pos = 0;
    std::string_view section;
    port = sdp_media_port(sdp, prefix, pos, section);
    if (port == 0) {
        port = sdp_media_port(sdp, prefix, pos, section);
    }
    if (port == 0) {
        return "";
    }

    bool ipv6;
    std::string host = sdp_media_connection(sdp, section, ipv6);
    if (host.empty()) {
        ERROR("extract_rtp_remote_addr: no c= line for %s in SDP message body", prefix.data() + 1);
    }
    return host;
}

void call::extract_rtp_remote_addr(const char* msg, std::string &audio_host, int &audio_port,
                                   std::string &video_host, int &video_port)
{
    /* Look for start of message body */
    const char *search = strstr(msg, "\r\n\r\n");
    if (!search) {
        ERROR("extract_rtp_remote_addr: SDP message body not found");
    }
    /* Point to the blank line before the body, so every SDP line starts with '\n'. */
    const std::string_view sdp(search + 2);

    audio_host = sdp_media_remote(sdp, SDP_AUDIOPORT_PREFIX, audio_port);
    video_host = sdp_media_remote(sdp, SDP_VIDEOPORT_PREFIX, video_port);
}

/* The SRTP crypto suites: those of RFC 4568, and AES_192_CM and AES_256_CM
 * of RFC 6188. NULL ones do not encrypt. */
struct SrtpSuite {
    const char* name;
    CipherType cipher;
    HashType hash;
};

enum { AES128_80, AES128_32, NULL_80, NULL_32, AES192_80, AES192_32, AES256_80, AES256_32 };

// clang-format off
static const SrtpSuite srtp_suites[] = {
    {"AES_CM_128_HMAC_SHA1_80", AES_CM_128, HMAC_SHA1_80},
    {"AES_CM_128_HMAC_SHA1_32", AES_CM_128, HMAC_SHA1_32},
    {"NULL_HMAC_SHA1_80", NULL_CIPHER, HMAC_SHA1_80},
    {"NULL_HMAC_SHA1_32", NULL_CIPHER, HMAC_SHA1_32},
    {"AES_192_CM_HMAC_SHA1_80", AES_CM_192, HMAC_SHA1_80},
    {"AES_192_CM_HMAC_SHA1_32", AES_CM_192, HMAC_SHA1_32},
    {"AES_256_CM_HMAC_SHA1_80", AES_CM_256, HMAC_SHA1_80},
    {"AES_256_CM_HMAC_SHA1_32", AES_CM_256, HMAC_SHA1_32},
};
// clang-format on

/* The SRTP keywords of a message, in the order of MessageCompType: [cryptotag1audio],
 * [cryptosuiteaescm128sha1801audio], [ueaescm128sha1321video], [cryptokeyparams2video]... */
struct SrtpKeyword {
    MessageCompType type;
    enum { TAG, SUITE, UNENCRYPTED, KEYPARAMS } what;
    bool video;
    ActiveCrypto crypto; // the a=crypto line: the first or the second
    const SrtpSuite *suite;
};

static const SrtpKeyword srtp_keywords[] = {
    {E_Message_CryptoTag1Audio, SrtpKeyword::TAG, false, PRIMARY_CRYPTO, nullptr},
    {E_Message_CryptoTag2Audio, SrtpKeyword::TAG, false, SECONDARY_CRYPTO, nullptr},
    {E_Message_CryptoSuiteAesCm128Sha1801Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_CryptoSuiteAesCm128Sha1802Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_CryptoSuiteAesCm128Sha1321Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_CryptoSuiteAesCm128Sha1322Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_CryptoKeyParams1Audio, SrtpKeyword::KEYPARAMS, false, PRIMARY_CRYPTO, nullptr},
    {E_Message_CryptoKeyParams2Audio, SrtpKeyword::KEYPARAMS, false, SECONDARY_CRYPTO, nullptr},
    {E_Message_CryptoTag1Video, SrtpKeyword::TAG, true, PRIMARY_CRYPTO, nullptr},
    {E_Message_CryptoTag2Video, SrtpKeyword::TAG, true, SECONDARY_CRYPTO, nullptr},
    {E_Message_CryptoSuiteAesCm128Sha1801Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_CryptoSuiteAesCm128Sha1802Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_CryptoSuiteAesCm128Sha1321Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_CryptoSuiteAesCm128Sha1322Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_CryptoKeyParams1Video, SrtpKeyword::KEYPARAMS, true, PRIMARY_CRYPTO, nullptr},
    {E_Message_CryptoKeyParams2Video, SrtpKeyword::KEYPARAMS, true, SECONDARY_CRYPTO, nullptr},
    {E_Message_CryptoSuiteNullSha1801Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[NULL_80]},
    {E_Message_CryptoSuiteNullSha1802Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[NULL_80]},
    {E_Message_CryptoSuiteNullSha1321Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[NULL_32]},
    {E_Message_CryptoSuiteNullSha1322Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[NULL_32]},
    {E_Message_CryptoSuiteNullSha1801Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[NULL_80]},
    {E_Message_CryptoSuiteNullSha1802Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[NULL_80]},
    {E_Message_CryptoSuiteNullSha1321Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[NULL_32]},
    {E_Message_CryptoSuiteNullSha1322Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[NULL_32]},
    {E_Message_UEAesCm128Sha1801Audio, SrtpKeyword::UNENCRYPTED, false, PRIMARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_UEAesCm128Sha1802Audio, SrtpKeyword::UNENCRYPTED, false, SECONDARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_UEAesCm128Sha1321Audio, SrtpKeyword::UNENCRYPTED, false, PRIMARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_UEAesCm128Sha1322Audio, SrtpKeyword::UNENCRYPTED, false, SECONDARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_UEAesCm128Sha1801Video, SrtpKeyword::UNENCRYPTED, true, PRIMARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_UEAesCm128Sha1802Video, SrtpKeyword::UNENCRYPTED, true, SECONDARY_CRYPTO, &srtp_suites[AES128_80]},
    {E_Message_UEAesCm128Sha1321Video, SrtpKeyword::UNENCRYPTED, true, PRIMARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_UEAesCm128Sha1322Video, SrtpKeyword::UNENCRYPTED, true, SECONDARY_CRYPTO, &srtp_suites[AES128_32]},
    {E_Message_CryptoSuiteAesCm192Sha1801Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[AES192_80]},
    {E_Message_CryptoSuiteAesCm192Sha1802Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[AES192_80]},
    {E_Message_CryptoSuiteAesCm192Sha1321Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[AES192_32]},
    {E_Message_CryptoSuiteAesCm192Sha1322Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[AES192_32]},
    {E_Message_CryptoSuiteAesCm256Sha1801Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[AES256_80]},
    {E_Message_CryptoSuiteAesCm256Sha1802Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[AES256_80]},
    {E_Message_CryptoSuiteAesCm256Sha1321Audio, SrtpKeyword::SUITE, false, PRIMARY_CRYPTO, &srtp_suites[AES256_32]},
    {E_Message_CryptoSuiteAesCm256Sha1322Audio, SrtpKeyword::SUITE, false, SECONDARY_CRYPTO, &srtp_suites[AES256_32]},
    {E_Message_CryptoSuiteAesCm192Sha1801Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[AES192_80]},
    {E_Message_CryptoSuiteAesCm192Sha1802Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[AES192_80]},
    {E_Message_CryptoSuiteAesCm192Sha1321Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[AES192_32]},
    {E_Message_CryptoSuiteAesCm192Sha1322Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[AES192_32]},
    {E_Message_CryptoSuiteAesCm256Sha1801Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[AES256_80]},
    {E_Message_CryptoSuiteAesCm256Sha1802Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[AES256_80]},
    {E_Message_CryptoSuiteAesCm256Sha1321Video, SrtpKeyword::SUITE, true, PRIMARY_CRYPTO, &srtp_suites[AES256_32]},
    {E_Message_CryptoSuiteAesCm256Sha1322Video, SrtpKeyword::SUITE, true, SECONDARY_CRYPTO, &srtp_suites[AES256_32]},
};

static const SrtpKeyword *find_srtp_keyword(MessageCompType type)
{
    if (type < E_Message_CryptoTag1Audio || type > E_Message_CryptoSuiteAesCm256Sha1322Video) {
        return nullptr;
    }
    return &srtp_keywords[type - E_Message_CryptoTag1Audio];
}

static const SrtpSuite *find_srtp_suite(const char *name)
{
    for (const SrtpSuite &suite : srtp_suites) {
        if (!strcmp(name, suite.name)) {
            return &suite;
        }
    }
    return nullptr;
}

/* Selects the cipher and hash of a suite, the NULL cipher for an
 * UNENCRYPTED_SRTP one; any other suite is left alone. */
static void select_srtp_suite(JLSRTP &ctx, const char *name, bool unencrypted, ActiveCrypto crypto)
{
    const SrtpSuite *suite = find_srtp_suite(name);
    if (!suite) {
        return;
    }
    if (ctx.selectCipherAlgorithm(unencrypted ? NULL_CIPHER : suite->cipher, crypto) < 0) {
        ERROR("SRTP crypto suite %s is not supported by the TLS library SIPp is built with", name);
    }
    ctx.selectHashAlgorithm(suite->hash, crypto);
}

/* Decodes the master key and salt of a received a=crypto line into ctx.
 * The RFC 6188 suites take a key of their AES key size, even without
 * encryption, the others (NULL ones too) a 128-bit key. Returns false,
 * with a warning, if it is not such a key and a 14-byte salt. */
static bool decode_srtp_key(JLSRTP& ctx, std::string& mks, const char* name, ActiveCrypto crypto)
{
    const SrtpSuite *suite = find_srtp_suite(name);
    size_t keyLength = !suite                        ? JLSRTP_ENCRYPTION_KEY_LENGTH
                       : suite->cipher == AES_CM_192 ? JLSRTP_AES_192_KEY_LENGTH
                       : suite->cipher == AES_CM_256 ? JLSRTP_AES_256_KEY_LENGTH
                                                     : JLSRTP_ENCRYPTION_KEY_LENGTH;

    if (ctx.decodeMasterKeySalt(mks, crypto, keyLength) < 0) {
        WARNING("SRTP: ignoring the %s key %s: not a %zu-byte key and a 14-byte salt",
                name, mks.c_str(), keyLength);
        return false;
    }
    return true;
}

/* The a=crypto line in ctx (PRIMARY_CRYPTO or SECONDARY_CRYPTO) of the
 * suite of an answer: the line of its tag if that is of the suite, else
 * the first line of the suite, else INVALID_CRYPTO. A line that the SDP
 * lacked, or whose key was ignored, has tag 0 and is never taken. */
static ActiveCrypto find_crypto_line(JLSRTP& ctx, unsigned int tag, const char* suite)
{
    auto is_suite = [&ctx, suite](ActiveCrypto crypto) {
        return ctx.getCryptoTag(crypto) != 0 && ctx.getCryptoSuite(crypto) == suite;
    };
    for (ActiveCrypto crypto : {PRIMARY_CRYPTO, SECONDARY_CRYPTO}) {
        if (is_suite(crypto) && ctx.getCryptoTag(crypto) == tag) {
            return crypto;
        }
    }
    for (ActiveCrypto crypto : {PRIMARY_CRYPTO, SECONDARY_CRYPTO}) {
        if (is_suite(crypto)) {
            return crypto;
        }
    }
    return INVALID_CRYPTO;
}

/* Whether the answerer, which answers suite, swaps to the offer's second
 * a=crypto line to receive with; it warns if no line of the offer it
 * took is of that suite. */
static bool answer_swaps_crypto(JLSRTP& rx, const char* suite)
{
    ActiveCrypto crypto = find_crypto_line(rx, 0, suite);
    if (crypto == INVALID_CRYPTO) {
        WARNING("SRTP: answering %s, the suite of no a=crypto line taken from the offer", suite);
    }
    return crypto == SECONDARY_CRYPTO;
}

/* The offerer sends with the line of its offer that the answer's
 * a=crypto line takes. If it takes none, it warns and sends plain RTP
 * rather than SRTP with a key the answerer did not take. */
static void take_answered_crypto(JLSRTP& tx, const SrtpInfoParams& p, const char* media)
{
    ActiveCrypto crypto = find_crypto_line(tx, p.primary_cryptotag, p.primary_cryptosuite);
    if (crypto == SECONDARY_CRYPTO) {
        tx.swapCrypto();
    } else if (crypto == INVALID_CRYPTO) {
        WARNING("SRTP: the %s answer a=crypto:%d %s is none of the offered lines, sending plain RTP",
                media, p.primary_cryptotag, p.primary_cryptosuite);
        tx.setCryptoTag(0, PRIMARY_CRYPTO);
        tx.setCryptoTag(0, SECONDARY_CRYPTO);
    }
}

/******* Extract SRTP remote media infomartion from SDP  *******/

/* Parse an a=crypto line into its tag, its suite and the key of its first
 * key-params (without a lifetime or MKI). Returns whether a session
 * parameter after the key-params is UNENCRYPTED_SRTP. */
static bool parse_crypto_line(const char* line, int& tag, char* suite, char* key)
{
    int end = 0;
    sscanf(line, "\na=crypto:%d %24[^ ] inline:%64[^ |\r\n]%n", &tag, suite, key, &end);
    if (!end)
        return false;
    // Skip the rest of the key-params: a lifetime, an MKI, more keys
    const char* session_params = line + end + strcspn(line + end, " \r\n");
    return strstr(session_params, "UNENCRYPTED_SRTP") != nullptr;
}

#define SDP_AUDIOCRYPTO_PREFIX "\na=crypto:"
#define SDP_VIDEOCRYPTO_PREFIX "\na=crypto:"
int call::extract_srtp_remote_info(const char * msg, SrtpInfoParams &pA, SrtpInfoParams &pV)
{
    pA.found = false;
    pV.found = false;

    pA.primary_cryptotag = 0;
    pV.primary_cryptotag = 0;
    *pA.primary_cryptosuite = 0;
    *pV.primary_cryptosuite = 0;
    *pA.primary_cryptokeyparams = 0;
    *pV.primary_cryptokeyparams = 0;
    pA.primary_unencrypted_srtp = false;
    pV.primary_unencrypted_srtp = false;

    pA.secondary_cryptotag = 0;
    pV.secondary_cryptotag = 0;
    *pA.secondary_cryptosuite = 0;
    *pV.secondary_cryptosuite = 0;
    *pA.secondary_cryptokeyparams = 0;
    *pV.secondary_cryptokeyparams = 0;
    pA.secondary_unencrypted_srtp = false;
    pV.secondary_unencrypted_srtp = false;

    std::size_t mline_sol = 0; /* Start of m-line line */
    std::size_t mline_eol = 0; /* End of m-line line */
    std::string mline_contents; /* Actual m-line contents */
    std::size_t msection_limit = 0; /* m-line media section limit */
    std::string msgstr; /* std::string representation of SDP body */

    bool audioExists = false;
    bool videoExists = false;
    std::size_t cur_pos = 0;
    int audio_port = 0;
    int video_port = 0;
    std::size_t pos1 = 0;
    std::size_t pos2 = 0;
    std::string sub;

    // skip past header - point to blank line before body
    // Try CRLF and if not found, try LF (the RFC requires CRLF)
    if (const char *body_crlf = strstr(msg, "\r\n\r\n")) {
        msgstr = body_crlf + 4;
    } else if (const char *body_lf = strstr(msg, "\n\n")) {
        msgstr = body_lf + 2;
    }

    if (msgstr.empty())
        return -1; /* FAILURE -- No SDP body found */

    /* --------------------------------------------------------------
        * Try to find an AUDIO MLINE
        * -------------------------------------------------------------- */
    pos1 = msgstr.find(SDP_AUDIOPORT_PREFIX, 0, 8);
    if (pos1 != std::string::npos)
    {
        pos1 += 8; /* skip SDP_AUDIOPORT_PREFIX */
        pos1 += 1; /* skip first whitespace */
        pos2 = msgstr.find(" ", pos1); /* find second whitespace AFTER port */
        if (pos2 != std::string::npos)
        {
            sub = msgstr.substr(pos1, pos2-pos1); /* extract port substring */
            sscanf(sub.c_str(), "%d", &audio_port); /* parse port substring as integer */
            if (audio_port != 0)
            {
                logSrtpInfo("found first ACTIVE audio m-line with NON-ZERO port [%d]...\n", audio_port);
                audioExists = true;
            }
            else
            {
                logSrtpInfo("found first INACTIVE audio m-line (e.g. with ZERO port)...\n");

                pos1 = msgstr.find(SDP_AUDIOPORT_PREFIX, pos2, 8);
                if (pos1 != std::string::npos)
                {
                    pos1 += 8; /* skip SDP_AUDIOPORT_PREFIX  */
                    pos1 += 1; /* skip first whitespace */
                    pos2 = msgstr.find(" ", pos1); /* find second whitespace AFTER port */
                    if (pos2 != std::string::npos)
                    {
                        sub = msgstr.substr(pos1, pos2-pos1); /* extract port substring */
                        sscanf(sub.c_str(), "%d", &audio_port);
                        if (audio_port != 0)
                        {
                            logSrtpInfo("found second ACTIVE audio m-line with NON-ZERO port [%d]...\n", audio_port);
                            audioExists = true;
                        }
                        else
                        {
                            logSrtpInfo("found second INACTIVE audio m-line (e.g. with ZERO port)...\n");
                            audioExists = false;
                        }
                    }
                    else
                    {
                        logSrtpInfo("invalid formatting encountered:  missing whitespace after second audio m-line port...\n");
                        audioExists = false;
                    }
                }
                else
                {
                    logSrtpInfo("NO second audio m-line found...\n");
                    audioExists = false;
                }
            }
        }
        else
        {
            logSrtpInfo("invalid formatting encountered:  missing whitespace after first audio m-line port...\n");
            audioExists = false;
        }
    }
    else
    {
        logSrtpInfo("NO first audio m-line found...\n");
        audioExists = false;
    }

    cur_pos = pos2;

    if (audioExists)
    {
        // AUDIO "m=audio" prefix found...
        pA.found = true;

        // Only the audio media section's crypto lines are audio's
        msection_limit = msgstr.find("\nm=", cur_pos, 3);

        mline_sol = msgstr.find(SDP_AUDIOCRYPTO_PREFIX, cur_pos/*0*/, 10);
        if (mline_sol < msection_limit) {
            // PRIMARY AUDIO "a:crypto:" crypto prefix found
            mline_eol = msgstr.find("\n", mline_sol + 1, 1);
            if (mline_eol != std::string::npos) {
                mline_contents = msgstr.substr(mline_sol, mline_eol - mline_sol);
                if (parse_crypto_line(mline_contents.c_str(), pA.primary_cryptotag,
                                      pA.primary_cryptosuite, pA.primary_cryptokeyparams)) {
                    logSrtpInfo("call::extract_srtp_remote_info():  Detected UNENCRYPTED_SRTP token for PRIMARY AUDIO\n");
                    pA.primary_unencrypted_srtp = true;
                } else {
                    logSrtpInfo("call::extract_srtp_remote_info():  No UNENCRYPTED_SRTP token detected for PRIMARY AUDIO\n");
                    pA.primary_unencrypted_srtp = false;
                }
            }

            mline_sol = mline_eol == std::string::npos ? mline_eol :
                        msgstr.find(SDP_AUDIOCRYPTO_PREFIX, mline_eol, 10);
        }

        if (mline_sol < msection_limit) {
            // SECONDARY AUDIO "a:crypto:" crypto prefix found
            mline_eol = msgstr.find("\n", mline_sol + 1, 1);
            if (mline_eol != std::string::npos) {
                mline_contents = msgstr.substr(mline_sol, mline_eol - mline_sol);
                if (parse_crypto_line(mline_contents.c_str(), pA.secondary_cryptotag,
                                      pA.secondary_cryptosuite, pA.secondary_cryptokeyparams)) {
                    logSrtpInfo("call::extract_srtp_remote_info():  Detected UNENCRYPTED_SRTP token for SECONDARY AUDIO\n");
                    pA.secondary_unencrypted_srtp = true;
                } else {
                    logSrtpInfo("call::extract_srtp_remote_info():  No UNENCRYPTED_SRTP token detected for SECONDARY AUDIO\n");
                    pA.secondary_unencrypted_srtp = false;
                }
            }
        }
    }

    /* --------------------------------------------------------------
        * Try to find a VIDEO MLINE
        * -------------------------------------------------------------- */
    pos1 = msgstr.find(SDP_VIDEOPORT_PREFIX, 0, 8);
    if (pos1 != std::string::npos)
    {
        pos1 += 8; /* skip SDP_VIDEOPORT_PREFIX */
        pos1 += 1; /* skip first whitespace */
        pos2 = msgstr.find(" ", pos1); /* find second whitespace AFTER port */
        if (pos2 != std::string::npos)
        {
            sub = msgstr.substr(pos1, pos2-pos1); /* extract port substring */
            sscanf(sub.c_str(), "%d", &video_port); /* parse port substring as integer */
            if (video_port != 0)
            {
                logSrtpInfo("found first ACTIVE video m-line with NON-ZERO port [%d]...\n", video_port);
                videoExists = true;
            }
            else
            {
                logSrtpInfo("found first INACTIVE video m-line (e.g. with ZERO port)...\n");

                pos1 = msgstr.find(SDP_VIDEOPORT_PREFIX, pos2, 8);
                if (pos1 != std::string::npos)
                {
                    pos1 += 8; /* skip SDP_VIDEOPORT_PREFIX  */
                    pos1 += 1; /* skip first whitespace */
                    pos2 = msgstr.find(" ", pos1); /* find second whitespace AFTER port */
                    if (pos2 != std::string::npos)
                    {
                        sub = msgstr.substr(pos1, pos2-pos1); /* extract port substring */
                        sscanf(sub.c_str(), "%d", &video_port);
                        if (video_port != 0)
                        {
                            logSrtpInfo("found second ACTIVE video m-line with NON-ZERO port [%d]...\n", video_port);
                            videoExists = true;
                        }
                        else
                        {
                            logSrtpInfo("found second INACTIVE video m-line (e.g. with ZERO port)...\n");
                            videoExists = false;
                        }
                    }
                    else
                    {
                        logSrtpInfo("invalid formatting encountered:  missing whitespace after second video m-line port...\n");
                        videoExists = false;
                    }
                }
                else
                {
                    logSrtpInfo("NO second video m-line found...\n");
                    videoExists = false;
                }
            }
        }
        else
        {
            logSrtpInfo("invalid formatting encountered:  missing whitespace after first video m-line port...\n");
            videoExists = false;
        }
    }
    else
    {
        logSrtpInfo("NO first video m-line found...\n");
        videoExists = false;
    }

    cur_pos = pos2;

    if (videoExists)
    {
        // VIDEO "m=video" prefix found...
        pV.found = true;

        // Only the video media section's crypto lines are video's
        msection_limit = msgstr.find("\nm=", cur_pos, 3);

        mline_sol = msgstr.find(SDP_VIDEOCRYPTO_PREFIX, cur_pos/*mline_eol+1*/, 10);
        if (mline_sol < msection_limit) {
            // PRIMARY VIDEO "a:crypto:" crypto prefix found
            mline_eol = msgstr.find("\n", mline_sol + 1, 1);
            if (mline_eol != std::string::npos) {
                mline_contents = msgstr.substr(mline_sol, mline_eol - mline_sol);
                if (parse_crypto_line(mline_contents.c_str(), pV.primary_cryptotag,
                                      pV.primary_cryptosuite, pV.primary_cryptokeyparams)) {
                    logSrtpInfo("call::extract_srtp_remote_info():  Detected UNENCRYPTED_SRTP token for PRIMARY VIDEO\n");
                    pV.primary_unencrypted_srtp = true;
                } else {
                    logSrtpInfo("call::extract_srtp_remote_info():  No UNENCRYPTED_SRTP token detected for PRIMARY VIDEO\n");
                    pV.primary_unencrypted_srtp = false;
                }
            }

            mline_sol = mline_eol == std::string::npos ? mline_eol :
                        msgstr.find(SDP_VIDEOCRYPTO_PREFIX, mline_eol, 10);
        }

        if (mline_sol < msection_limit) {
            // SECONDARY VIDEO "a:crypto:" crypto prefix found
            mline_eol = msgstr.find("\n", mline_sol + 1, 1);
            if (mline_eol != std::string::npos) {
                mline_contents = msgstr.substr(mline_sol, mline_eol - mline_sol);
                if (parse_crypto_line(mline_contents.c_str(), pV.secondary_cryptotag,
                                      pV.secondary_cryptosuite, pV.secondary_cryptokeyparams)) {
                    logSrtpInfo("call::extract_srtp_remote_info():  Detected UNENCRYPTED_SRTP token for SECONDARY VIDEO\n");
                    pV.secondary_unencrypted_srtp = true;
                } else {
                    logSrtpInfo("call::extract_srtp_remote_info():  No UNENCRYPTED_SRTP token detected for SECONDARY VIDEO\n");
                    pV.secondary_unencrypted_srtp = false;
                }
            }
        }
    }

    return 0; /* SUCCESS -- parsed SDP SRTP INFO */
}

/* Whether two messages have the same CSeq, number and method. */
static bool same_cseq(const char* a, const char* b)
{
    return get_header_content(a, "CSeq:").view() == get_header_content(b, "CSeq:").view();
}

/* Free the text s holds, whose buffer clear() would keep */
static void release(std::string &s)
{
    if (!s.empty()) {
        std::string().swap(s);
    }
}

/******* Very simple hash for retransmission detection  *******/

/* The hash of the loop below (hash * 65599 + c for each character) of
 * the len characters of s, taken four at a time: each step then waits
 * for one multiplication of the step before, not four. */
static unsigned long sdbm_hash(const char *s, size_t len)
{
    const unsigned long p1 = 65599, p2 = p1 * p1, p3 = p2 * p1, p4 = p3 * p1;
    unsigned long hash = 0;
    size_t i = 0;

    for (; i + 4 <= len; i += 4) {
        hash = hash * p4 + (unsigned long)s[i] * p3 + (unsigned long)s[i + 1] * p2 + (unsigned long)s[i + 2] * p1 +
               (unsigned long)s[i + 3];
    }
    for (; i < len; i++) {
        hash = hash * p1 + (unsigned long)s[i];
    }
    return hash;
}

unsigned long call::hash(const char * msg)
{
    unsigned long hash = 0;
    int c;

    if (rtcheck == RTCHECK_FULL) {
        hash = sdbm_hash(msg, strlen(msg));
    } else if (rtcheck == RTCHECK_LOOSE) {
        /* Based on section 11.5 (bullet 2) of RFC2543 we only take into account
         * the To, From, Call-ID, and CSeq values. */
        for (const char *name : {"To:", "From:", "Call-ID:", "CSeq:"}) {
            const header_value value = get_header_content(msg, name);
            for (const char v : value.view()) {
                hash = v + (hash << 6) + (hash << 16) - hash;
            }
        }
        /* For responses, we should also consider the code and body (if any),
         * because they are not nearly as well defined as the request retransmission. */
        if (!strncmp(msg, "SIP/2.0", strlen("SIP/2.0"))) {
            /* Add the first line into the hash. */
            const char *hdr = msg + strlen("SIP/2.0");
            while ((c = *hdr++) && (c != '\r'))
                hash = c + (hash << 6) + (hash << 16) - hash;
            /* Add the body (if any) into the hash. */
            hdr = strstr(msg, "\r\n\r\n");
            if (hdr) {
                hdr += strlen("\r\n\r\n");
                while ((c = *hdr++))
                    hash = c + (hash << 6) + (hash << 16) - hash;
            }
        }
    } else {
        ERROR("Internal error: Invalid rtcheck %d", rtcheck);
    }

    return hash;
}

/******************* Call class implementation ****************/
call::call(scenario *call_scenario, std::string_view p_id, bool use_ipv6, int userId, struct sockaddr_storage *dest)
    : listener(p_id, true)
{
    init(call_scenario, nullptr, dest, p_id, userId, use_ipv6, false, false);
}

call::call(scenario *call_scenario, std::string_view p_id, SIPpSocket *socket, struct sockaddr_storage *dest)
    : listener(p_id, true)
{
    init(call_scenario, socket, dest, p_id, 0 /* No User. */, socket->ss_ipv6, false /* Not Auto. */, false);
}

call::call(scenario *call_scenario, SIPpSocket *socket, struct sockaddr_storage *dest, std::string_view p_id,
           int userId, bool ipv6, bool isAutomatic, bool isInitialization)
    : listener(p_id, true)
{
    init(call_scenario, socket, dest, p_id, userId, ipv6, isAutomatic, isInitialization);
}

call *call::add_call(int userId, bool ipv6, struct sockaddr_storage *dest,
                     remote_address *remote)
{
    static char call_id[MAX_HEADER_LEN];

    if(!next_number) {
        next_number ++;
    }

    build_call_id(call_id, next_number);

    call *new_call = new call(main_scenario, nullptr, dest, call_id, userId, ipv6, false /* Not Auto. */, false);
    new_call->remote = remote;
    return new_call;
}


void call::init(scenario *call_scenario, SIPpSocket *socket, struct sockaddr_storage *dest, std::string_view p_id,
                int userId, bool ipv6, bool isAutomatic, bool isInitCall)
{
    _srtpctxdebugfile = nullptr;

    if (srtpcheck_debug)
    {
        if (sendMode == MODE_CLIENT)
        {
            _srtpctxdebugfile = fopen("srtpctxdebugfile_uac", "w");
        }
        else if (sendMode == MODE_SERVER)
        {
            _srtpctxdebugfile = fopen("srtpctxdebugfile_uas", "w");
        }

        if (_srtpctxdebugfile == nullptr)
        {
            /* error encountered opening srtp ctx debug file */
            WARNING("Error encountered opening srtp ctx debug file");
        }
    }

    _sessionStateCurrent = eNoSession;
    _sessionStateOld = eNoSession;

    this->call_scenario = call_scenario;
    zombie = false;

    msg_index = 0;
    last_send_index = 0;
    last_send_unanswered = false;
    recv_retrans_last = false;

    last_recv_hash = 0;
    last_recv_index = -1;

    last_recv_invite_cseq = 0;

    recv_retrans_hash = 0;
    recv_retrans_recv_index = -1;
    recv_retrans_send_index = -1;

    cseq = 0;

    next_retrans = 0;
    nb_retrans = 0;
    nb_last_delay = 0;

    paused_until = 0;
    rtpstream_wait_check = 0;
    rtpstream_wait_until = 0;
    rtpstream_wait_msg = nullptr;
    verify_pending = 0;

    call_port = 0;

    start_time = clock_tick;
    call_established=false ;
    ack_is_pending=false ;
    bye_after_peer_request = false;
    cseq = base_cseq;
    nb_last_delay = 0;
    use_ipv6 = ipv6;

    //
    // JLSRTP CLIENT context constants
    //
    if (srtpcheck_debug)
    {
        if (sendMode == MODE_CLIENT)
        {
            logSrtpInfo("call::init():  (a) TX-UAC-AUDIO SRTP context - CLIENT setting SRTP header size to 12\n");
            _srtpAudio.txUAC->setSrtpHeaderSize(12);
            logSrtpInfo("call::init():  (a) TX-UAC-VIDEO SRTP context - CLIENT setting SRTP header size to 12\n");
            _srtpVideo.txUAC->setSrtpHeaderSize(12);
            logSrtpInfo("call::init():  (b) RX-UAC-AUDIO SRTP context - CLIENT setting SRTP header size to 12\n");
            _srtpAudio.rxUAC->setSrtpHeaderSize(12);
            logSrtpInfo("call::init():  (b) RX-UAC-VIDEO SRTP context - CLIENT setting SRTP header size to 12\n");
            _srtpVideo.rxUAC->setSrtpHeaderSize(12);
        }
    }

    //
    // JLSRTP SERVER context constants
    //
    if (srtpcheck_debug)
    {
        if (sendMode == MODE_SERVER)
        {
            logSrtpInfo("call::init():  (c) RX-UAS-AUDIO SRTP context - SERVER setting SRTP header size to 12\n");
            _srtpAudio.rxUAS->setSrtpHeaderSize(12);
            logSrtpInfo("call::init():  (c) RX-UAS-VIDEO SRTP context - SERVER setting SRTP header size to 12\n");
            _srtpVideo.rxUAS->setSrtpHeaderSize(12);
            logSrtpInfo("call::init():  (d) TX-UAS-AUDIO SRTP context - SERVER setting SRTP header size to 12\n");
            _srtpAudio.txUAS->setSrtpHeaderSize(12);
            logSrtpInfo("call::init():  (d) TX-UAS-VIDEO SRTP context - SERVER setting SRTP header size to 12\n");
            _srtpVideo.txUAS->setSrtpHeaderSize(12);
        }
    }

    /* check and warn on rtpstream_new_call result? -> error alloc'ing mem */
    rtpstream_new_call(&rtpstream_callinfo);

#ifdef PCAPPLAY
    hasMediaInformation = 0;
#endif

    call_remote_socket = nullptr;
    if (socket) {
        associate_socket(socket);
        socket->ss_count++;
        /* [local_port] is the socket's, as for a shared call socket. */
        call_port = socket->ss_port;
    } else {
        call_socket = nullptr;
    }
    if (dest) {
        memcpy(&call_peer, dest, sizeof(call_peer));
    } else {
        memset(&call_peer, 0, sizeof(call_peer));
    }
    remote = nullptr;

    // initialising the CallVariable with the Scenario variable
    int i;
    VariableTable *userVars = nullptr;
    bool putUserVars = false;
    if (userId) {
        int_vt_map::iterator it = userVarMap.find(userId);
        if (it != userVarMap.end()) {
            userVars = it->second;
        }
    } else {
        userVars = new VariableTable(userVariables);
        /* Creating this table creates a reference to it, but if it is really used,
         * then the refcount will be increased. */
        putUserVars = true;
    }
    if (call_scenario->allocVars->size > 0) {
        M_callVariableTable = new VariableTable(userVars, call_scenario->allocVars->size);
    } else if (userVars && userVars->size > 0) {
        M_callVariableTable = userVars->getTable();
    } else if (globalVariables->size > 0) {
        M_callVariableTable = globalVariables->getTable();
    } else {
        M_callVariableTable = nullptr;
    }
    if (putUserVars) {
        userVars->putTable();
    }

    if (call_scenario->transactions.size() > 0) {
        transactions = std::make_unique<txnInstanceInfo[]>(call_scenario->transactions.size());
    }

    if (call_scenario->dialogs) {
        dialogs = std::make_unique<call_dialogs>();
        dialogs->dialogs[1];
        if (call_scenario->new_dialogs && !isInitCall) {
            dialogs->waiting = new_dialog_calls.insert(new_dialog_calls.end(), this);
            dialogs->waits_new = true;
        }
    }

    // If not updated by a message we use the start time
    // information to compute rtd information
    start_time_rtd.resize(call_scenario->stats->nRtds());
    rtd_done.resize(call_scenario->stats->nRtds());
    for (i = 0; i < call_scenario->stats->nRtds(); i++) {
        start_time_rtd[i] = getmicroseconds();
        rtd_done[i] = false;
    }

    // by default, last action result is NO_ERROR
    last_action_result = call::E_AR_NO_ERROR;

    this->userId = userId;

    /* For automatic answer calls to an out of call request, we must not */
    /* increment the input files line numbers to not disturb */
    /* the input files read mechanism (otherwise some lines risk */
    /* to be systematically skipped. An <init> reads the line the */
    /* first call will read, and leaves it to that call. */
    if (!isAutomatic) {
        m_lineNumber = new file_line_map();
        for (file_map::iterator file_it = inFiles.begin();
                file_it != inFiles.end();
                file_it++) {
            (*m_lineNumber)[file_it->first] = file_it->second->nextLine(userId, !isInitCall);
        }
    } else {
        m_lineNumber = nullptr;
    }
    this->initCall = isInitCall;

#ifdef PCAPPLAY
    hasMediaInformation = 0;
#endif

    recv_timeout = 0;
    send_timeout = 0;
    timewait = false;

    if (!isAutomatic) {
        /* Not advancing the number is safe, because for automatic calls we do not
         * assign the identifier,  the only other place it is used is for the auto
         * media port. An <init> is not a call of the scenario either: the
         * first call is number 1 all the same. */
        number = isInitCall ? 0 : next_number++;

        if (use_tdmmap) {
            tdm_map_number = get_tdm_map_number();
            if (tdm_map_number == 0) {
                /* Can't create the new call */
                WARNING("Can't create new outgoing call: all tdm_map circuits busy");
                computeStat(CStat::E_CALL_FAILED);
                computeStat(CStat::E_FAILED_OUTBOUND_CONGESTION);
                this->zombie = true;
                return;
            }
            /* Mark the entry in the list as busy */
            tdm_map[tdm_map_number - 1] = true;
        } else {
            tdm_map_number = 0;
        }
    }

    callDebug("Starting call %s\n", id);

    setRunning();
}

bool call::checkAckCSeq(const char* msg)
{
    static char request[65];
    unsigned long int rcseq = 0;
    const char* ptr = nullptr;

    rcseq = get_cseq_value(msg);
    memset(request, 0, sizeof(request));

    if ((msg[0] == 'S') &&
        (msg[1] == 'I') &&
        (msg[2] == 'P') &&
        (msg[3] == '/') &&
        (msg[4] == '2') &&
        (msg[5] == '.') &&
        (msg[6] == '0')) {
        request[0]=0;
    } else if ((ptr = strchr(msg, ' '))) {
        if ((ptr - msg) < 64) {
            memcpy(request, msg, ptr - msg);
            request[ptr - msg] = 0;
        } else {
            ERROR("SIP method too long in received message '%s'", msg);
        }
    } else {
        ERROR("Invalid SIP message received '%s'", msg);
    }

    if ((default_behaviors & DEFAULT_BEHAVIOR_BADCSEQ) &&
        !strncmp(request, "ACK", 3) &&
        (rcseq != last_recv_invite_cseq)) {
        return false;
    } else {
        return true;
    }
}

int call::_callDebug(const char *fmt, ...)
{
    va_list ap;

    if (!useCallDebugf) {
        return 0;
    }

    /* First we figure out how much to allocate. */
    va_start(ap, fmt);
    int ret = vsnprintf(nullptr, 0, fmt, ap);
    va_end(ap);

    struct timeval now;
    gettimeofday(&now, nullptr);
    std::string &debug = cold().debugBuffer;
    debug += CStat::formatTime(&now, rfc3339);
    debug += ' ';

    /* Written in place: vsnprintf() ends it with the string's own NUL */
    const size_t at = debug.size();
    debug.resize(at + ret);
    va_start(ap, fmt);
    vsnprintf(debug.data() + at, ret + 1, fmt, ap);
    va_end(ap);

    return ret;
}

call::~call()
{
    computeStat(CStat::E_ADD_CALL_DURATION, clock_tick - start_time);

    if (call_remote_socket && (call_remote_socket != main_remote_socket)) {
        call_remote_socket->close();
    }
    while (!peekCold().request_sources.empty()) {
        forget_request_source(cold_state->request_sources.begin());
    }

    /* Deletion of the call variable */
    if(M_callVariableTable) {
        M_callVariableTable->putTable();
    }
    if (m_lineNumber) {
        delete m_lineNumber;
    }
    if (userId) {
        CallGenerationTask::free_user(userId);
    }

    if (dialogs) {
        if (dialogs->waits_new) {
            new_dialog_calls.erase(dialogs->waiting);
        }
        for (auto &[dialog, d] : dialogs->dialogs) {
            if (!d.call_id.empty()) {
                unlisten(d.call_id.c_str());
            }
        }
    }

    rtpstream_end_call(&rtpstream_callinfo);

    /* tdm_map_number counts from 1, and is 0 for a call that got no
     * circuit. */
    if (use_tdmmap && tdm_map_number) {
        tdm_map[tdm_map_number - 1] = false;
    }

    if (verify_pending) {
        /* Its commands run on, and their end is ignored */
        for (auto& v : verify_commands) {
            if (v.second.waiting == this) {
                v.second.waiting = nullptr;
            }
        }
    }

    if (_srtpctxdebugfile) {
        fclose(_srtpctxdebugfile);
        _srtpctxdebugfile = nullptr;
    }
}

void call::setRtpEchoErrors(int value)
{
    if (!initCall)
    {
        call_scenario->stats->setRtpEchoErrors(value);
    }
}

int call::getRtpEchoErrors()
{
    if (!initCall)
    {
        return call_scenario->stats->getRtpEchoErrors();
    }
    else
    {
        return 0;
    }
}

void call::computeStat (CStat::E_Action P_action)
{
    if (initCall) {
        return;
    }
    call_scenario->stats->computeStat(P_action);
}

void call::computeStat (CStat::E_Action P_action, unsigned long P_value)
{
    if (initCall) {
        return;
    }
    call_scenario->stats->computeStat(P_action, P_value);
}

void call::computeStat (CStat::E_Action P_action, unsigned long P_value, int which)
{
    if (initCall) {
        return;
    }
    call_scenario->stats->computeStat(P_action, P_value, which);
}

/* Dump call info to error log. */
void call::dump()
{
    char s[MAX_HEADER_LEN];
    int slen = sizeof(s);
    int written;

    written = snprintf(s, slen, "%s: State %d", id, msg_index);
    if (next_retrans) {
        written += snprintf(s + written, slen - written, " (next retrans %u)", next_retrans);
    }
    if (paused_until) {
        written += snprintf(s + written, slen - written, " (paused until %u)", paused_until);
    }
    if (recv_timeout) {
        written += snprintf(s + written, slen - written, " (recv timeout %u)", recv_timeout);
    }
    if (rtpstream_wait_check) {
        written += snprintf(s + written, slen - written, " (rtp_stream wait until %u)", rtpstream_wait_until);
    }
    if (verify_pending) {
        written += snprintf(s + written, slen - written, " (%d exec verify running)", verify_pending);
    }
    if (send_timeout) {
        written += snprintf(s + written, slen - written, " (send timeout %u)", send_timeout);
    }
    WARNING("%s", s);
}

bool call::connect_socket_if_needed()
{
    bool existing;

    if(call_socket) return true;
    if(!multisocket) return true;

    if(transport == T_UDP) {
        struct sockaddr_storage saddr;

        if(sendMode != MODE_CLIENT)
            return true;

        if (!peripsocket) {
            if ((associate_socket(SIPpSocket::new_sipp_call_socket(use_ipv6, transport, &existing))) == nullptr) {
                ERROR_NO("Unable to get a UDP socket (1)");
            }
        } else {
            const std::string peripaddr = getFieldFromInputFile(ip_file, peripfield, nullptr);
            auto i = map_perip_fd.find(peripaddr);
            SIPpSocket *sock = i != map_perip_fd.end() ? i->second : nullptr;
            if (!sock) {
                if (gai_getsockaddr(&saddr, peripaddr.c_str(), local_port, AI_PASSIVE, AF_UNSPEC) != 0) {
                    ERROR("Unknown host '%s' in the -ip_field of %s", peripaddr.c_str(), ip_file.c_str());
                }
                sock = find_perip_socket(peripaddr, &saddr);
            }
            if (sock) {
                // Socket exists already
                associate_socket(sock);
                existing = true;
                sock->ss_count++;
            } else {
                // Socket does not exist
                if ((associate_socket(SIPpSocket::new_sipp_call_socket(use_ipv6, transport, &existing))) == nullptr) {
                    ERROR_NO("Unable to get a UDP socket (2)");
                } else {
                    /* Ensure that it stays persistent, because it is recorded in the map. */
                    call_socket->ss_count++;
                    add_perip_socket(peripaddr, &saddr, call_socket);
                }
            }
        }
        if (existing) {
            /* [local_port] is the shared socket's. */
            call_port = call_socket->ss_port;
            return true;
        }

        /* -t ui: saddr is the -ip_field address */
        if (!peripsocket) {
            memcpy(&saddr, &local_addr_storage, sizeof(struct sockaddr_storage));
            if (use_ipv6) {
                saddr.ss_family = AF_INET6;
            } else {
                saddr.ss_family = AF_INET;
            }
        }

        if (sipp_bind_socket(call_socket, &saddr, &call_port)) {
            ERROR_NO("Unable to bind UDP socket");
        }
    } else { /* TCP, SCTP or TLS. */
        struct sockaddr_storage *L_dest = remote ? &remote->addr : &remote_sockaddr;

        if ((associate_socket(SIPpSocket::new_sipp_call_socket(use_ipv6, transport, &existing))) == nullptr) {
            ERROR_NO("Unable to get a TCP/SCTP/TLS socket");
        }

        if (existing) {
            call_port = call_socket->ss_port;
            return true;
        }

        sipp_customize_socket(call_socket);

        if (use_remote_sending_addr) {
            L_dest = &remote_sending_sockaddr;
        }
        if (L_dest->ss_family == AF_UNSPEC) {
            ERROR("Call '%s' has no remote host to connect to", id);
        }

        if (call_socket->connect(L_dest)) {
            if (reconnect_allowed()) {
                if(errno == EINVAL) {
                    /* This occurs sometime on HPUX but is not a true INVAL */
                    WARNING("Unable to connect a TCP/SCTP/TLS socket, remote peer error");
                } else {
                    WARNING("Unable to connect a TCP/SCTP/TLS socket");
                }
                /* This connection failed.  We must be in multisocket mode, because
                     * otherwise we would already have a call_socket.  This call can not
                     * succeed, but does not affect any of our other calls. We do decrement
                 * the reconnection counter however. */
                if (reset_number != -1) {
                    reset_number--;
                }

                computeStat(CStat::E_CALL_FAILED);
                computeStat(CStat::E_FAILED_TCP_CONNECT);
                delete this;

                return false;
            } else {
                if(errno == EINVAL) {
                    /* This occurs sometime on HPUX but is not a true INVAL */
                    ERROR("Unable to connect a TCP/SCTP/TLS socket, remote peer error");
                } else {
                    ERROR_NO("Unable to connect a TCP/SCTP/TLS socket");
                }
            }
        }
        call_port = call_socket->ss_port;
    }
    return true;
}

bool call::lost(int index)
{
    double percent = global_lost;

    if(!lose_packets) return false;

    if (call_scenario->messages[index]->lost >= 0) {
        percent = call_scenario->messages[index]->lost;
    }

    if (percent == 0) {
        return false;
    }

    return (((double)rand() / (double)RAND_MAX) < (percent / 100.0));
}

int call::send_raw(const char * msg, int index, int len)
{
    SIPpSocket *sock;
    int rc;

    callDebug("Sending %s message for call %s (index %d, hash %lu):\n%s\n\n",
              TRANSPORT_TO_STRING(transport), id, index, hash(msg), msg);

    if((index!=-1) && (lost(index))) {
        TRACE_MSG("%s message voluntary lost (while sending).", TRANSPORT_TO_STRING(transport));
        callDebug("%s message voluntary lost (while sending) (index %d, hash %lu).\n",
                  TRANSPORT_TO_STRING(transport), index, hash(msg));

        call_scenario->messages[index] -> nb_lost++;
        return 0;
    }

    sock = call_socket;

    if ((use_remote_sending_addr) && (sendMode == MODE_SERVER)) {
        if (!call_remote_socket) {
            if (multisocket || !main_remote_socket) {
                struct sockaddr_storage *L_dest = &remote_sending_sockaddr;

                if((call_remote_socket= new_sipp_socket(use_ipv6, transport)) == nullptr) {
                    ERROR_NO("Unable to get a socket for rsa option");
                }

                sipp_customize_socket(call_remote_socket);

                if(transport != T_UDP) {
                    if (call_remote_socket->connect(L_dest)) {
                        if(errno == EINVAL) {
                            /* This occurs sometime on HPUX but is not a true INVAL */
                            ERROR("Unable to connect a %s socket for rsa option, remote peer error", TRANSPORT_TO_STRING(transport));
                        } else {
                            ERROR_NO("Unable to connect a socket for rsa option");
                        }
                    }
                }
                if (!multisocket) {
                    main_remote_socket = call_remote_socket;
                }
            }

            if (!multisocket) {
                call_remote_socket = main_remote_socket;
                main_remote_socket->ss_count++;
            }
        }
        sock=call_remote_socket ;
    }

    // If the length hasn't been explicitly specified, treat the message as a string
    if (len==0) {
        len = strlen(msg);
    }

    assert(sock);

    /* A response to a request that came from elsewhere goes back there. */
    struct sockaddr_storage *dest = &call_peer;
    if (!peekCold().request_sources.empty() && !strncmp(msg, "SIP/2.0 ", 8)) {
        char branch[MAX_HEADER_LEN];
        extract_transaction(branch, sizeof(branch), msg);
        for (request_source &rs : cold_state->request_sources) {
            if (rs.branch == branch) {
                if (!rs.socket) {
                    dest = &rs.addr;
                } else if (rs.socket->ss_fd != -1) {
                    sock = rs.socket;
                }
                break;
            }
        }
    }

    /* A message of the scenario waits for the connection to be made
     * again, if it failed; one of our own reports the failure. */
    rc = sock->write(msg, len, index != -1 ? WS_BUFFER | WS_KEEP : WS_BUFFER, dest);
    if(rc < 0 && errno == EWOULDBLOCK) {
        return rc;
    }

    /* A message of our own (index -1) is sent by code that carries on
     * with the call, so it stays; sendBuffer() reports the failure. */
    if(rc < 0 && index != -1) {
        computeStat(CStat::E_CALL_FAILED);
        computeStat(CStat::E_FAILED_CANNOT_SEND_MSG);
        delete this;
    }

    return rc; /* OK */
}

/* This method is used to send messages that are not */
/* part of the XML scenario                          */
void call::sendBuffer(char * msg, int len)
{
    /* call send_raw but with a special scenario index */
    if (send_raw(msg, -1, len) < 0) {
        if (sendbuffer_warn) {
            ERROR_NO("Error sending raw message");
        } else {
            WARNING_NO("Error sending raw message");
        }
    }
}

/* The header of name, "From" or "From:", of the last message received, or
 * nothing when none was */
header_value call::get_last_header(std::string_view name)
{
    if (last_recv_msg.empty()) {
        return header_value();
    }

    /* Ideally this check should be moved to the XML parser so that it is not
     * along a critical path.  We could also handle lowercasing there. */
    if (name.size() > MAX_HEADER_LEN) {
        ERROR("call::get_last_header: Header to parse bigger than %d (%zu)", MAX_HEADER_LEN, name.size());
    }

    if (!name.empty() && name.back() == ':') {
        return get_header(last_recv_msg.c_str(), name, false);
    }
    char with_colon[MAX_HEADER_LEN + 1];
    memcpy(with_colon, name.data(), name.size());
    with_colon[name.size()] = ':';
    return get_header(last_recv_msg.c_str(), std::string_view(with_colon, name.size() + 1), false);
}

/* Return the last request URI from the To header. On any error returns the
 * empty string. */
std::string call::get_last_request_uri()
{
    const header_value last_To = get_last_header("To:");
    const std::string_view to = last_To.view();
    const size_t begin = to.find('<');
    const size_t end = to.find('>', begin);
    if (begin == std::string_view::npos || end == std::string_view::npos) {
        return "";
    }

    return std::string(to.substr(begin + 1, end - begin - 1));
}

char * call::send_scene(int index, int *send_status, int *len)
{
#define MAX_MSG_NAME_SIZE 30
    static char msg_name[MAX_MSG_NAME_SIZE];
    char *L_ptr1 ;
    char *L_ptr2 ;
    int uselen = 0;

    assert(send_status);

    /* Socket port must be known before string substitution */
    if (!connect_socket_if_needed()) {
        *send_status = -2;
        return nullptr;
    }

    if (!call_socket) {
        ERROR("Call '%s' has no socket to send on: a call that a 3PCC command "
              "creates in a scenario starting with a <recv> needs a remote host",
              id);
    }

    assert(call_scenario->messages[index]->send_scheme);

    if (!len) {
        len = &uselen;
    }

    char * dest;
    dest = createSendingMessage(call_scenario->messages[index]->send_scheme, index, len);

    if (!dest) {
        *send_status = -2;
        return nullptr;
    }

    L_ptr1=msg_name ;
    L_ptr2=dest ;
    while ((*L_ptr2 != ' ') && (*L_ptr2 != '\n') && (*L_ptr2 != '\t'))  {
        *L_ptr1 = *L_ptr2;
        L_ptr1 ++;
        L_ptr2 ++;
    }
    *L_ptr1 = '\0' ;

    if (strcmp(msg_name, "ACK") == 0) {
        call_established = true ;
        ack_is_pending = false ;
    }

    *send_status = send_raw(dest, index, *len);

    return dest;
}

void call::do_bookkeeping(message *curmsg)
{
    /* If this message increments a counter, do it now. */
    if (curmsg -> counter) {
        computeStat(CStat::E_ADD_GENERIC_COUNTER, 1, curmsg->counter - 1);
    }

    if (curmsg->start_rtd.empty() && curmsg->stop_rtd.empty()) {
        return;
    }

    /* If this message can be used to compute RTD, do it now, at the same
     * time for all its timers */
    unsigned long long now = getmicroseconds();
    for (int rtd : curmsg->start_rtd) {
        start_time_rtd[rtd - 1] = now;
    }

    for (int rtd : curmsg->stop_rtd) {
        if (!rtd_done[rtd - 1]) {
            unsigned long long start = start_time_rtd[rtd - 1];
            unsigned long long end = now;

            if (dumpInRtt) {
                call_scenario->stats->computeRtt(start, end, rtd);
            }

            computeStat(CStat::E_ADD_RESPONSE_TIME_DURATION,
                        (end - start) / 1000, rtd - 1);

            if (!curmsg->repeat_rtd) {
                rtd_done[rtd - 1] = true;
            }
        }
    }
}

/* Its connection failed and was made again, with the calls kept: a
 * request that the old one took, with no response yet, may have been
 * lost with it, and goes on the new one (see
 * SIPpSocket::resume_calls()). */
void call::tcpReconnected()
{
    if (last_send_unanswered) {
        callDebug("Sending the unanswered request again on a new connection\n");
        send_raw(last_send_msg.c_str(), last_send_index, last_send_msg.size());
    }
}

bool call::tcpClose()
{
    /* A call whose next step is its <timewait> is done, even if it has not
     * run that step yet: the peer closing the connection after the last
     * message (a client exiting after its final 200, say) ends it
     * successfully, as it does once the timewait has started. */
    msgvec *msgs = initCall ? &call_scenario->initmessages : &call_scenario->messages;
    if (msg_index >= 0 && msg_index < (int)msgs->size() && (*msgs)[msg_index]->timewait) {
        timewait = true;
    }
    bool failed = last_action_result != E_AR_NO_ERROR || !timewait;
    terminate(CStat::E_FAILED_TCP_CLOSED);
    return failed;
}

int call::close_twin_calls()
{
    /* No call uses the twin connection as its socket, but a call waiting
     * at a <recvCmd> waits for a command it would have brought: it fails
     * as a call on a closed TCP connection does. */
    std::vector<call *> waiting;
    for (task *t : *get_all_tasks()) {
        call *c = dynamic_cast<call *>(t);
        if (c && !c->initCall && c->msg_index >= 0 &&
                c->msg_index < (int)c->call_scenario->messages.size() &&
                c->call_scenario->messages[c->msg_index]->M_type == MSG_TYPE_RECVCMD) {
            waiting.push_back(c);
        }
    }

    int failed = 0;
    for (call *c : waiting) {
        if (c->tcpClose()) {
            failed++;
        }
    }
    return failed;
}

void call::terminate(CStat::E_Action reason)
{
    const char *dead_reason = nullptr; /* of the dead call to leave */

    stopListening();

    // Call end -> was it successful?
    if(call::last_action_result != call::E_AR_NO_ERROR) {
        switch(call::last_action_result) {
        case call::E_AR_REGEXP_DOESNT_MATCH:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_REGEXP_DOESNT_MATCH);
            if (deadcall_wait && !initCall) {
                dead_reason = "regexp match failure at index %d";
            }
            break;
        case call::E_AR_REGEXP_SHOULDNT_MATCH:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_REGEXP_SHOULDNT_MATCH);
            if (deadcall_wait && !initCall) {
                dead_reason = "regexp matched, but shouldn't at index %d";
            }
            break;
        case call::E_AR_HDR_NOT_FOUND:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_REGEXP_HDR_NOT_FOUND);
            if (deadcall_wait && !initCall) {
                dead_reason = "regexp header not found at index %d";
            }
            break;
        case E_AR_CONNECT_FAILED:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_TCP_CONNECT);
            if (deadcall_wait && !initCall) {
                dead_reason = "connection failed %d";
            }
            break;
        case E_AR_RTPECHO_ERROR:
            computeStat(CStat::E_CALL_FAILED);
            setRtpEchoErrors(1);
            if (deadcall_wait && !initCall) {
                dead_reason = "rtp echo error %d";
            }
            break;
        case E_AR_VERIFY_FAILED:
            computeStat(CStat::E_CALL_FAILED);
            if (deadcall_wait && !initCall) {
                dead_reason = "exec verify failure at index %d";
            }
            break;
        case call::E_AR_NO_ERROR:
        case call::E_AR_STOP_CALL:
            /* Do nothing. */
            break;
        case call::E_AR_TEST_DOESNT_MATCH:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_TEST_DOESNT_MATCH);
            if (deadcall_wait && !initCall) {
                dead_reason = "test failure at index %d";
            }
            break;
        case call::E_AR_TEST_SHOULDNT_MATCH:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_TEST_SHOULDNT_MATCH);
            if (deadcall_wait && !initCall) {
                dead_reason = "test succeeded, but shouldn't at index %d";
            }
            break;
        case call::E_AR_STRCMP_DOESNT_MATCH:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_STRCMP_DOESNT_MATCH);
            if (deadcall_wait && !initCall) {
                dead_reason = "test failure at index %d";
            }
            break;
        case call::E_AR_STRCMP_SHOULDNT_MATCH:
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_STRCMP_SHOULDNT_MATCH);
            if (deadcall_wait && !initCall) {
                dead_reason = "test succeeded, but shouldn't at index %d";
            }
            break;
        }
    } else {
        if (reason == CStat::E_CALL_SUCCESSFULLY_ENDED || timewait) {
            computeStat(CStat::E_CALL_SUCCESSFULLY_ENDED);
            if (deadcall_wait && !initCall) {
                dead_reason = "successful";
            }
        } else {
            computeStat(CStat::E_CALL_FAILED);
            if (reason != CStat::E_NO_ACTION) {
                computeStat(reason);
            }
            if (deadcall_wait && !initCall) {
                dead_reason = "failed at index %d";
            }
        }
    }

    if (dead_reason) {
        /* Made once the call is gone, the dead call takes the place of
         * what the call freed, as it has the same small allocations */
        std::string dead_id(id);
        std::vector<std::string> dead_ids = dialogIds();
        int dead_index = msg_index;
        delete this;
        new deadcall(dead_id.c_str(), dead_reason, dead_index);
        for (const std::string &dialog_id : dead_ids) {
            new deadcall(dialog_id.c_str(), dead_reason, dead_index);
        }
    } else {
        delete this;
    }
}

bool call::next()
{
    msgvec * msgs = &call_scenario->messages;
    if (initCall) {
        msgs = &call_scenario->initmessages;
    }

    int test;
    /* What is the next message index? */
    /* Default without branching: use the next message */
    int new_msg_index = msg_index + 1;
    /* If branch needed, overwrite this default */
    if (msg_index >= 0 && ((*msgs)[msg_index]->next >= 0) &&
            (((test = ((*msgs)[msg_index]->test)) == -1) ||
             M_callVariableTable->getVar(test)->isSet())) {
        /* Branching possible, check the probability */
        int chance = (*msgs)[msg_index]->chance;
        if ((chance <= 0) || (rand() > chance )) {
            /* Branch == overwrite with the 'next' attribute value */
            new_msg_index = (*msgs)[msg_index]->next;
        }
    }
    msg_index = new_msg_index;
    recv_timeout = 0;
    if (msg_index >= (int)((*msgs).size())) {
        if (verify_pending) {
            /* verifyDone() ends the call, which has nothing left to wait
             * for but the commands. */
            next_retrans = 0;
            rtpstream_wait_check = 0;
            setPaused();
            return true;
        }
        terminate(CStat::E_CALL_SUCCESSFULLY_ENDED);
        return false;
    }

    return true;
}

bool call::executeMessage(message *curmsg)
{
    T_ActionResult actionResult = E_AR_NO_ERROR;

    if (curmsg->pause_distribution || curmsg->pause_variable != -1) {
        unsigned int pause;
        if (curmsg->pause_distribution) {
            double actualpause = curmsg->pause_distribution->sample();
            if (actualpause < 1) {
                // Protect against distribution samples that give
                // negative results (and so pause for ~50 hours when
                // cast to a unsigned int).
                pause = 0;
            } else {
                pause  = (unsigned int)actualpause;
            };
        } else {
            int varId = curmsg->pause_variable;
            pause = (int) get_var_double(varId);
        }
        if (pause > INT_MAX) {
            pause = INT_MAX;
        }
        paused_until = clock_tick + pause;

        /* This state is used as the last message of a scenario, just for handling
         * final retransmissions. If the connection closes, we do not mark it is
         * failed. */
        this->timewait = curmsg->timewait;

        /* Increment the number of sessions in pause state */
        curmsg->sessions++;
        do_bookkeeping(curmsg);
        if (!handleActionResult(executeAction(nullptr, curmsg))) {
            return false; /* call deleted */
        }
        callDebug("Pausing call until %d (is now %ld).\n", paused_until, clock_tick);
        setPaused();
        return true;
    } else if(curmsg -> M_type == MSG_TYPE_SENDCMD) {
        int send_status;

        if(next_retrans) {
            return true;
        }

        send_status = sendCmdMessage(curmsg);

        if(send_status != 0) { /* Send error */
            return false; /* call deleted */
        }
        curmsg -> M_nbCmdSent++;
        next_retrans = 0;

        do_bookkeeping(curmsg);
        if (!handleActionResult(executeAction(nullptr, curmsg))) {
            return false; /* call deleted */
        }
        return(next());
    } else if(curmsg -> M_type == MSG_TYPE_NOP) {
        callDebug("Executing NOP at index %d.\n", curmsg->index);
        do_bookkeeping(curmsg);
        actionResult = executeAction(nullptr, curmsg);
        if (!handleActionResult(actionResult)) {
            return false; /* call deleted */
        }
        if (actionResult == E_AR_RTPECHO_ERROR)
        {
            terminate(CStat::E_CALL_FAILED);
            return false;
        }
        else
        {
            return next();
        }
    }

    else if(curmsg -> send_scheme) {
        char * msg_snd;
        int msgLen;
        int send_status;

        /* Do not send a new message until the previous one which had
         * retransmission enabled is acknowledged */

        if(next_retrans) {
            setPaused();
            return true;
        }

        if (dialogs) {
            switchDialog(msgDialog(curmsg));
        }

        /* Handle counters and RTDs for this message. */
        do_bookkeeping(curmsg);

        /* decide whether to increment cseq or not
         * basically increment for anything except response, ACK or CANCEL
         * Note that cseq is only used by the [cseq] keyword, and
         * not by default
         */

        int incr_cseq = 0;
        if (!curmsg->send_scheme->isAck() &&
                !curmsg->send_scheme->isCancel() &&
                !curmsg->send_scheme->isResponse()) {
            ++cseq;
            incr_cseq = 1;
        }

        /* A response in a transaction a received request started: the
         * [last_*] keywords are of that request. */
        txnInstanceInfo *answered = nullptr;
        if (curmsg->response_txn && !transactions[curmsg->response_txn - 1].request.empty()) {
            answered = &transactions[curmsg->response_txn - 1];
            std::swap(last_recv_msg, answered->request);
        }
        msg_snd = send_scene(msg_index, &send_status, &msgLen);
        if (!msg_snd) {
            /* The connection failed and connect_socket_if_needed() deleted
             * the call, so we should no longer access members. */
            return false;
        }
        if (send_status < 0 && errno != EWOULDBLOCK) { /* Send error */
            /* The call was already deleted by send_raw, so we should no
             * longer access members. */
            return false;
        }
        if (answered) {
            std::swap(last_recv_msg, answered->request);
        }

        if (send_status < 0) {
            if (incr_cseq) --cseq;
            /* Have we set the timeout yet? */
            if (send_timeout) {
                /* If we have actually timed out. */
                if (clock_tick > send_timeout) {
                    WARNING("Call-Id: %s, send timeout on message %s:%d: aborting call",
                            id, curmsg->desc, curmsg->index);
                    computeStat(CStat::E_CALL_FAILED);
                    computeStat(CStat::E_FAILED_TIMEOUT_ON_SEND);
                    if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
                        return (abortCall(true));
                    } else {
                        delete this;
                        return false;
                    }
                }
            } else if (curmsg->timeout) {
                /* Initialize the send timeout to the per message timeout. */
                send_timeout = clock_tick + curmsg->timeout;
            } else if (defl_send_timeout) {
                /* Initialize the send timeout to the global timeout. */
                send_timeout = clock_tick + defl_send_timeout;
            }
            return true; /* No step, nothing done, retry later */
        }
        /* We have sent the message, so the timeout is no longer needed. */
        send_timeout = 0;

        keepRecvRetransMsg();
        last_send_index = curmsg->index;
        assign_exact(last_send_msg, msg_snd, msgLen);
        /* Not one that waits for the connection to be made again: that
         * sends it (see SIPpSocket::keep()). */
        last_send_unanswered = !curmsg->send_scheme->isResponse() &&
                               !curmsg->send_scheme->isAck() &&
                               call_socket && call_socket->all_written();

        if (curmsg->start_txn) {
            char branch[MAX_HEADER_LEN];
            extract_transaction(branch, sizeof(branch), last_send_msg.c_str());
            transactions[curmsg->start_txn - 1].txnID = branch;
            transactions[curmsg->start_txn - 1].dialog = dialogs ? dialogs->current : 1;
        }
        if (dialogs && !dialogKnown(dialogs->current)) {
            /* A Call-ID written without [call_id] */
            const std::string_view sent_id = get_call_id(last_send_msg.c_str());
            if (!sent_id.empty()) {
                setDialogCallId(dialogs->current, sent_id);
            }
        }
        if (curmsg->ack_txn) {
            transactions[curmsg->ack_txn - 1].ackIndex = curmsg->index;
        }
        if (answered) {
            /* A retransmission of the request gets it again */
            assign_exact(answered->response, msg_snd, msgLen);
            answered->responseIndex = curmsg->index;
        }

        /* A response to an earlier request than the last received is
         * not what a retransmission of the last one should get. */
        if(last_recv_index >= 0 && last_recv_hash &&
                (!answered || answered->requestHash == last_recv_hash)) {
            /* We are sending just after msg reception. There is a great
             * chance that we will be asked to retransmit this message */
            recv_retrans_hash       = last_recv_hash;
            recv_retrans_recv_index = last_recv_index;
            recv_retrans_send_index = curmsg->index;
            /* Only UDP retransmissions of the request get it again. */
            if (transport == T_UDP && retrans_enabled) {
                release(recv_retrans_msg);
                recv_retrans_last = true;
            }

            callDebug("Set Retransmission Hash: %lu (recv index %d, send index %d)\n",
                      recv_retrans_hash, recv_retrans_recv_index, recv_retrans_send_index);

            /* Prevent from detecting the cause relation between send and recv
             * in the next valid send */
            last_recv_hash = 0;
        } else if (last_recv_index >= 0 && recv_retrans_recv_index == last_recv_index &&
                   call_scenario->messages[last_recv_index]->recv_request && curmsg->send_scheme->isResponse() &&
                   same_cseq(last_send_msg.c_str(), last_recv_msg.c_str())) {
            /* A later response to the same request (a 200 after a 180): a
             * retransmission of the request gets the most recent one. A
             * response to another request, such as the 200 of an INVITE
             * sent after the 200 of a PRACK, is not one. */
            recv_retrans_send_index = curmsg->index;
            if (transport == T_UDP && retrans_enabled) {
                release(recv_retrans_msg);
                recv_retrans_last = true;
            }
        }

        /* Update retransmission information */
        if(curmsg -> retrans_delay) {
            if((transport == T_UDP) && (retrans_enabled)) {
                next_retrans = clock_tick + curmsg -> retrans_delay;
                nb_retrans = 0;
                nb_last_delay = curmsg->retrans_delay;
            }
        } else {
            next_retrans = 0;
        }

        /* Update scenario statistics */
        curmsg -> nb_sent++;

        if (!handleActionResult(executeAction(msg_snd, curmsg))) {
            return false; /* call deleted */
        }

        return next();
    } else if (curmsg->M_type == MSG_TYPE_RECV
               || curmsg->M_type == MSG_TYPE_RECVCMD
              ) {
        if (curmsg->M_type == MSG_TYPE_RECVCMD && !peekCold().queued_cmd.empty()) {
            std::string cmd = std::exchange(cold_state->queued_cmd, std::string());
            return process_twinSippCom(cmd.data());
        } else if (!peekCold().queued_msg.empty()) {
            std::string msg = std::exchange(cold_state->queued_msg, std::string());
            return process_incoming(msg.c_str(), nullptr, nullptr, cold_state->queued_sdp_read);
        } else if (recv_timeout) {
            if(recv_timeout > getmilliseconds()) {
                setPaused();
                return true;
            }
            recv_timeout = 0;
            curmsg->nb_timeout++;
            if (curmsg->on_timeout < 0) {
                // if you set a timeout but not a label, the call is aborted
                WARNING("Call-Id: %s, receive timeout on message %s:%d without label to jump to (ontimeout attribute): aborting call",
                        id, curmsg->desc, curmsg->index);
                computeStat(CStat::E_CALL_FAILED);
                computeStat(CStat::E_FAILED_TIMEOUT_ON_RECV);
                if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
                    return (abortCall(true));
                } else {
                    delete this;
                    return false;
                }
            }
            WARNING("Call-Id: %s, receive timeout on message %s:%d, jumping to label %d",
                    id, curmsg->desc, curmsg->index, curmsg->on_timeout);
            /* FIXME: We should do something like set index here, but it probably
             * does not matter too much as only nops are allowed in the init stanza. */
            msg_index = curmsg->on_timeout;
            recv_timeout = 0;
            if (msg_index < (int)call_scenario->messages.size()) return true;
            // special case - the label points to the end - finish the call
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_TIMEOUT_ON_RECV);
            if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
                return (abortCall(true));
            } else {
                delete this;
                return false;
            }
        } else if (unsigned int timeout = recvTimeout(curmsg); timeout || defl_recv_timeout) {
            if (timeout)
                // If timeout is specified on message receive, use it
                recv_timeout = getmilliseconds() + timeout;
            else
                // Else use the default timeout if specified
                recv_timeout = getmilliseconds() + defl_recv_timeout;
            return true;
        } else {
            /* We are going to wait forever. */
            setPaused();
        }
    } else {
        WARNING("Unknown message type at %s:%d: %d", curmsg->desc, curmsg->index, curmsg->M_type);
    }
    return true;
}

bool call::run()
{
    bool            bInviteTransaction = false;

    assert(running);

    if (zombie) {
        delete this;
        return false;
    }

    update_clock_tick();

    if (verify_pending && pastLastMessage()) {
        setPaused();
        return true;
    }

    message *curmsg;
    if (initCall) {
        if(msg_index >= (int)call_scenario->initmessages.size()) {
            ERROR("Scenario initialization overrun for call %s (%p) (index = %d)", id, _RCAST(void*, this), msg_index);
        }
        curmsg = call_scenario->initmessages[msg_index];
    } else {
        if(msg_index >= (int)call_scenario->messages.size()) {
            ERROR("Scenario overrun for call %s (%p) (index = %d)", id, _RCAST(void*, this), msg_index);
        }
        curmsg = call_scenario->messages[msg_index];
    }

    callDebug("Processing message %d of type %d for call %s at %lu.\n", msg_index, curmsg->M_type, id, clock_tick);

    if (curmsg->condexec != -1) {
        bool exec = M_callVariableTable->getVar(curmsg->condexec)->isSet();
        if (curmsg->condexec_inverse) {
            exec = !exec;
        }
        if (!exec) {
            callDebug("Conditional variable %s %s set, so skipping message %d.\n", call_scenario->allocVars->getName(curmsg->condexec), curmsg->condexec_inverse ? "" : "not", msg_index);
            return next();
        }
    }

    /* Manages retransmissions or delete if max retrans reached */
    if(next_retrans && (next_retrans < clock_tick)) {
        nb_retrans++;

        if ((0 == strncmp(last_send_msg.c_str(), "INVITE", 6))) {
            bInviteTransaction = true;
        }

        int rtAllowed = std::min(bInviteTransaction ? max_invite_retrans : max_non_invite_retrans, max_udp_retrans);

        callDebug("Retransmission required (%d retransmissions, max %d)\n", nb_retrans, rtAllowed);

        if(nb_retrans > rtAllowed) {
            call_scenario->messages[last_send_index] -> nb_timeout ++;
            if (call_scenario->messages[last_send_index]->on_timeout >= 0) {  // action on timeout
                WARNING("Call-Id: %s, timeout on max UDP retrans for message %d, jumping to label %d ",
                        id, msg_index, call_scenario->messages[last_send_index]->on_timeout);
                msg_index = call_scenario->messages[last_send_index]->on_timeout;
                next_retrans = 0;
                recv_timeout = 0;
                if (msg_index < (int)call_scenario->messages.size()) {
                    return true;
                }

                // here if asked to go to the last label  delete the call
                computeStat(CStat::E_CALL_FAILED);
                computeStat(CStat::E_FAILED_MAX_UDP_RETRANS);
                if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
                    // Abort the call by sending proper SIP message
                    return(abortCall(true));
                } else {
                    // Just delete existing call
                    delete this;
                    return false;
                }
            }
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_MAX_UDP_RETRANS);
            if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
                // Abort the call by sending proper SIP message
                WARNING("Aborting call on UDP retransmission timeout for Call-ID '%s'", id);
                return(abortCall(true));
            } else {
                // Just delete existing call
                delete this;
                return false;
            }
        } else {
            nb_last_delay *= 2;
            if (global_t2 < nb_last_delay) {
                if (!bInviteTransaction) {
                    nb_last_delay = global_t2;
                }
            }
            if (send_raw(last_send_msg.c_str(), last_send_index, last_send_msg.size()) < 0) {
                return false;
            }
            call_scenario->messages[last_send_index] -> nb_sent_retrans++;
            computeStat(CStat::E_RETRANSMISSION);
            next_retrans = clock_tick + nb_last_delay;
        }
    }

    if(paused_until) {
        /* Process a pending pause instruction until delay expiration */
        if(paused_until > clock_tick) {
            callDebug("Call is paused until %d (now %ld).\n", paused_until, clock_tick);
            setPaused();
            callDebug("Running: %d (wake %d).\n", running, wake());
            return true;
        }
        /* Our pause is over. */
        callDebug("Pause complete, waking up.\n");
        paused_until = 0;
        return next();
    }

    if (rtpstream_wait_check) {
        /* Hold the next message until the rtp_stream playback is over */
        unsigned long play_end = rtpstream_play_end(&rtpstream_callinfo);
        if (!play_end) {
            callDebug("rtp_stream playback over, waking up.\n");
            rtpstream_wait_check = 0;
        } else if (rtpstream_wait_until && rtpstream_wait_until <= clock_tick) {
            return rtpstreamWaitTimeout();
        } else {
            rtpstreamWaitNextCheck(play_end);
            setPaused();
            return true;
        }
    }

    if (verify_pending) {
        /* Hold the next message until verifyDone() wakes the call */
        callDebug("Waiting for %d exec verify commands.\n", verify_pending);
        setPaused();
        return true;
    }
    return executeMessage(curmsg);
}

const char *default_message_names[] = {
    "3pcc_abort",
    "ack",
    "ack2",
    "bye",
    "cancel",
    "200",
};
std::string default_message_strings[] = {
    /* 3pcc_abort */
    "call-id: [call_id]\ninternal-cmd: abort_call\n\n",
    /* ack */
    "ACK [last_Request_URI] SIP/2.0\n"
    "[last_Via]\n"
    "[last_From]\n"
    "[last_To]\n"
    "Call-ID: [call_id]\n"
    "CSeq: [last_cseq_number] ACK\n"
    "Contact: <sip:sipp@[local_ip]:[local_port];transport=[transport]>\n"
    "Max-Forwards: 70\n"
    "Subject: Performance Test\n"
    "Content-Length: 0\n\n",
    /* ack2, the only difference is Via, I don't quite know why. */
    "ACK [last_Request_URI] SIP/2.0\n"
    "Via: SIP/2.0/[transport] [local_ip]:[local_port];branch=[branch]\n"
    "[last_From]\n"
    "[last_To]\n"
    "Call-ID: [call_id]\n"
    "CSeq: [last_cseq_number] ACK\n"
    "Contact: <sip:sipp@[local_ip]:[local_port];transport=[transport]>\n"
    "Max-Forwards: 70\n"
    "Subject: Performance Test\n"
    "Content-Length: 0\n\n",
    /* bye */
    "BYE [next_url] SIP/2.0\n"
    "Via: SIP/2.0/[transport] [local_ip]:[local_port];branch=[branch]\n"
    "[routes]\n"
    "[last_From]\n"
    "[last_To]\n"
    "Call-ID: [call_id]\n"
    "CSeq: [last_cseq_number+1] BYE\n"
    "Max-Forwards: 70\n"
    "Contact: <sip:sipp@[local_ip]:[local_port];transport=[transport]>\n"
    "Content-Length: 0\n\n",
    /* cancel */
    "CANCEL [last_Request_URI] SIP/2.0\n"
    "[last_Via]\n"
    "[last_From]\n"
    "[last_To]\n"
    "Call-ID: [call_id]\n"
    "CSeq: [last_cseq_number] CANCEL\n"
    "Max-Forwards: 70\n"
    "Contact: <sip:sipp@[local_ip]:[local_port];transport=[transport]>\n"
    "Content-Length: 0\n\n",
    /* 200 */
    "SIP/2.0 200 OK\n"
    "[last_Via:]\n"
    "[last_From:]\n"
    "[last_To:]\n"
    "[last_Call-ID:]\n"
    "[last_CSeq:]\n"
    "Contact: <sip:[local_ip]:[local_port];transport=[transport]>\n"
    "Content-Length: 0\n\n"};

SendingMessage **default_messages;

void init_default_messages()
{
    int messages = sizeof(default_message_strings)/sizeof(default_message_strings[0]);
    default_messages = new SendingMessage* [messages];
    for (int i = 0; i < messages; i++) {
        default_messages[i] = new SendingMessage(main_scenario, default_message_strings[i].c_str());
    }
}

void free_default_messages()
{
    int messages = sizeof(default_message_strings)/sizeof(default_message_strings[0]);
    if (!default_messages) {
        return;
    }
    for (int i = 0; i < messages; i++) {
        delete default_messages[i];
    }
    delete [] default_messages;
}

SendingMessage *get_default_message(const char *which)
{
    int messages = sizeof(default_message_names)/sizeof(default_message_names[0]);
    for (int i = 0; i < messages; i++) {
        if (!strcmp(which, default_message_names[i])) {
            return default_messages[i];
        }
    }
    ERROR("Internal Error: Unknown default message: %s!", which);
}

void set_default_message(const char *which, std::string msg)
{
    int messages = sizeof(default_message_names)/sizeof(default_message_names[0]);
    for (int i = 0; i < messages; i++) {
        if (!strcmp(which, default_message_names[i])) {
            default_message_strings[i] = std::move(msg);
            return;
        }
    }
    ERROR("Internal Error: Unknown default message: %s!", which);
}

bool call::process_unexpected(const char* msg)
{
    std::ostringstream sb;
    int res = 0;

    message *curmsg = call_scenario->messages[msg_index];

    curmsg->nb_unexp++;

    if (default_behaviors & DEFAULT_BEHAVIOR_ABORTUNEXP) {
        sb << "Aborting ";
    } else {
        sb << "Continuing ";
    }
    sb << "call on unexpected message for Call-Id '" << id << "': ";

    if (curmsg -> M_type == MSG_TYPE_RECV) {
        if (curmsg -> recv_request) {
            sb << "while expecting '" << *curmsg->recv_request << "' ";
        } else {
            sb << "while expecting '" << curmsg->recv_response.value_or("") << "' ";
        }
    } else if (curmsg -> M_type == MSG_TYPE_SEND) {
        sb << "while sending ";
    } else if (curmsg -> M_type == MSG_TYPE_PAUSE) {
        sb << "while pausing ";
    } else if (curmsg -> M_type == MSG_TYPE_SENDCMD) {
        sb << "while sending command ";
    } else if (curmsg -> M_type == MSG_TYPE_RECVCMD) {
        sb << "while expecting command ";
    } else {
        sb << "while in message type " << curmsg->M_type << " ";
    }
    sb << "(index " << msg_index << ")";

    WARNING("%s, received '%s'", sb.str().c_str(), msg);

    TRACE_MSG("-----------------------------------------------\n"
              "Unexpected %s message received:\n\n%s\n",
              TRANSPORT_TO_STRING(transport),
              msg);

    callDebug("Unexpected %s message received (index %d, hash %lu):\n\n%s\n",
              TRANSPORT_TO_STRING(transport), msg_index, hash(msg), msg);

    if (get_reply_code(msg)) {
        this->call_scenario->stats->error_codes.push_back(get_reply_code(msg));
    }

    if (default_behaviors & DEFAULT_BEHAVIOR_ABORTUNEXP) {
        // if twin socket call => reset the other part here
        if (twinSippSocket && (msg_index > 0)) {
            res = sendCmdBuffer(createSendingMessage(get_default_message("3pcc_abort")));
            if (res < 0) {
                WARNING("sendCmdBuffer returned %d", res);
                return false;
            }
        }

        // usage of last_ keywords => for call aborting
        assign_exact(last_recv_msg, msg);

        computeStat(CStat::E_CALL_FAILED);
        computeStat(CStat::E_FAILED_UNEXPECTED_MSG);
        if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
            return (abortCall(true));
        } else {
            delete this;
            return false;
        }
    } else {
        // Do not abort call nor send anything in reply if default behavior is disabled
        return false;
    }
}

void call::abort()
{
    computeStat(CStat::E_CALL_FAILED);
    WARNING("Aborted call with Call-ID '%s'", id);
    abortCall(false);
}

/* Does this call send the request that creates its dialog? Only then does
 * an abort end the dialog. It is the call's and not the process's role: a
 * 3PCC controller B takes commands like a server, but sends the INVITE. */
bool call::createsDialog()
{
    for (message *m : call_scenario->messages) {
        if (m->M_type == MSG_TYPE_RECV) {
            return false;
        } else if (m->send_scheme) {
            return !m->send_scheme->isResponse();
        }
    }
    return false;
}

bool call::abortCall(bool writeLog)
{
    int is_inv;
    bool sent_bye = false, sent_cancel = false;

    callDebug("Aborting call %s (index %d).\n", id, msg_index);

    is_inv = !strncmp(last_send_msg.c_str(), "INVITE", 6);
    /* The BYE starts a transaction of its own: its [branch] is that of an
     * index no step has, not that of the step before it, which would be
     * the ACK's after a 2xx. */
    int byeIndex = call_scenario->messages.size();

    if (createsDialog() && (msg_index > 0)) {
        if ((call_established == false) && (is_inv)) {
            // Answer unexpected errors (4XX, 5XX and beyond) with an ACK
            // Contributed by F. Tarek Rogers
            if (!last_recv_msg.empty() && (get_reply_code(last_recv_msg.c_str()) >= 400)) {
                sendBuffer(createSendingMessage(get_default_message("ack")));
            } else if (!last_recv_msg.empty()) {
                /* Call is not established and the reply is not a 4XX, 5XX */
                /* And we already received a message. */
                if (ack_is_pending == true) {
                    /* If an ACK is expected from the other side, send it
                     * and send a BYE afterwards. */
                    ack_is_pending = false;
                    sendBuffer(createSendingMessage(get_default_message("ack")));

                    /* Send the BYE */
                    sendBuffer(createSendingMessage(get_default_message("bye"), byeIndex));
                    sent_bye = true;
                } else {
                    /* Send a CANCEL */
                    sendBuffer(createSendingMessage(get_default_message("cancel")));
                    sent_cancel = true;
                }
            } else {
                /* Call is not established and the reply is not a 4XX, 5XX */
                /* and we didn't received any message. This is the case when */
                /* we are aborting after having send an INVITE and not received */
                /* any answer. */
                /* Do nothing ! */
            }
        } else if (!last_recv_msg.empty()) {
            /* The call may not be established, if we haven't yet received a message,
             * because the earlier check depends on the first message being an INVITE
             * (although it could be something like a message message, therefore we
             * check that we received a message. */
            /* The peer's own request has its From and To the other way
             * round from ours, and a CSeq of the peer's. */
            bye_after_peer_request = !get_reply_code(last_recv_msg.c_str());
            sendBuffer(createSendingMessage(get_default_message("bye"), byeIndex));
            sent_bye = true;
        }
    }

    if (writeLog && useCallDebugf) {
        TRACE_CALLDEBUG ("-------------------------------------------------------------------------------\n");
        TRACE_CALLDEBUG ("Call debugging information for call %s:\n", id);
        TRACE_CALLDEBUG("%s", peekCold().debugBuffer.c_str());
    }

    stopListening();
    if (deadcall_wait && !initCall) {
        /* made once the call is gone, as in terminate() */
        std::string dead_id(id);
        std::vector<std::string> dead_ids = dialogIds();
        int dead_index = msg_index;
        delete this;
        new deadcall(dead_id.c_str(), "aborted at index %d", dead_index, sent_bye, sent_cancel);
        for (const std::string &dialog_id : dead_ids) {
            new deadcall(dialog_id.c_str(), "aborted at index %d", dead_index, sent_bye, sent_cancel);
        }
    } else {
        delete this;
    }

    return false;
}

bool call::rejectCall()
{
    computeStat(CStat::E_CALL_FAILED);
    computeStat(CStat::E_FAILED_CALL_REJECTED);
    delete this;
    return false;
}


int call::sendCmdMessage(message *curmsg)
{
    char * dest;
    char delimitor[2];
    delimitor[0]=27;
    delimitor[1]=0;

    /* 3pcc extended mode */
    SIPpSocket **peer_socket;

    if(curmsg -> M_sendCmdData) {
        // WARNING("---PREPARING_TWIN_CMD---%s---", scenario[index] -> M_sendCmdData);
        dest = createSendingMessage(curmsg->M_sendCmdData);
        strcat(dest, delimitor);
        //WARNING("---SEND_TWIN_CMD---%s---", dest);

        int rc;

        /* 3pcc extended mode */
        if (!curmsg->peer_dest.empty()) {
            peer_socket = get_peer_socket(curmsg->peer_dest.c_str());
            rc = (*peer_socket)->write(dest, strlen(dest), WS_BUFFER, &call_peer);
        } else if (twinSippSocket) {
            rc = twinSippSocket->write(dest, strlen(dest), WS_BUFFER, &call_peer);
        } else {
            /* Controller B until A connects again, or A once B ended. */
            WARNING("Unable to send TCP message: %s", strerror(ENOTCONN));
            nb_net_send_errors++;
            rc = -1;
        }
        if(rc <  0) {
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_CMD_NOT_SENT);
            delete this;
            return(-1);
        }

        return(0);
    } else
        return(-1);
}


int call::sendCmdBuffer(char* cmd)
{
    char * dest;
    char delimitor[2];
    int  rc;

    delimitor[0]=27;
    delimitor[1]=0;

    dest = cmd ;

    strcat(dest, delimitor);

    rc = twinSippSocket->write(dest, strlen(dest), WS_BUFFER, &twinSippSocket->ss_dest);
    if(rc <  0) {
        computeStat(CStat::E_CALL_FAILED);
        computeStat(CStat::E_FAILED_CMD_NOT_SENT);
        delete this;
        return(-1);
    }

    return(0);
}


char* call::createSendingMessage(SendingMessage *src, int P_index, int *msgLen)
{
    static char msg_buffer[SIPP_MAX_MSG_SIZE+2];
    /* Keep one byte spare: sendCmdMessage() and sendCmdBuffer() strcat() a
     * one-character delimiter onto the rendered message. */
    return createSendingMessage(src, P_index, msg_buffer, sizeof(msg_buffer) - 1, msgLen);
}

char* call::createSendingMessage(SendingMessage *src, int P_index, char *msg_buffer, int buf_len, int *msgLen)
{
    /* Room for most messages, rather than growing it a piece at a time */
    const std::string out = buildSendingMessage(src, P_index, msg_buffer, buf_len, 2048);
    memcpy(msg_buffer, out.c_str(), out.size() + 1);
    if (msgLen) {
        *msgLen = out.size();
    }
    return msg_buffer;
}

std::string call::createSendingString(SendingMessage *src, int P_index)
{
    /* Not the buffer createSendingMessage() returns, which holds the
     * message sent while its actions run. */
    static char scratch[SIPP_MAX_MSG_SIZE + 1];
    return buildSendingMessage(src, P_index, scratch, sizeof(scratch), 0);
}

/* The message, cut to buf_len - 1 bytes. The keywords that fill a char
 * buffer use scratch, of buf_len bytes. */
std::string call::buildSendingMessage(SendingMessage *src, int P_index, char *scratch, int buf_len, size_t reserve)
{
    const size_t max_len = buf_len - 1;
    std::string out;
    out.reserve(std::min(max_len, reserve));
    size_t length_marker = std::string::npos;
    size_t auth_marker = std::string::npos;
    MessageComponent *auth_comp = nullptr;
    bool auth_comp_allocated = false;
    int    len_offset = 0;
    bool suppresscrlf = false;

    bool srtp_audio_updated = false;
    bool srtp_video_updated = false;

    // OUTGOING SRTP PARAM CONTEXT
    SrtpInfoParams pA;
    SrtpInfoParams pV;

    /* Set wherever a keyword is cut short to fit; the size check after the
     * loop catches the rest. */
    bool truncated = false;
    int i = 0;
    for (; i < src->numComponents() && out.size() < max_len; i++) {
        MessageComponent *comp = src->getComponent(i);
        switch(comp->type) {
        case E_Message_Literal:
            if (suppresscrlf) {
                const char *ptr = comp->literal.c_str();
                while (isspace(*ptr)) ptr++;
                out += ptr;
                suppresscrlf = false;
            } else {
                out += comp->literal;
            }
            break;
        case E_Message_Remote_IP:
            out += remote ? remote->ip_w_brackets : remote_ip_w_brackets;
            break;
        case E_Message_Remote_Host:
            out += remote_host;
            break;
        case E_Message_Remote_Port:
            append_number(out, remote_port + comp->offset);
            break;
        case E_Message_Local_IP:
            out += local_ip_w_brackets;
            break;
        case E_Message_Local_Port:
            int port;
            if((multisocket) && (sendMode != MODE_SERVER)) {
                port = call_port;
            } else {
                port =  local_port;
            }
            append_number(out, port + comp->offset);
            break;
        case E_Message_Transport:
            out += TRANSPORT_TO_STRING(transport);
            break;
        case E_Message_Local_IP_Type:
            out += (local_ip_is_ipv6 ? "6" : "4");
            break;
        case E_Message_Server_IP: {
            /* We should do this conversion once per socket creation, rather than
             * repeating it every single time. */
            struct sockaddr_storage server_sockaddr;

            sipp_socklen_t len = sizeof(server_sockaddr);
            if (getsockname(call_socket->ss_fd,
                            (sockaddr *)(void *)&server_sockaddr, &len) < 0) {
                ERROR_NO("Unable to get the socket name");
            }

            char address[INET6_ADDRSTRLEN];
            if (int err = getnameinfo(_RCAST(sockaddr*, &server_sockaddr), len, address, sizeof(address),
                                      nullptr, 0, NI_NUMERICHOST)) {
                ERROR("Unable to get socket name information: %s", gai_strerror(err));
            }

            out += address;
        }
        break;
        case E_Message_Media_IP:
            out += media_ip;
            break;
        case E_Message_Auto_Media_Port:
        case E_Message_Media_Port: {
            int port = media_port + comp->offset;
            if (comp->type == E_Message_Auto_Media_Port) {
                port += (4 * (number - 1)) % 10000;
            }
#ifdef PCAPPLAY
            // Outside a message, e.g. in a <log>, the text is one line.
            const size_t line_start = out.rfind('\n');
            const char *begin = out.c_str() +
                (line_start == std::string::npos ? 0 : line_start);
            play_args_t* play_args = nullptr;
            rtpstream_pcap_t stream = RTPSTREAM_PCAP_AUDIO;
            if (!hasMedia || !pcap_plays) {
                /* The port of a pcap play, which a scenario without media
                 * or pcap plays has none of */
            } else if (strstr(begin, "audio")) {
                play_args = &playArgs(RTPSTREAM_PCAP_AUDIO);
            } else if (strstr(begin, "image")) {
                play_args = &playArgs(RTPSTREAM_PCAP_IMAGE);
                stream = RTPSTREAM_PCAP_IMAGE;
            } else if (strstr(begin, "video")) {
                play_args = &playArgs(RTPSTREAM_PCAP_VIDEO);
                stream = RTPSTREAM_PCAP_VIDEO;
            } else if (strstr(begin, "m=text")) {
                play_args = &playArgs(RTPSTREAM_PCAP_TEXT);
                stream = RTPSTREAM_PCAP_TEXT;
            } else {
                // This check will not do, as we use the media_port in other places too.
                //ERROR("media_port keyword with no audio or video on the current line (%s)", begin);
            }
            if (play_args != nullptr) {
                if (media_ip_is_ipv6) {
                    (_RCAST(struct sockaddr_in6 *, &(play_args->from)))->sin6_port = htons(port);
                } else {
                    (_RCAST(struct sockaddr_in *, &(play_args->from)))->sin_port = htons(port);
                }
                rtpstream_update_pcap(&rtpstream_callinfo, stream, play_args);
            }
#endif
            append_number(out, port);
            break;
        }
        case E_Message_RTPStream_Audio_Port:
        {
          int temp_audio_port = 0;
          // Only obtain port for RTP ([rtpstream_audio_port+0]) *BUT NOT* RTCP ([rtpstream_audio_port+1])
          if (comp->offset == 0) {
              temp_audio_port = rtpstream_get_local_audioport(&rtpstream_callinfo);
              if (!temp_audio_port) {
                  /* Make this a warning instead? */
                  ERROR("cannot assign a free audio port to this call - using 0 for [rtpstream_audio_port]");
              }
          } else if (comp->offset >= 1) {
              temp_audio_port = rtpstream_callinfo.local_audioport + comp->offset;
          }
          logSrtpInfo("call::createSendingMessage():  E_Message_RTPStream_Audio_Port: %d\n", temp_audio_port);
          append_number(out, temp_audio_port);
        }
        break;
        case E_Message_RTPStream_Video_Port:
        {
          int temp_video_port = 0;
          // Only obtain port for RTP ([rtpstream_video_port+0]) *BUT NOT* RTCP ([rtpstream_video_port+1])
          if (comp->offset == 0) {
              temp_video_port = rtpstream_get_local_videoport(&rtpstream_callinfo);
              if (!temp_video_port) {
                /* Make this a warning instead? */
                ERROR("cannot assign a free video port to this call - using 0 for [rtpstream_video_port]");
              }
          } else if (comp->offset >= 1) {
              temp_video_port = rtpstream_callinfo.local_videoport + comp->offset;
          }
          logSrtpInfo("call::createSendingMessage():  E_Message_RTPStream_Video_Port: %d\n", temp_video_port);
          append_number(out, temp_video_port);
        } break;
        case E_Message_Media_IP_Type:
            out += (media_ip_is_ipv6 ? "6" : "4");
            break;
        case E_Message_Call_Number:
            append_number(out, number);
            break;
        case E_Message_DynamicId:
            append_number(out, call::dynamicId);
            // increment at each request, back to the start past the maximum
            // or below the lowest int
            {
                long long next = (long long)dynamicId + stepDynamicId;
                dynamicId = next > maxDynamicId || next < INT_MIN ? startDynamicId : (int)next;
            }
            break;
        case E_Message_Call_ID:
            out += dialogs ? dialogCallId() : id;
            break;
        case E_Message_CSEQ:
            append_number(out, cseq + comp->offset);
            break;
        case E_Message_PID:
            append_number(out, pid);
            break;
        case E_Message_Service:
            out += service;
            break;
        case E_Message_Branch:
            /* Branch is magic cookie + call number + message index in scenario */
            out += "z9hG4bK-";
            append_number(out, pid);
            out += '-';
            append_number(out, number);
            out += '-';
            append_number(out, (P_index == -1 ? msg_index - 1 : P_index) + comp->offset);
            break;
        case E_Message_Index:
            append_number(out, P_index);
            break;
        case E_Message_Next_Url:
            if (!peekCold().next_req_url.empty()) {
                out += peekCold().next_req_url;
            } else {
                out += get_last_request_uri();
            }
            break;
        case E_Message_Len:
            length_marker = out.size();
            out += "     ";
            len_offset = comp->offset;
            break;
        case E_Message_Authentication:
            if (auth_marker != std::string::npos) {
                ERROR("Only one [authentication] keyword is currently supported!");
            }
            auth_marker = out.size();
            out += "[authentication place holder]";
            auth_comp = comp;
            break;
        case E_Message_Peer_Tag_Param:
            if (peer_tag) {
                out += ";tag=";
                out += *peer_tag;
            }
            break;
        case E_Message_Routes:
            if (peekCold().dialog_route_set) {
                out += "Route: ";
                out += *peekCold().dialog_route_set;
            } else if (!out.empty() && out.back() == '\n') {
                suppresscrlf = true;
            }
            break;
        case E_Message_ClockTick:
            append_number(out, clock_tick);
            break;
        case E_Message_Timestamp:
            struct timeval currentTime;
            gettimeofday(&currentTime, nullptr);
            out += CStat::formatTime(&currentTime, rfc3339);
            break;
        case E_Message_Date:
            char buf[256];
            time_t t;
            struct tm *tm;

            t = time(nullptr);
            tm = gmtime(&t);
            /* changed %Z to hardcoded GMT since in some OS like FreeBSD it could return UTC instead, see issue #535 */
            strftime(buf, 256, "%a, %d %b %Y %T GMT", tm);
            out += buf;
            break;
        case E_Message_Users:
            append_number(out, users);
            break;
        case E_Message_UserID:
            append_number(out, userId);
            break;
        case E_Message_SippVersion:
            /* Drop the initial "v" from the SIPP_VERSION string for legacy reasons. */
            out += (const char *)SIPP_VERSION + 1;
            break;
        case E_Message_Variable: {
            int varId = comp->varId;
            CCallVariable *var = M_callVariableTable->getVar(varId);
            if (var->isSet()) {
                if (var->isRegExp()) {
                    out += var->getMatchingValue();
                } else if (var->isDouble()) {
                    out += std::to_string(var->getDouble());
                } else if (var->isString()) {
                    out += var->getString();
                } else if (var->isBool()) {
                    out += "true";
                }
            } else if (var->isBool()) {
                out += "false";
            }
            if (!out.empty() && out.back() == '\n') {
                suppresscrlf = true;
            }
            break;
        }
        case E_Message_Fill: {
            int varId = comp->varId;
            int length = (int)M_callVariableTable->getVar(varId)->getDouble();
            if (length < 0) {
                length = 0;
            }
            const char *filltext = comp->literal.c_str();
            int filllen = strlen(filltext);
            if (filllen == 0) {
                ERROR("Internal error: [fill] keyword has zero-length text.");
            }
            /* Never grow the message past what can be sent. */
            if ((size_t)length > max_len - out.size()) {
                length = max_len - out.size();
                truncated = true;
            }
            for (int j = 0; j < length; j++) {
                out += filltext[j % filllen];
            }
            break;
        }
        case E_Message_File: {
            char buffer[MAX_HEADER_LEN];
            char chunk[4096];
            createSendingMessage(comp->comp_param.filename, SM_UNUSED, buffer, sizeof(buffer));
            FILE *f = fopen(buffer, "r");
            if (!f) {
                ERROR("Could not open '%s': %s", buffer, strerror(errno));
            }
            int ret;
            while ((ret = fread(chunk, 1, std::min(sizeof(chunk), max_len - out.size()), f)) > 0) {
                out.append(chunk, ret);
            }
            if (ferror(f)) {
                ERROR("Error reading '%s': %s", buffer, strerror(errno));
            }
            if (out.size() == max_len && fgetc(f) != EOF) {
                truncated = true;
            }
            fclose(f);
            break;
        }
        case E_Message_Injection: {
            const size_t orig_len = out.size();
            out += getFieldFromInputFile(comp->field_param.filename, comp->field_param.field, comp->field_param.line);
            /* We are injecting an authentication line. */
            if (size_t tmp = out.find("[authentication", orig_len); tmp != std::string::npos) {
                if (auth_marker != std::string::npos) {
                    ERROR("Only one [authentication] keyword is currently supported!");
                }
                auth_marker = tmp;
                auth_comp = new MessageComponent();
                auth_comp_allocated = true;

                const size_t end = out.find(']', auth_marker);
                if (end == std::string::npos) {
                    ERROR("Unterminated [authentication] keyword!");
                }
                /* Without its brackets, as the scenario's own keywords are
                 * parsed: a parameter is not looked for inside a '['. */
                std::string keyword = out.substr(auth_marker + 1, end - auth_marker - 1);
                SendingMessage::parseAuthenticationKeyword(call_scenario, auth_comp, keyword.data());
            }
            if (!out.empty() && out.back() == '\n') {
                suppresscrlf = true;
            }
            break;
        }
        case E_Message_Last_Header:
        case E_Message_Last_Header_Value: {
            /* "From" or "From:" (the name without the colon) */
            std::string_view name = comp->literal;
            if (!name.empty() && name.back() == ':') {
                name.remove_suffix(1);
            }
            const bool value_only = comp->type == E_Message_Last_Header_Value;
            const char *other = nullptr;
            if (bye_after_peer_request && name.size() == 4 && !strncasecmp(name.data(), "From", 4)) {
                other = "To:";
            } else if (bye_after_peer_request && name.size() == 2 && !strncasecmp(name.data(), "To", 2)) {
                other = "From:";
            }
            if (other) {
                const header_value value = get_header_content(last_recv_msg.c_str(), other);
                if (!value.empty()) {
                    if (!value_only) {
                        out += name;
                        out += ": ";
                    }
                    out += value.view();
                }
            } else if (value_only) {
                out += get_header_content(last_recv_msg.c_str(), std::string(name) + ":").view();
            } else {
                out += get_last_header(comp->literal).view();
            }
            if (!out.empty() && out.back() == '\n') {
                suppresscrlf = true;
            }
            break;
        }
        case E_Message_Custom: {
            /* Keywords registered by plugins: don't trust the returned
             * length to stay inside the space we gave them. */
            const int room = max_len - out.size() + 1;
            const int n = comp->comp_param.fxn(this, comp, scratch, room);
            out.append(scratch, std::clamp(n, 0, room - 1));
            if (n >= room) {
                truncated = true;
            }
            break;
        }
        case E_Message_Last_Message:
            out += last_recv_msg;
            break;
        case E_Message_Last_Request_URI: {
            out += get_last_request_uri();
            break;
        }
        case E_Message_Last_CSeq_Number: {
            int last_cseq = 0;

            const header_value last_header = get_last_header("CSeq:");
            if (bye_after_peer_request) {
                last_cseq = cseq;
            } else if (!last_header.empty()) {
                /* Extract the integer value of the field */
                last_cseq = header_number(last_header.view().substr(strlen("CSeq:")));
            }
            append_number(out, last_cseq + comp->offset);
            break;
        }
        case E_Message_TDM_Map:
            if (!use_tdmmap)
                ERROR("[tdmmap] keyword without -tdmmap parameter on command line");
            out += std::to_string(tdm_map_x+(int((tdm_map_number)/((tdm_map_b+1)*(tdm_map_c+1))))%(tdm_map_a+1)) + "."
                   + std::to_string(tdm_map_h) + "."
                   + std::to_string(tdm_map_y+(int((tdm_map_number)/(tdm_map_c+1)))%(tdm_map_b+1)) + "/"
                   + std::to_string(tdm_map_z+(tdm_map_number)%(tdm_map_c+1));
            break;
        default:
            /* The SRTP keywords: all that is left of the enum */
            if (const SrtpKeyword *keyword = find_srtp_keyword(comp->type)) {
                appendSrtpKeyword(*keyword, *comp, out, keyword->video ? pV : pA);
                (keyword->video ? srtp_video_updated : srtp_audio_updated) = true;
            }
            break;
        }
    }
    /* Components skipped because the message was already full. */
    if (out.size() > max_len || i < src->numComponents()) {
        truncated = true;
    }
    if (out.size() > max_len) {
        out.resize(max_len);
    }
    /* Placeholders cut off by the truncation can't be filled in. */
    if (length_marker != std::string::npos && length_marker + 5 > out.size()) {
        length_marker = std::string::npos;
    }
    if (auth_marker != std::string::npos && out.find(']', auth_marker) == std::string::npos) {
        auth_marker = std::string::npos;
    }

    /* Need the body for length and auth-int calculation */
    size_t body = std::string::npos;
    if (length_marker != std::string::npos || auth_marker != std::string::npos) {
        body = out.find("\r\n\r\n");
    }

    /* Fix up the length. */
    if (length_marker != std::string::npos) {
        if (auth_marker != std::string::npos && (body == std::string::npos || auth_marker > body)) {
            ERROR("The authentication keyword should appear in the message header, not the body!");
        }

        const size_t body_len = out.size() - body;
        if (body != std::string::npos && body_len > 4 && body_len < 100004) {
            char len[16];
            snprintf(len, sizeof(len), "%5u", (unsigned)(body_len - 4 + len_offset));
            out.replace(length_marker, 5, len);
        } else if (body != std::string::npos) {
            // Empty body: Content-Length is 0
            out.replace(length_marker, 5, "    0");
        } else {
            // No end of headers: Content-Length is 0 and ends them
            out.replace(length_marker, std::string::npos, "    0\r\n\r\n");
        }
    }

    /*
     * The authentication substitution must be done outside the above
     * loop because auth-int will use the body (which must have already
     * been keyword substituted) to build the md5 hash
     */
    if (auth_marker != std::string::npos) {
        if (peekCold().dialog_authentication.empty()) {
            ERROR("Authentication keyword without dialog_authentication!");
        }
        call_cold &auth = *cold_state;

        const size_t auth_marker_len = out.find(']', auth_marker) + 1 - auth_marker;
        /* Determine the type of credentials: registrars use
         * Authorization, proxies Proxy-Authorization. */
        std::string result = auth.dialog_challenge_type == 401 ? "Authorization: " : "Proxy-Authorization: ";

        /* Build the auth credenticals */
        const std::string uri = (remote ? remote->ip : remote_ip) + ":" + std::to_string(remote_port);
        char my_auth_user[MAX_HEADER_LEN + 2];
        char my_auth_pass[MAX_HEADER_LEN + 2];
        char my_aka_OP[MAX_HEADER_LEN + 2];
        char my_aka_AMF[MAX_HEADER_LEN + 2];
        char my_aka_K[MAX_HEADER_LEN + 2];

        createSendingMessage(auth_comp->comp_param.auth_param.auth_user, SM_UNUSED, my_auth_user, sizeof(my_auth_user));
        createSendingMessage(auth_comp->comp_param.auth_param.auth_pass, SM_UNUSED, my_auth_pass, sizeof(my_auth_pass));
        createSendingMessage(auth_comp->comp_param.auth_param.aka_K, SM_UNUSED, my_aka_K, sizeof(my_aka_K));
        createSendingMessage(auth_comp->comp_param.auth_param.aka_AMF, SM_UNUSED, my_aka_AMF, sizeof(my_aka_AMF));
        createSendingMessage(auth_comp->comp_param.auth_param.aka_OP, SM_UNUSED, my_aka_OP, sizeof(my_aka_OP));

        std::string credentials;
        if (!createAuthHeader(my_auth_user, my_auth_pass, src->getMethod(), uri,
                              body == std::string::npos ? "" : out.c_str() + body + 4,
                              auth.dialog_authentication.c_str(), my_aka_OP, my_aka_AMF, my_aka_K,
                              auth.next_nonce_count++, credentials)) {
            ERROR("%s", credentials.c_str());
        }
        result += credentials;

        out.replace(auth_marker, auth_marker_len, result);
    }

    if (out.size() > max_len) {
        out.resize(max_len);
        truncated = true;
    }
    if (truncated) {
        static bool warned = false;
        if (!warned) {
            WARNING("Outgoing message truncated to the %zu-byte message buffer (further truncations are not reported)", max_len);
            warned = true;
        }
    }
    if (auth_comp_allocated) {
        SendingMessage::freeMessageComponent(auth_comp);
    }

    // PASS OUTGOING SRTP PARAMETERS...
    if (srtp_audio_updated) {
        passLocalSrtp(false, pA);
    }
    if (srtp_video_updated) {
        passLocalSrtp(true, pV);
    }

    /* An SDP is an offer or an answer, whether or not a [len] or an
     * [authentication] had its body found above */
    if (out.find("\r\n\r\n") != std::string::npos &&
        is_sdp_content_type(get_header_content(out.c_str(), "Content-Type:").view())) {
        if (getSessionStateCurrent() == eNoSession)
        {
            logSrtpInfo("call::createSendingMessage():  Switching session state:  eNoSession --> eOfferSent\n");
            setSessionState(eOfferSent);
        }
        else if (getSessionStateCurrent() == eCompleted)
        {
            logSrtpInfo("call::createSendingMessage():  Switching session state:  eCompleted --> eOfferSent\n");
            setSessionState(eOfferSent);
        }
        else if (getSessionStateCurrent() == eOfferReceived)
        {
            logSrtpInfo("call::createSendingMessage():  Switching session state:  eOfferReceived --> eAnswerSent\n");
            setSessionState(eAnswerSent);
            logSrtpInfo("call::createSendingMessage():  Switching session state:  eAnswerSent --> eCompleted\n");
            setSessionState(eCompleted);
        }
    }

    return out;
}

/* Is there a <recvCmd> after the step at index, before the call sends
 * another command? */
bool call::recvCmdFollows(int index)
{
    for (int i = index + 1; i < (int)call_scenario->messages.size(); i++) {
        if (call_scenario->messages[i]->M_type == MSG_TYPE_RECVCMD) {
            return true;
        } else if (call_scenario->messages[i]->M_type == MSG_TYPE_SENDCMD) {
            return false;
        }
    }
    return false;
}

bool call::process_twinSippCom(char * msg)
{
    int             search_index;
    bool            found = false;

    callDebug("Processing incoming command for call-ID %s:\n%s\n\n", id, msg);

    setRunning();

    if (checkInternalCmd(msg) == false) {

        for(search_index = msg_index;
                search_index < (int)call_scenario->messages.size();
                search_index++) {
            if(call_scenario->messages[search_index] -> M_type != MSG_TYPE_RECVCMD) {
                if ((call_scenario->messages[search_index] -> optional) ||
                    (call_scenario->messages[search_index] -> M_type == MSG_TYPE_NOP)) {
                    continue;
                }
                /* The peer can answer a <sendCmd> before the SIP message
                 * the call waits for comes, or before the call has sent
                 * the one after the <sendCmd>, which runs on its next
                 * turn. Keep the command for the <recvCmd> that follows,
                 * as a message that comes before a <sendCmd> has run is
                 * kept for its <recv>. */
                int type = call_scenario->messages[search_index]->M_type;
                if ((type == MSG_TYPE_RECV || type == MSG_TYPE_SEND) && peekCold().queued_cmd.empty() &&
                    recvCmdFollows(search_index)) {
                    callDebug("Keeping the command for the <recvCmd> after index %d.\n", search_index);
                    cold().queued_cmd = msg;
                    return true;
                }
                /* The received message is different from the expected one */
                TRACE_MSG("Unexpected control message received (I was expecting a different type of message):\n%s\n", msg);
                callDebug("Unexpected control message received (I was expecting a different type of message):\n%s\n\n", msg);
                return rejectCall();
            } else {
                if(extendedTwinSippMode) {                  // 3pcc extended mode
                    if(check_peer_src(msg, search_index)) {
                        found = true;
                        break;
                    } else {
                        WARNING("Unexpected sender for the received peer message\n%s", msg);
                        return rejectCall();
                    }
                } else {
                    found = true;
                    break;
                }
            }
        }

        if (found) {
            call_scenario->messages[search_index]->M_nbCmdRecv ++;
            do_bookkeeping(call_scenario->messages[search_index]);

            // variable treatment
            // Remove the blank line a command without a body ends with
            // (necessary for transport, to be removed for usage), but
            // not the CRLF a body variable at its end ends with.
            size_t len = strlen(msg);
            if (len >= 4 && !strcmp(msg + len - 4, "\r\n\r\n")) {
                msg[len - 4] = 0;
            }
            if (!handleActionResult(executeAction(msg, call_scenario->messages[search_index]))) {
                return false; /* call deleted */
            }
        } else {
            TRACE_MSG("Unexpected control message received (no such message found):\n%s\n", msg);
            callDebug("Unexpected control message received (no such message found):\n%s\n\n", msg);
            return rejectCall();
        }
        msg_index = search_index; //update the state machine
        return(next());
    } else {
        return (false);
    }
}

bool call::checkInternalCmd(char * cmd)
{

    char * L_ptr1, * L_ptr2, L_backup;

    L_ptr1 = strstr(cmd, "internal-cmd:");
    if (!L_ptr1) {
        return (false);
    }
    L_ptr1 += 13 ;
    while((*L_ptr1 == ' ') || (*L_ptr1 == '\t')) {
        L_ptr1++;
    }
    if (!(*L_ptr1)) {
        return (false);
    }
    L_ptr2 = L_ptr1;
    while((*L_ptr2) &&
            (*L_ptr2 != ' ') &&
            (*L_ptr2 != '\t') &&
            (*L_ptr2 != '\r') &&
            (*L_ptr2 != '\n')) {
        L_ptr2 ++;
    }
    if(!*L_ptr2) {
        return (false);
    }
    L_backup = *L_ptr2;
    *L_ptr2 = 0;

    if (strcmp(L_ptr1, "abort_call") == 0) {
        *L_ptr2 = L_backup;
        computeStat(CStat::E_CALL_FAILED);
        abortCall(true);
        return (true);
    }

    *L_ptr2 = L_backup;
    return (false);
}

bool call::check_peer_src(char * msg, int search_index)
{
    char * L_ptr1, * L_ptr2, L_backup ;

    L_ptr1 = strstr(msg, "From:");
    if (!L_ptr1) {
        return (false);
    }
    L_ptr1 += 5 ;
    while((*L_ptr1 == ' ') || (*L_ptr1 == '\t')) {
        L_ptr1++;
    }
    if (!(*L_ptr1)) {
        return (false);
    }
    L_ptr2 = L_ptr1;
    while((*L_ptr2) &&
            (*L_ptr2 != ' ') &&
            (*L_ptr2 != '\t') &&
            (*L_ptr2 != '\r') &&
            (*L_ptr2 != '\n')) {
        L_ptr2 ++;
    }
    if(!*L_ptr2) {
        return (false);
    }
    L_backup = *L_ptr2;
    *L_ptr2 = 0;
    if (strcmp(L_ptr1, call_scenario->messages[search_index]->peer_src.c_str()) == 0) {
        *L_ptr2 = L_backup;
        return(true);
    }

    *L_ptr2 = L_backup;
    return (false);
}


void call::extract_cseq_method(char* method, size_t size, const char* msg)
{
    /* The CSeq header, in any case, not "CSeq" elsewhere in the message */
    const header_value cseq = get_header_content(msg, "CSeq:");
    std::string_view value = cseq.view();
    /* Skip the CSeq number, and the blanks around it */
    value.remove_prefix(std::min(value.find_first_not_of(" \t\r\n"), value.size()));
    value.remove_prefix(std::min(value.find_first_of(" \t\r\n"), value.size()));
    value.remove_prefix(std::min(value.find_first_not_of(" \t\r\n"), value.size()));
    /* A '\r' terminates the line, so we want to catch that too. */
    size_t nbytes = std::min(value.find_first_of("\r\n"), value.size());
    if (nbytes >= size) {
        nbytes = size - 1;
    }
    memcpy(method, value.data(), nbytes);
    method[nbytes] = '\0';
}

/* The first branch in the Via headers of msg, cut to fit in size bytes */
void call::extract_transaction(char *txn, size_t size, const char *msg)
{
    const header_value via = get_header_content(msg, "via:");
    const std::string_view text = via.view();
    size_t branch = text.find(";branch=");
    if (branch == std::string_view::npos) {
        txn[0] = '\0';
        return;
    }

    branch += strlen(";branch=");
    const char *end = txn + size - 1;
    while (txn < end && branch < text.size() && text[branch] != ';' && text[branch] != ',' &&
           !isspace((unsigned char)text[branch])) {
        *txn++ = text[branch++];
    }
    *txn = '\0';
}

void call::formatNextReqUrl(const char* contact)
{
    /* clean up the next_req_url */
    while (*contact != '\0' && (*contact == ' ' || *contact == '\t')) {
        ++contact;
    }
    const char* start = strchr(contact, '<');
    const char* end = strchr(contact, '>');
    if ((start && end)  && (start < end)) {
        contact = start;
        contact++;
        cold().next_req_url.assign(contact, end - contact);
    } else {
        cold().next_req_url.assign(contact);
    }
}

void call::computeRouteSetAndRemoteTargetUri(const char* rr, const char* contact, bool bRequestIncoming)
{
    if (!*contact) {
        WARNING("Cannot record route set if there is no Contact");
        return;
    }

    if (!*rr) {
        /* There are no RR headers. Simply set up the contact as our
         * target uri.  Note that this is only called if there was no
         * dialog_route_set at the moment.  And in either case, we
         * wouldn't want to clear the dialog_route_set because changing
         * RR mid-dialog is not allowed. */
        formatNextReqUrl(contact);
        return;
    }

    std::vector<std::string> headers = split(rr, ',');
    std::vector<std::string>::iterator it;
    std::vector<std::string>::iterator end;
    int direction;

    if (bRequestIncoming) {
        it = headers.begin();
        end = headers.end();
        direction = 1;
    } else {
        it = headers.end() - 1;
        end = headers.begin() - 1;
        direction = -1;
    }

    std::vector<std::string> routes;
    std::string targetUri;
    bool first = true;

    for (; it != end; it += direction) {
        const std::string& header = *it;

        if (first && header.find(";lr") == std::string::npos) {
            /* If the next hop is a static router, set target URI to
             * that router. We'll push the original contact onto the end
             * of the route set. We won't need to record this route,
             * because we've set the target to it. */
            targetUri = header;
        } else {
            first = false;
            routes.emplace_back(trim(header));
        }
    }

    /* If target URI is set, the first hop is a strict router.  Add the
     * Contact as tailing route. */
    if (targetUri.length()) {
        routes.emplace_back(trim(contact));
    } else {
        targetUri = contact;
    }

    if (routes.size()) {
        cold().dialog_route_set = join(routes, ", ");
    }

    formatNextReqUrl(targetUri.c_str());
}

static call_dialog &dialog_entry(std::map<int, call_dialog> &dialogs, int dialog)
{
    std::pair<std::map<int, call_dialog>::iterator, bool> ins = dialogs.try_emplace(dialog);
    if (ins.second) {
        ins.first->second.cseq = base_cseq;
    }
    return ins.first->second;
}

void call::switchDialog(int dialog)
{
    if (!dialogs || dialogs->current == dialog) {
        return;
    }
    auto swap_state = [this](call_dialog &d) {
        std::swap(cseq, d.cseq);
        std::swap(last_recv_invite_cseq, d.last_recv_invite_cseq);
        std::swap(peer_tag, d.peer_tag);
        std::swap(last_recv_msg, d.last_recv_msg);
        std::swap(cold().dialog_route_set, d.dialog_route_set);
        std::swap(cold().next_req_url, d.next_req_url);
    };
    swap_state(dialogs->dialogs[dialogs->current]);
    swap_state(dialog_entry(dialogs->dialogs, dialog));
    dialogs->current = dialog;
}

int call::msgDialog(const message *curmsg)
{
    if (curmsg->dialog) {
        return curmsg->dialog;
    }
    int txn = curmsg->response_txn ? curmsg->response_txn : curmsg->ack_txn;
    if (txn && transactions[txn - 1].dialog) {
        return transactions[txn - 1].dialog;
    }
    return 1;
}

int call::dialogOf(const char *msg)
{
    /* The peer echoes a "///" prefix written before [call_id]: the
     * Call-ID of the dialog is what follows it, as for the call's */
    std::string_view full_call_id;
    const std::string_view call_id = get_trimmed_call_id(msg, &full_call_id);
    for (const auto &[dialog, d] : dialogs->dialogs) {
        if (!d.call_id.empty() && (d.call_id == full_call_id || d.call_id == call_id)) {
            return dialog;
        }
    }
    return 1;
}

bool call::dialogKnown(int dialog)
{
    if (dialog == 1) {
        return true;
    }
    std::map<int, call_dialog>::iterator it = dialogs->dialogs.find(dialog);
    return it != dialogs->dialogs.end() && !it->second.call_id.empty();
}

void call::setDialogCallId(int dialog, std::string_view call_id)
{
    /* A Call-ID of this call already, such as its own */
    if (get_listener(call_id) == this) {
        return;
    }
    call_dialog &d = dialog_entry(dialogs->dialogs, dialog);
    d.call_id = call_id;
    listen(d.call_id.c_str());
}

const char *call::dialogCallId()
{
    if (dialogs->current == 1) {
        return id;
    }
    call_dialog &d = dialogs->dialogs[dialogs->current];
    if (d.call_id.empty()) {
        setDialogCallId(dialogs->current, (std::to_string(dialogs->current) + "-" + id).c_str());
    }
    return d.call_id.c_str();
}

std::vector<std::string> call::dialogIds()
{
    std::vector<std::string> ids;
    if (dialogs) {
        for (const auto &[dialog, d] : dialogs->dialogs) {
            if (!d.call_id.empty()) {
                ids.push_back(d.call_id);
            }
        }
    }
    return ids;
}

int call::newDialogFor(const char *msg)
{
    char request[65];
    const char *end = strchr(msg, ' ');
    if (pastLastMessage() || get_reply_code(msg) || !end || end - msg >= (int)sizeof(request)) {
        return 0;
    }
    memcpy(request, msg, end - msg);
    request[end - msg] = '\0';

    for (int index = msg_index; index < (int)call_scenario->messages.size(); index++) {
        message *curmsg = call_scenario->messages[index];
        if (curmsg->recv_request) {
            int dialog = msgDialog(curmsg);
            if (!dialogKnown(dialog) && curmsg->matchesRequest(request)) {
                return dialog;
            }
        }
        if (!curmsg->optional) {
            break;
        }
    }
    return 0;
}

call *call::take_new_dialog(const char *msg)
{
    for (call *call_ptr : new_dialog_calls) {
        if (int dialog = call_ptr->newDialogFor(msg)) {
            call_ptr->setDialogCallId(dialog, get_call_id(msg));
            return call_ptr;
        }
    }
    return nullptr;
}

bool call::matches_scenario(unsigned int index, int reply_code, char * request, char * responsecseqmethod, char *txn)
{
    message *curmsg = call_scenario->messages[index];

    if (dialogs && msgDialog(curmsg) != dialogs->incoming) {
        return false;
    }

    if ((curmsg->recv_request)) {
        return curmsg->matchesRequest(request);
    } else if (curmsg->recv_response) {
        if (!curmsg->matchesResponse(reply_code)) {
            return false;
        }
       /* This is a potential candidate, we need to match transactions. */
       if (curmsg->response_txn) {
           if (transactions[curmsg->response_txn - 1].txnID && *transactions[curmsg->response_txn - 1].txnID == txn) {
               return true;
           } else {
               return false;
           }
       } else if (index == 0) {
           /* Always true for the first message. */
           return true;
       } else if (!curmsg->recv_response_for_cseq_method_list.empty() &&
                  strstr(curmsg->recv_response_for_cseq_method_list.c_str(), responsecseqmethod)) {
           /* If we do not have a transaction defined, we just check the CSEQ method. */
           return true;
       } else {
           return false;
       }
    }

    return false;
}

void call::queue_up(const char* msg, bool sdp_read)
{
    call_cold &c = cold();
    c.queued_msg = msg;
    c.queued_sdp_read = sdp_read;
}

/* Whether a and b are the same address and port. */
static bool same_address(const struct sockaddr_storage *a, const struct sockaddr_storage *b)
{
    if (a->ss_family != b->ss_family) {
        return false;
    }
    if (a->ss_family == AF_INET) {
        const struct sockaddr_in *a4 = (const struct sockaddr_in *)a;
        const struct sockaddr_in *b4 = (const struct sockaddr_in *)b;
        return a4->sin_port == b4->sin_port && a4->sin_addr.s_addr == b4->sin_addr.s_addr;
    }
    if (a->ss_family == AF_INET6) {
        const struct sockaddr_in6 *a6 = (const struct sockaddr_in6 *)a;
        const struct sockaddr_in6 *b6 = (const struct sockaddr_in6 *)b;
        return a6->sin6_port == b6->sin6_port &&
               !memcmp(&a6->sin6_addr, &b6->sin6_addr, sizeof(a6->sin6_addr));
    }
    return !memcmp(a, b, sizeof(*a));
}

void call::forget_request_source(std::vector<request_source>::iterator it)
{
    if (it->socket) {
        it->socket->close();
    }
    cold_state->request_sources.erase(it);
}

/* Remember where a request that did not come from the call's destination
 * came from, for its responses: RFC 3261 18.2.2 sends a response back to
 * the source of its request, as rport (RFC 3581) does in practice. It is
 * found by the request's top Via branch, which the response copies; a
 * CANCEL has its INVITE's, and comes from the same hop. -rsa sends every
 * message to its address. */
void call::remember_request_source(const char *msg, const struct sockaddr_storage *src,
                                   SIPpSocket *socket)
{
    static const size_t max_request_sources = 4;

    if (use_remote_sending_addr || !strncmp(msg, "SIP/2.0 ", 8) || !strncmp(msg, "ACK ", 4)) {
        return;
    }
    bool elsewhere = transport == T_UDP ? !same_address(src, &call_peer)
                                        : socket && socket != call_socket;
    if (!elsewhere && peekCold().request_sources.empty()) {
        return;
    }
    std::vector<request_source> &request_sources = cold().request_sources;

    char branch[MAX_HEADER_LEN];
    extract_transaction(branch, sizeof(branch), msg);
    if (!*branch) {
        return;
    }
    auto it = request_sources.begin();
    while (it != request_sources.end() && it->branch != branch) {
        ++it;
    }
    if (it != request_sources.end()) {
        /* A request of this transaction again: it is answered where the
         * last one came from. */
        forget_request_source(it);
    }
    if (!elsewhere) {
        return;
    }
    if (request_sources.size() == max_request_sources) {
        forget_request_source(request_sources.begin());
    }
    request_source rs;
    rs.branch = branch;
    memcpy(&rs.addr, src, sizeof(rs.addr));
    rs.socket = nullptr;
    if (transport != T_UDP) {
        rs.socket = socket;
        socket->ss_count++;
    }
    request_sources.push_back(std::move(rs));
}

bool call::process_incoming(const char* msg, const struct sockaddr_storage* src, SIPpSocket *socket)
{
    return process_incoming(msg, src, socket, false);
}

bool call::process_incoming(const char* msg, const struct sockaddr_storage* src, SIPpSocket *socket,
                            bool sdp_read)
{
    int             reply_code = 0;
    static char     request[65];
    char            responsecseqmethod[65];
    char            txn[MAX_HEADER_LEN];
    unsigned long   cookie = 0;
    const char*     ptr;
    int             search_index;
    bool            found = false;
    unsigned long int invite_cseq = 0;

    update_clock_tick();
    callDebug("Processing %zu byte incoming message for call-ID %s (hash %lu):\n%s\n\n",
              strlen(msg), id, hash(msg), msg);

    if (last_send_unanswered && !strncmp(msg, "SIP/2.0", 7) && same_cseq(last_send_msg.c_str(), msg)) {
        last_send_unanswered = false;
    }

    /* Over but for its <exec verify> commands, the call takes no more
     * messages. */
    if (pastLastMessage()) {
        return true;
    }

    setRunning();
    message *curmsg = call_scenario->messages[msg_index];

    /* Ignore the messages received during a pause if -pause_msg_ign is set */
    if (curmsg->M_type == MSG_TYPE_PAUSE && pause_msg_ign) {
        return true;
    }

    /* Get our destination if we have none. */
    if (call_peer.ss_family == AF_UNSPEC && src) {
        memcpy(&call_peer, src, sizeof(call_peer));
    }
    if (src) {
        remember_request_source(msg, src, socket);
    }

    /* A <nop> or <sendCmd> runs on the call's next turn, so a message can
     * arrive before it has, as the first command in server mode or right
     * after the message sent before it. Run it first and handle the message
     * once the call waits for one, instead of taking it as unexpected. */
    if (curmsg->M_type == MSG_TYPE_NOP || curmsg->M_type == MSG_TYPE_SENDCMD) {
        queue_up(msg);
        paused_until = 0;
        return run();
    }
    responsecseqmethod[0] = '\0';
    txn[0] = '\0';

    if (dialogs) {
        dialogs->incoming = dialogOf(msg);
        switchDialog(dialogs->incoming);
    }

    if (!checkAckCSeq(msg)) {
        WARNING("ACK CSeq value does NOT match value of related INVITE CSeq -- aborting call");
        computeStat(CStat::E_CALL_FAILED);
        delete this;
        return false;
    }

    /* Check that we have a To:-header */
    if (get_header(msg, "To:", false).empty() && !process_unexpected(msg)) {
        return false;
    }

    if ((transport == T_UDP) && (retrans_enabled)) {
        /* Detects retransmissions from peer and retransmit the
         * message which was sent just after this one was received */
        cookie = hash(msg);
        if ((recv_retrans_recv_index >= 0) && (recv_retrans_hash == cookie)) {

            if (lost(recv_retrans_recv_index)) {
                TRACE_MSG("%s message (retrans) lost (recv).", TRANSPORT_TO_STRING(transport));
                callDebug("%s message (retrans) lost (recv) (hash %lu)\n", TRANSPORT_TO_STRING(transport), hash(msg));

                call_scenario->messages[recv_retrans_recv_index]->nb_lost++;
                return true;
            }

            call_scenario->messages[recv_retrans_recv_index]->nb_recv_retrans++;

            /* Send it again as it was sent: rendering it again would give
             * new values to keywords such as the SRTP keys. */
            int status;
            if (recv_retrans_last) {
                status = send_raw(last_send_msg.c_str(), recv_retrans_send_index, last_send_msg.size());
            } else {
                status = send_raw(recv_retrans_msg.c_str(), recv_retrans_send_index, recv_retrans_msg.size());
            }

            if (status >= 0) {
                call_scenario->messages[recv_retrans_send_index]->nb_sent_retrans++;
                computeStat(CStat::E_RETRANSMISSION);
            } else {
                return false;
            }

            return true;
        }

        if ((last_recv_index >= 0) && (last_recv_hash == cookie)) {
            /* This one has already been received, but not processed
             * yet => (has not triggered something yet) so we can discard.
             *
             * This case appears when the UAS has send a 200 but not received
             * a ACK yet. Thus, the UAS retransmit the 200 (invite transaction)
             * until it receives a ACK. In this case, it never sends the 200
             * from the  BYE, until it has reveiced the previous 200. Thus,
             * the UAC retransmit the BYE, and this BYE is considered as an
             * unexpected.
             *
             * This case can also appear in case of message duplication by
             * the network. This should not be considered as an unexpected.
             */
            call_scenario->messages[last_recv_index]->nb_recv_retrans++;
            return true;
        }

        /* A request of a transaction started before the last message:
         * the last response we sent in it, if any, goes again. */
        for (unsigned int i = 0; i < call_scenario->transactions.size(); i++) {
            txnInstanceInfo &txn_info = transactions[i];
            if (txn_info.request.empty() || txn_info.requestHash != cookie) {
                continue;
            }
            call_scenario->messages[txn_info.requestIndex]->nb_recv_retrans++;
            if (txn_info.response.empty()) {
                return true;
            }
            if (send_raw(txn_info.response.c_str(), txn_info.responseIndex, txn_info.response.size()) < 0) {
                return false;
            }
            call_scenario->messages[txn_info.responseIndex]->nb_sent_retrans++;
            computeStat(CStat::E_RETRANSMISSION);
            return true;
        }
    }

    /* Check if message has a SDP in it; and extract media information.
     * Also handle multipart/mixed bodies that contain an application/sdp part
     * (e.g. SIP messages carrying both SDP and PIDF-LO geolocation).
     * Its crypto lines and the offer/answer state are taken without
     * media too, for the crypto keywords of the next SDP. */
    const header_value content_type = get_header_content(msg, "Content-Type:");
    const std::string_view ct_hdr = content_type.view();
    bool has_sdp_content = is_sdp_content_type(ct_hdr) ||
                           (ct_hdr.find("multipart/") != std::string_view::npos && strstr(msg, "application/sdp"));
    if (has_sdp_content && !sdp_read && !curmsg->ignoresdp) {
        int audio_port = 0;
        int video_port = 0;
        std::string audio_host;
        std::string video_host;

        if (header_number(get_header_content(msg, "Content-Length:").view()) > 0) {
            if (getSessionStateCurrent() == eNoSession) {
                logSrtpInfo("call::process_incoming():  Switching session state:  eNoSession --> eOfferReceived\n");
                setSessionState(eOfferReceived);
            } else if (getSessionStateCurrent() == eCompleted) {
                logSrtpInfo("call::process_incoming():  Switching session state:  eCompleted --> eOfferReceived\n");
                setSessionState(eOfferReceived);
            } else if (getSessionStateCurrent() == eOfferSent) {
                logSrtpInfo("call::process_incoming():  Switching session state:  eOfferSent --> eAnswerReceived\n");
                setSessionState(eAnswerReceived);
                logSrtpInfo("call::process_incoming();  Switching session state:  eAnswerReceived --> eCompleted\n");
                setSessionState(eCompleted);
            }

            // INCOMING SRTP PARAM CONTEXT
            SrtpInfoParams pA;
            SrtpInfoParams pV;

            if (extract_srtp_remote_info(msg, pA, pV) < 0) {
                WARNING("extract_rtp_remote_addr: error extracting SRTP parameters from SDP message body");
                return rejectCall();
            }

            if (hasMedia == 1) {
                extract_rtp_remote_addr(msg, audio_host, audio_port, video_host, video_port);
                if ((audio_port == 0) && (video_port == 0)) {
                    WARNING("extract_rtp_remote_addr: no m=audio or m=video or m=image line found in SDP message body");
                } else {
                    rtpstream_set_remote(&rtpstream_callinfo, audio_host.c_str(), audio_port, video_host.c_str(),
                                         video_port);
                }
            }

            // PASS INCOMING SRTP PARAMETERS...
            const bool answer = getSessionStateCurrent() == eCompleted && getSessionStateOld() == eAnswerReceived;
            if (pA.found && (pA.primary_cryptotag != 0)) {
                rtpstream_set_srtp_audio_remote(&rtpstream_callinfo, pA);
                takeRemoteSrtp(false, pA, audio_host, audio_port, answer);
            }
            if (pV.found && (pV.primary_cryptotag != 0)) {
                rtpstream_set_srtp_video_remote(&rtpstream_callinfo, pV);
                takeRemoteSrtp(true, pV, video_host, video_port, answer);
            }
        } // ptr
    } // Content-Type

    /* Is it a response ? */
    if ((msg[0] == 'S') &&
            (msg[1] == 'I') &&
            (msg[2] == 'P') &&
            (msg[3] == '/') &&
            (msg[4] == '2') &&
            (msg[5] == '.') &&
            (msg[6] == '0')) {

        reply_code = get_reply_code(msg);
        if (!reply_code) {
            if (!process_unexpected(msg)) {
                return false; // Call aborted by unexpected message handling
            }
#ifdef PCAPPLAY
        } else if (!sdp_read && hasMedia == 1 && !curmsg->ignoresdp) {
            /* Get media info if we find something like an SDP: a
             * response need not end its headers with a blank line. */
            const char *body = strstr(msg, "\r\n\r\n");
            if (body && body[4]) {
                get_remote_media_addr(msg);
            }
#endif
        }
        /* It is a response: update peer_tag */
        if (const std::optional<std::string_view> tag = get_peer_tag(msg)) {
            peer_tag = *tag;
        }
        request[0] = 0;
        // extract the cseq method from the response
        extract_cseq_method(responsecseqmethod, sizeof(responsecseqmethod), msg);
        extract_transaction(txn, sizeof(txn), msg);
    } else if ((ptr = strchr(msg, ' '))) {
        if ((ptr - msg) < 64) {
            memcpy(request, msg, ptr - msg);
            request[ptr - msg] = 0;
            // Check if we received an ACK => call established
            if (strcmp(request, "ACK") == 0) {
                call_established = true;
            }
#ifdef PCAPPLAY
            /* In case of INVITE or re-INVITE, ACK or PRACK
               get the media info if needed (= we got a pcap
               play action) */
            if (((strncmp(request, "INVITE", 6) == 0)
                    || (strncmp(request, "ACK", 3) == 0)
                    || (strncmp(request, "PRACK", 5) == 0))
                    && !sdp_read && hasMedia == 1 && !curmsg->ignoresdp) {
                get_remote_media_addr(msg);
            }
#endif
            if (!strncmp(request, "INVITE", 6)) {
                invite_cseq = get_cseq_value(msg);
                last_recv_invite_cseq = invite_cseq;
            }
            reply_code = 0;
        } else {
            ERROR("SIP method too long in received message '%s'",
                  msg);
        }
    } else {
        ERROR("Invalid sip message received '%s'",
              msg);
    }

    /* Try to find it in the expected non mandatory responses
     * until the first mandatory response in the scenario */
    for (search_index = msg_index;
            search_index < (int)call_scenario->messages.size();
            search_index++) {
        if (!matches_scenario(search_index, reply_code, request, responsecseqmethod, txn)) {
            if (call_scenario->messages[search_index]->optional) {
                continue;
            }
            /* The received message is different for the expected one */
            break;
        }

        found = true;
        /* TODO : this is a little buggy: If a 100 trying from an INVITE
         * is delayed by the network until the BYE is sent, it may
         * stop BYE transmission erroneously, if the BYE also expects
         * a 100 trying. */
        break;
    }

    /* Try to find it in the old non-mandatory receptions */
    if (!found) {
        bool contig = true;
        for(search_index = msg_index - 1;
                search_index >= 0;
                search_index--) {
            if (call_scenario->messages[search_index]->optional == OPTIONAL_FALSE) {
                contig = false;
            }
            if (matches_scenario(search_index, reply_code, request, responsecseqmethod, txn)) {
                if (contig || call_scenario->messages[search_index]->optional == OPTIONAL_GLOBAL) {
                    found = true;
                    break;
                } else {
                    if (int checkTxn = call_scenario->messages[search_index]->response_txn) {
                        /* This is a reply to an old transaction. */
                        if (*transactions[checkTxn - 1].txnID == txn) {
                            /* This reply is provisional, so it should have no effect if we receive it out-of-order. */
                            if (reply_code >= 100 && reply_code <= 199) {
                                TRACE_MSG("-----------------------------------------------\n"
                                          "Ignoring provisional %s message for transaction %s:\n\n%s\n",
                                          TRANSPORT_TO_STRING(transport), call_scenario->transactions[checkTxn - 1].name.c_str(), msg);
                                callDebug("Ignoring provisional %s message for transaction %s (hash %lu):\n\n%s\n",
                                          TRANSPORT_TO_STRING(transport), call_scenario->transactions[checkTxn - 1].name.c_str(), hash(msg), msg);
                                return true;
                            } else if (int ackIndex = transactions[checkTxn - 1].ackIndex) {
                                /* This is the message before an ACK, so verify that this is an invite transaction. */
                                assert (call_scenario->transactions[checkTxn - 1].isInvite);
                                sendBuffer(createSendingMessage(call_scenario->messages[ackIndex]->send_scheme, ackIndex));
                                return true;
                            } else {
                                /* This is a non-provisional message for the transaction, and
                                 * we have already gotten our allowable response (for an INVITE,
                                 * the ACK is still to be sent).  Just make sure that it is not
                                 * a retransmission of the final response. */
                                if (transactions[checkTxn - 1].txnResp == hash(msg)) {
                                    /* We have gotten this retransmission out-of-order, let's just ignore it. */
                                    TRACE_MSG("-----------------------------------------------\n"
                                              "Ignoring final %s message for transaction %s:\n\n%s\n",
                                              TRANSPORT_TO_STRING(transport), call_scenario->transactions[checkTxn - 1].name.c_str(), msg);
                                    callDebug("Ignoring final %s message for transaction %s (hash %lu):\n\n%s\n",
                                              TRANSPORT_TO_STRING(transport), call_scenario->transactions[checkTxn - 1].name.c_str(), hash(msg), msg);
                                    WARNING("Ignoring final %s message for transaction %s (hash %lu):\n\n%s",
                                            TRANSPORT_TO_STRING(transport), call_scenario->transactions[checkTxn - 1].name.c_str(), hash(msg), msg);
                                    return true;
                                }
                            }
                        }
                    } else {
                        /* A provisional reply that UDP delivered behind the
                         * final one has no effect either. */
                        if (reply_code >= 100 && reply_code <= 199) {
                            TRACE_MSG("-----------------------------------------------\n"
                                      "Ignoring late provisional %s message:\n\n%s\n",
                                      TRANSPORT_TO_STRING(transport), msg);
                            callDebug("Ignoring late provisional %s message (hash %lu):\n\n%s\n",
                                      TRANSPORT_TO_STRING(transport), hash(msg), msg);
                            return true;
                        }
                        /*
                         * we received a non mandatory msg for an old transaction (this could be due to a retransmit.
                         * If this response is for an INVITE transaction, retransmit the ACK to quench retransmits.
                         */
                        if ( (reply_code) &&
                                (0 == strncmp (responsecseqmethod, "INVITE", strlen(responsecseqmethod)) ) &&
                                (call_scenario->messages[search_index+1]->M_type == MSG_TYPE_SEND) &&
                                (call_scenario->messages[search_index+1]->send_scheme->isAck()) ) {
                            sendBuffer(createSendingMessage(call_scenario->messages[search_index+1]->send_scheme, search_index + 1));
                            return true;
                        }
                        /* The peer ACKs each 200 we retransmit, so an ACK
                         * can come again after we moved on; nothing answers
                         * it. */
                        if (!reply_code && !strcmp(request, "ACK")) {
                            TRACE_MSG("-----------------------------------------------\n"
                                      "Ignoring repeated %s ACK:\n\n%s\n",
                                      TRANSPORT_TO_STRING(transport), msg);
                            callDebug("Ignoring repeated %s ACK (hash %lu):\n\n%s\n",
                                      TRANSPORT_TO_STRING(transport), hash(msg), msg);
                            return true;
                        }
                    }
                }
            }
        }
    }

    /* If it is still not found, process an unexpected message */
    if(!found) {
        if (call_scenario->unexpected_jump >= 0) {
            bool recursive = false;
            if (call_scenario->retaddr >= 0) {
                if (M_callVariableTable->getVar(call_scenario->retaddr)->getDouble() != 0) {
                    /* We are already in a jump! */
                    recursive = true;
                } else {
                    M_callVariableTable->getVar(call_scenario->retaddr)->setDouble(msg_index);
                }
            }
            if (!recursive) {
                if (call_scenario->pausedaddr >= 0) {
                    M_callVariableTable->getVar(call_scenario->pausedaddr)->setDouble(paused_until);
                }
                msg_index = call_scenario->unexpected_jump;
                queue_up(msg, true);
                paused_until = 0;
                rtpstream_wait_check = 0;
                return run();
            } else {
                if (!process_unexpected(msg)) {
                    return false; // Call aborted by unexpected message handling
                }
            }
        } else {
            T_AutoMode L_case;
            if ((L_case = checkAutomaticResponseMode(request)) == 0) {
                if (!process_unexpected(msg)) {
                    return false; // Call aborted by unexpected message handling
                }
            } else {
                // call aborted by automatic response mode if needed
                return automaticResponseMode(L_case, msg);
            }
        }
    }

    int test = (!found) ? -1 : call_scenario->messages[search_index]->test;
    /* test==0: No branching"
     * test==-1 branching without testing"
     * test>0   branching with testing
     */

    /* Simulate loss of messages */
    if(lost(search_index)) {
        TRACE_MSG("%s message lost (recv).",
                  TRANSPORT_TO_STRING(transport));
        callDebug("%s message lost (recv) (hash %lu).\n",
                  TRANSPORT_TO_STRING(transport), hash(msg));
        call_scenario->messages[search_index] -> nb_lost++;
        return true;
    }

    /* If we are part of a transaction, mark this as the final response. */
    if (int checkTxn = call_scenario->messages[search_index]->response_txn) {
        transactions[checkTxn - 1].txnResp = hash(msg);
    }

    /* A request that starts a transaction: kept for its responses */
    if (found && call_scenario->messages[search_index]->start_txn) {
        txnInstanceInfo &txn_info = transactions[call_scenario->messages[search_index]->start_txn - 1];
        assign_exact(txn_info.request, msg);
        txn_info.requestHash = cookie;
        txn_info.requestIndex = search_index;
        txn_info.response.clear();
        txn_info.dialog = dialogs ? dialogs->current : 1;
    }


    /* Handle counters and RTDs for this message. */
    do_bookkeeping(call_scenario->messages[search_index]);

    /* Increment the recv counter */
    call_scenario->messages[search_index] -> nb_recv++;

    // Action treatment
    if (found) {
        //WARNING("---EXECUTE_ACTION_ON_MSG---%s---", msg);

        if (!handleActionResult(executeAction(msg, call_scenario->messages[search_index]))) {
            return false; /* call deleted */
        }
    }

    if (*request) { // update [cseq] with received CSeq
        unsigned long int rcseq = get_cseq_value(msg);
        if (rcseq > cseq) cseq = rcseq;
    }

    /* This is an ACK/PRACK or a response, and its index is greater than the
     * current active retransmission message, so we stop the retrans timer.
     * True also for CANCEL and BYE that we also want to answer to */
    if(((reply_code) ||
            ((!strcmp(request, "ACK")) ||
             (!strcmp(request, "CANCEL")) || (!strcmp(request, "BYE")) ||
             (!strcmp(request, "PRACK"))))  &&
            (search_index > last_send_index)) {
        /*
         * We should stop any retransmission timers on receipt of a provisional response only for INVITE
         * transactions. Non INVITE transactions continue to retransmit at T2 until a final response is
         * received
         */
        if ( (0 == reply_code) || // means this is a request.
                (200 <= reply_code) ||  // final response
                ((0 != reply_code) && (0 == strncmp (responsecseqmethod, "INVITE", strlen(responsecseqmethod)))) ) { // prov for INVITE
            next_retrans = 0;
        } else {
            /*
             * We are here due to a provisional response for non INVITE. Update our next retransmit.
             */
            next_retrans = clock_tick + global_t2;
            nb_last_delay = global_t2;

        }
    }

    /* This is a response with 200 so set the flag indicating that an
     * ACK is pending (used to prevent from release a call with CANCEL
     * when an ACK+BYE should be sent instead)                         */
    if (reply_code == 200) {
        ack_is_pending = true;
    }

    /* store the route set only once. TODO: does not support target refreshes!! */
    if (call_scenario->messages[search_index]->bShouldRecordRoutes && !peekCold().dialog_route_set) {
        /* Ensure next_req_url has an empty value in case contact is missing */
        cold().next_req_url.clear();

        /* cache the route set and the contact */
        const std::string rr(get_header_content(msg, "Record-Route:").view());
        const std::string contact(get_header_content(msg, "Contact:").view());
        computeRouteSetAndRemoteTargetUri(rr.c_str(), contact.c_str(), !reply_code);
        // WARNING("next_req_url is [%s]", next_req_url);
    }

    /* store the authentication info */
    if ((call_scenario->messages[search_index] -> bShouldAuthenticate) &&
            (reply_code == 401 || reply_code == 407)) {

        /* is a challenge */
        header_value auth = get_header_content(msg, "Proxy-Authenticate:");
        if (auth.empty()) {
            auth = get_header_content(msg, "WWW-Authenticate:");
        }
        if (auth.empty()) {
            ERROR("Couldn't find 'Proxy-Authenticate' or 'WWW-Authenticate' in 401 or 407!");
        }
        call_cold &c = cold();
        c.dialog_authentication = selectAuthChallenge(auth.view());

        /* Store the code of the challenge for building the proper header */
        c.dialog_challenge_type = reply_code;

        c.next_nonce_count = 1;
    }

    /* If we are not advancing state, we should quite before we change this stuff. */
    if (!call_scenario->messages[search_index]->advance_state) {
        return true;
    }

    /* Store last received message information for all messages so that we can
     * correctly identify retransmissions, and use its body for inclusion
     * in our messages. */
    last_recv_index = search_index;
    last_recv_hash = cookie;
    callDebug("Set Last Recv Hash: %lu (recv index %d)\n", last_recv_hash, last_recv_index);
    assign_exact(last_recv_msg, msg);

    /* If this was a mandatory message, or if there is an explicit next label set
     * we must update our state machine.  */
    if (!call_scenario->messages[search_index]->optional ||
            (call_scenario->messages[search_index]->next &&
             (test == -1 || M_callVariableTable->getVar(test)->isSet()))) {
        /* If we are paused, then we need to wake up so that we properly go through the state machine. */
        paused_until = 0;
        /* Likewise for a wait, unless the actions of this one set it. */
        if (rtpstream_wait_msg != call_scenario->messages[search_index]) {
            rtpstream_wait_check = 0;
        }
        msg_index = search_index;
        return next();
    } else {
        unsigned int timeout = wake();
        unsigned int candidate;

        if (call_scenario->messages[search_index]->next && M_callVariableTable->getVar(test)->isSet()) {
            WARNING("Last message generates an error and will not be used for next sends (for last_ variables):\n%s", msg);
        }

        /* We are just waiting for a message to be received, if any of the
         * potential messages have a timeout we set it as our timeout. We
         * start from the next message and go until any non-receives. */
        for(search_index++; search_index < (int)call_scenario->messages.size(); search_index++) {
            if(call_scenario->messages[search_index] -> M_type != MSG_TYPE_RECV) {
                break;
            }
            candidate = recvTimeout(call_scenario->messages[search_index]);
            if (candidate == 0) {
                if (defl_recv_timeout == 0) {
                    continue;
                }
                candidate = defl_recv_timeout;
            }
            if (!timeout || (clock_tick + candidate < timeout)) {
                timeout = clock_tick + candidate;
            }
        }

        setPaused();
    }
    return true;
}

/* A variable as a number: a string or a regexp match converts, anything
 * that isn't a number is 0 (with a warning if it has a value). */
double call::get_var_double(int varId)
{
    CCallVariable *var = M_callVariableTable->getVar(varId);
    double value;

    if (var->toDouble(&value)) {
        return value;
    }
    if (var->isSet()) {
        WARNING("Invalid double conversion of $%s",
                call_scenario->allocVars->getName(varId));
    }
    return 0.0;
}

double call::get_rhs(CAction *currentAction)
{
    if (currentAction->getVarInId()) {
        return get_var_double(currentAction->getVarInId());
    } else {
        return currentAction->getDoubleValue();
    }
}

/* The receive timeout of curmsg in ms: its timeout, with the keywords
 * expanded now if it has any. */
unsigned int call::recvTimeout(message *curmsg)
{
    if (!curmsg->timeout_scheme) {
        return curmsg->timeout;
    }

    double timeout = strtod(createSendingString(curmsg->timeout_scheme).c_str(), nullptr);
    if (!(timeout >= 1)) { // Also NaN
        return 0;
    }
    if (timeout > INT_MAX) {
        return INT_MAX;
    }
    return (unsigned int)timeout;
}

/* Check the rtp_stream playback again when it is due to end, or after a
 * packet time when that is not known or has passed, or at the wait
 * timeout if that comes first. */
void call::rtpstreamWaitNextCheck(unsigned long play_end)
{
    rtpstream_wait_check = play_end > clock_tick && play_end != ULONG_MAX ? play_end : clock_tick + 20;
    if (rtpstream_wait_until && rtpstream_wait_until < rtpstream_wait_check) {
        rtpstream_wait_check = rtpstream_wait_until;
    }
}

/* The rtp_stream playback outlasted the wait: jump to the ontimeout
 * label of the message that waits, or abort the call without one. */
bool call::rtpstreamWaitTimeout()
{
    message *waitmsg = rtpstream_wait_msg;

    rtpstream_wait_check = 0;
    waitmsg->nb_timeout++;
    if (waitmsg->on_timeout < 0) {
        WARNING("Call-Id: %s, rtp_stream wait timeout on message %s:%d without label to jump to (ontimeout attribute): aborting call",
                id, waitmsg->desc, waitmsg->index);
    } else {
        WARNING("Call-Id: %s, rtp_stream wait timeout on message %s:%d, jumping to label %d",
                id, waitmsg->desc, waitmsg->index, waitmsg->on_timeout);
        msg_index = waitmsg->on_timeout;
        if (msg_index < (int)call_scenario->messages.size()) {
            return true;
        }
        // special case - the label points to the end - finish the call
    }
    computeStat(CStat::E_CALL_FAILED);
    if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
        return abortCall(true);
    }
    delete this;
    return false;
}

/* Past its last message, the call waits for its <exec verify> commands
 * to end, see next(). */
bool call::pastLastMessage()
{
    return msg_index >= (int)(initCall ? call_scenario->initmessages : call_scenario->messages).size();
}

/* Run an <exec verify> command, which the call waits for before its next
 * message. The command runs as system() runs it, but without waiting. */
void call::startVerify(const char *command)
{
    TRACE_MSG("Executing '%s'\n", command);
    pid_t pid = fork();
    if (pid < 0) {
        ERROR_NO("Forking error main");
    }
    if (pid == 0) {
        /* _exit(), as the children of an <exec command> */
        execl("/bin/sh", "sh", "-c", command, (char *) nullptr);
        _exit(127);
    }
    verify_commands[pid] = {this, command};
    verify_pending++;
}

/* An <exec verify> command ended: a non-zero exit fails the call. */
void call::verifyDone(const char *command, int status)
{
    if (WIFEXITED(status)) {
        TRACE_MSG("'%s' returned %d\n", command, WEXITSTATUS(status));
        if (WEXITSTATUS(status) != 0) {
            WARNING("Call-Id: %s, '%s' returned %d", id, command, WEXITSTATUS(status));
            last_action_result = E_AR_VERIFY_FAILED;
        }
    } else {
        TRACE_MSG("'%s' was killed by signal %d\n", command, WTERMSIG(status));
        WARNING("Call-Id: %s, '%s' was killed by signal %d", id, command, WTERMSIG(status));
        last_action_result = E_AR_VERIFY_FAILED;
    }

    if (--verify_pending) {
        return;
    }
    if (pastLastMessage()) {
        terminate(CStat::E_CALL_SUCCESSFULLY_ENDED);
    } else {
        setRunning();
    }
}

void call::reap_verify_commands()
{
    int status;
    pid_t pid;

    /* SIPp waits for no other child while one runs: it reaps the first
     * child of an <exec command> as soon as it forks it. */
    while (!verify_commands.empty() && (pid = waitpid(-1, &status, WNOHANG)) > 0) {
        auto it = verify_commands.find(pid);
        if (it == verify_commands.end()) {
            continue; /* an orphan, adopted when SIPp is PID 1 */
        }
        verify_command done = std::move(it->second);
        verify_commands.erase(it);
        if (done.waiting) {
            done.waiting->verifyDone(done.command.c_str(), status);
        }
    }
}

/* Every step's actions count the same way: a failed check marks the call
 * as failed when it ends, stop_call and a failed setdest end it now.
 * Returns false if the call was deleted. */
bool call::handleActionResult(T_ActionResult actionResult)
{
    if (actionResult == E_AR_NO_ERROR) {
        return true;
    }
    // Store last action result if it is an error
    // and go on with the scenario
    last_action_result = actionResult;
    if (actionResult == E_AR_STOP_CALL) {
        return rejectCall();
    } else if (actionResult == E_AR_CONNECT_FAILED) {
        terminate(CStat::E_FAILED_TCP_CONNECT);
        return false;
    }
    return true;
}

call::T_ActionResult call::executeAction(const char* msg, message* curmsg)
{
    CActions*  actions;
    CAction*   currentAction;
    int rc = 0;

    actions = curmsg->M_actions;
    // looking for action to do on this message
    if (actions == nullptr) {
        return(call::E_AR_NO_ERROR);
    }

    for (int i = 0; i < actions->getActionSize(); i++) {
        currentAction = actions->getAction(i);
        if(currentAction == nullptr) {
            continue;
        }

        if(currentAction->getActionType() == CAction::E_AT_ASSIGN_FROM_REGEXP) {
            std::string msgPart;

            /* Where to look. */
            const char* haystack = nullptr;
            std::string var_value;

            if(currentAction->getLookingPlace() == CAction::E_LP_HDR) {
                msgPart = extractSubMessage(msg, currentAction->getLookingChar(), currentAction->getCaseIndep(),
                                            currentAction->getOccurrence(), currentAction->getHeadersOnly());
                if (currentAction->getCheckIt() == true && msgPart.empty()) {
                    // the sub message is not found and the checking action say it
                    // MUST match --> Call will be marked as failed but will go on
                    WARNING("Failed regexp match: header %s not found in message\n%s", currentAction->getLookingChar(), msg);
                    return(call::E_AR_HDR_NOT_FOUND);
                }
                haystack = msgPart.c_str();
            } else if(currentAction->getLookingPlace() == CAction::E_LP_BODY) {
                haystack = strstr(msg, "\r\n\r\n");
                if (haystack) {
                    haystack += strlen("\r\n\r\n");
                } else {
                    if (currentAction->getCheckIt() == true) {
                        WARNING("Failed regexp match: body not found in message\n%s", msg);
                        return(call::E_AR_HDR_NOT_FOUND);
                    }
                    haystack = "";
                }
            } else if(currentAction->getLookingPlace() == CAction::E_LP_MSG) {
                haystack = msg;
            } else if(currentAction->getLookingPlace() == CAction::E_LP_VAR) {
                /* Get the input variable. */
                const char* value = M_callVariableTable->getVar(currentAction->getVarInId())->getString();
                if (!value) {
                    if (currentAction->getCheckIt() == true) {
                        WARNING("Failed regexp match: variable $%d not set", currentAction->getVarInId());
                        return(call::E_AR_HDR_NOT_FOUND);
                    }
                    value = "";
                }
                /* A copy: a match assigned to the variable it searches
                 * frees the value searched. */
                var_value = value;
                haystack = var_value.c_str();
            } else {
                ERROR("Invalid looking place: %d", currentAction->getLookingPlace());
            }
            bool did_match = (currentAction->executeRegExp(haystack, M_callVariableTable) > 0);

            if (!did_match && currentAction->getCheckIt()) {
                // the message doesn't match and the checkit action say it MUST match
                // Allow easier regexp debugging
                WARNING("Failed regexp match: looking in '%s', with regexp '%s'",
                        haystack, currentAction->getRegularExpression());
                return(call::E_AR_REGEXP_DOESNT_MATCH);
            } else if (did_match && currentAction->getCheckItInverse()) {
                // The inverse of the above
                WARNING("Regexp matched but should not: looking in '%s', with regexp '%s'",
                        haystack, currentAction->getRegularExpression());
                return(call::E_AR_REGEXP_SHOULDNT_MATCH);
            }
        } else if (currentAction->getActionType() == CAction::E_AT_ASSIGN_FROM_VALUE) {
            double operand = get_rhs(currentAction);
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(operand);
        } else if (currentAction->getActionType() == CAction::E_AT_ASSIGN_FROM_INDEX) {
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(msg_index);
        } else if (currentAction->getActionType() == CAction::E_AT_ASSIGN_FROM_GETTIMEOFDAY) {
            struct timeval tv;
            gettimeofday(&tv, nullptr);
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble((double)tv.tv_sec);
            M_callVariableTable->getVar(currentAction->getSubVarId(0))->setDouble((double)tv.tv_usec);
        } else if (currentAction->getActionType() == CAction::E_AT_LOOKUP) {
            /* Create strings from the sending messages. */
            std::string file = createSendingString(currentAction->getMessage(0));
            std::string key = createSendingString(currentAction->getMessage(1));

            auto in_file = inFiles.find(file.c_str());
            if (in_file == inFiles.end()) {
                ERROR("Invalid injection file for insert: %s", file.c_str());
            }

            double value = in_file->second->lookup(key);

            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(value);
        } else if (currentAction->getActionType() == CAction::E_AT_INSERT) {
            /* Create strings from the sending messages. */
            std::string file = createSendingString(currentAction->getMessage(0));
            std::string value = createSendingString(currentAction->getMessage(1));

            auto in_file = inFiles.find(file.c_str());
            if (in_file == inFiles.end()) {
                ERROR("Invalid injection file for insert: %s", file.c_str());
            }

            in_file->second->insert(value);
        } else if (currentAction->getActionType() == CAction::E_AT_REPLACE) {
            /* Create strings from the sending messages. */
            std::string file = createSendingString(currentAction->getMessage(0));
            std::string line = createSendingString(currentAction->getMessage(1));
            std::string value = createSendingString(currentAction->getMessage(2));

            auto in_file = inFiles.find(file.c_str());
            if (in_file == inFiles.end()) {
                ERROR("Invalid injection file for replace: %s", file.c_str());
            }

            char *endptr;
            int lineNum = (int)strtod(line.c_str(), &endptr);
            if (*endptr) {
                ERROR("Invalid line number for replace: %s", line.c_str());
            }

            in_file->second->replace(lineNum, value);
        } else if (currentAction->getActionType() == CAction::E_AT_CLOSE_CON) {
            if (call_socket) {
                dissociate_socket()->close();
            }
        } else if (currentAction->getActionType() == CAction::E_AT_SET_DEST) {
            /* Change the destination for this call. */
            const std::string host = createSendingString(currentAction->getMessage(0));
            const std::string port_text = createSendingString(currentAction->getMessage(1));
            const std::string protocol_text = createSendingString(currentAction->getMessage(2));
            const char *str_host = host.c_str();
            const char *str_port = port_text.c_str();
            const char *str_protocol = protocol_text.c_str();

            char *endptr;
            int port = (int)strtod(str_port, &endptr);
            if (*endptr) {
                ERROR("Invalid port for setdest: %s", str_port);
            }

            int protocol = 0;
            if (!strcmp(str_protocol, "udp") || !strcmp(str_protocol, "UDP")) {
                protocol = T_UDP;
            } else if (!strcmp(str_protocol, "tcp") || !strcmp(str_protocol, "TCP")) {
                protocol = T_TCP;
            } else if (!strcmp(str_protocol, "tls") || !strcmp(str_protocol, "TLS")) {
                protocol = T_TLS;
            } else if (!strcmp(str_protocol, "sctp") || !strcmp(str_protocol, "SCTP")) {
                protocol = T_SCTP;
            } else if (!strcmp(str_protocol, "ws") || !strcmp(str_protocol, "WS")) {
                protocol = T_WS;
            } else if (!strcmp(str_protocol, "wss") || !strcmp(str_protocol, "WSS")) {
                protocol = T_WSS;
            } else {
                ERROR("Unknown transport for setdest: '%s'", str_protocol);
            }

            if (!call_socket && ((protocol == T_TCP && transport == T_TCP) ||
                                 (protocol == T_WS && transport == T_WS) ||
                                 (protocol == T_SCTP && transport == T_SCTP))) {
                bool existing;
                if ((associate_socket(SIPpSocket::new_sipp_call_socket(use_ipv6, transport, &existing))) == nullptr) {
                    switch (protocol) {
                    case T_SCTP:
                        ERROR_NO("Unable to get a SCTP socket");
                        break;
                    default:
                        ERROR_NO("Unable to get a TCP socket");
                    }
                }

                if (!existing) {
                    sipp_customize_socket(call_socket);
                }
            }

            /* A UDP call socket is bound, not connected: the new
             * destination below applies to it as well. Only a failed
             * connection deletes the call, which a UDP socket makes none
             * of. */
            if (!call_socket && protocol == T_UDP && transport == T_UDP && !connect_socket_if_needed()) {
                ERROR("Internal error: a UDP call socket deleted its call");
            }

            if (!call_socket) {
                ERROR("Unable to get a socket");
            }

            if (protocol != call_socket->ss_transport) {
                ERROR("Can not switch protocols during setdest.");
            }

            if (protocol == T_UDP) {
                /* Nothing to do. */
            } else if (TRANSPORT_IS_TLS(protocol)) {
                ERROR("Changing destinations is not supported for TLS.");
            } else if (protocol == T_TCP || protocol == T_SCTP || protocol == T_WS) {
                if (!multisocket) {
                    ERROR("Changing destinations for TCP or SCTP requires multisocket mode.");
                }
                if (call_socket->ss_count > 1) {
                    ERROR("Can not change destinations for a TCP/SCTP socket that has more than one user.");
                }
            }

            if (gai_getsockaddr(&call_peer, str_host, port, AI_PASSIVE, AF_UNSPEC,
                                call_socket->ss_ipv6 ? AF_INET6 : AF_INET) != 0) {
                ERROR("Unknown host '%s' for setdest", str_host);
            }
            memcpy(&call_socket->ss_dest, &call_peer, sizeof(call_peer));

            if (protocol == T_TCP || protocol == T_SCTP || protocol == T_WS) {
                call_socket->close_fd();
                call_socket->ss_changed_dest = true;
                if (call_socket->reconnect()) {
                    if (reconnect_allowed()) {
                        if(errno == EINVAL) {
                            /* This occurs sometime on HPUX but is not a true INVAL */
                            WARNING("Unable to connect a TCP/SCTP/TLS socket, remote peer error");
                        } else {
                            WARNING("Unable to connect a TCP/SCTP/TLS socket");
                        }
                        /* This connection failed.  We must be in multisocket mode, because
                         * otherwise we would already have a call_socket.  This call can not
                         * succeed, but does not affect any of our other calls. We do decrement
                         * the reconnection counter however. */
                        if (reset_number != -1) {
                            reset_number--;
                        }

                        return E_AR_CONNECT_FAILED;
                    } else {
                        if(errno == EINVAL) {
                            /* This occurs sometime on HPUX but is not a true INVAL */
                            ERROR("Unable to connect a TCP/SCTP/TLS socket, remote peer error");
                        } else {
                            ERROR_NO("Unable to connect a TCP/SCTP/TLS socket");
                        }
                    }
                }
            }
        } else if (currentAction->getActionType() == CAction::E_AT_VERIFY_AUTH) {
            bool result;
            const char* lf;
            const char* end;

            lf = strchr(msg, '\n');
            end = strchr(msg, ' ');

            if (!lf || !end) {
                result = false;
            } else if (lf < end) {
                result = false;
            } else {
                const header_value auth = get_header(msg, "Authorization:", true);
                const std::string method(msg, end - msg);

                /* Generate the username to verify it against. */
                const std::string username = createSendingString(currentAction->getMessage(0));
                /* Generate the password to verify it against. */
                const std::string password = createSendingString(currentAction->getMessage(1));
                /* Need the body for length and auth-int calculation */
                const char *body;
                const char *auth_body = nullptr;
                body = strstr(msg, "\r\n\r\n");
                if (body) {
                    auth_body = body;
                    auth_body += strlen("\r\n\r\n");
                } else {
                    auth_body = "";
                }

                result = verifyAuthHeader(username.c_str(), password.c_str(), method.c_str(), auth.view(), auth_body);
            }

            M_callVariableTable->getVar(currentAction->getVarId())->setBool(result);
        } else if (currentAction->getActionType() == CAction::E_AT_JUMP) {
            double operand = get_rhs(currentAction);
            if (msg_index == ((int)operand)) {
                ERROR("Jump statement at index %d jumps to itself and causes an infinite loop", msg_index);
            }
            msg_index = (int)operand - 1;
            /* -1 is allowed to go to the first label, but watch out
             * when using msg_index. */
            if (msg_index < -1 || msg_index >= (int)call_scenario->messages.size()) {
                ERROR("Jump statement out of range (not 0 <= %d <= %zu)",
                      msg_index + 1, call_scenario->messages.size());
            }
        } else if (currentAction->getActionType() == CAction::E_AT_PAUSE_RESTORE) {
            double operand = get_rhs(currentAction);
            paused_until = (int)operand;
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_ADD) {
            double value = get_var_double(currentAction->getVarId());
            double operand = get_rhs(currentAction);
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(value + operand);
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_SUBTRACT) {
            double value = get_var_double(currentAction->getVarId());
            double operand = get_rhs(currentAction);
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(value - operand);
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_MULTIPLY) {
            double value = get_var_double(currentAction->getVarId());
            double operand = get_rhs(currentAction);
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(value * operand);
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_DIVIDE) {
            double value = get_var_double(currentAction->getVarId());
            double operand = get_rhs(currentAction);
            if (operand == 0) {
                WARNING("Action failure: Can not divide by zero ($%s/$%s)!",
                        call_scenario->allocVars->getName(currentAction->getVarId()),
                        call_scenario->allocVars->getName(currentAction->getVarInId()));
            } else {
                M_callVariableTable->getVar(currentAction->getVarId())->setDouble(value / operand);
            }
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_TEST) {
            bool value = currentAction->compare(M_callVariableTable);
            if ((currentAction->getCheckIt() && !value) ||
                (currentAction->getCheckItInverse() && value)
            ) {
                double lhs = M_callVariableTable->getVar(currentAction->getVarInId())->getDouble();
                double rhs = currentAction->getVarIn2Id() ?
                    M_callVariableTable->getVar(currentAction->getVarIn2Id())->getDouble() :
                    currentAction->getDoubleValue();
                const char *lhsName = call_scenario->allocVars->getName(currentAction->getVarInId());
                const char *rhsName = "";
                if (currentAction->getVarIn2Id()) {
                    rhsName = call_scenario->allocVars->getName(currentAction->getVarIn2Id());
                }
                const char *_inverse = currentAction->getCheckIt() ? "" : "_inverse";
                call::T_ActionResult result = currentAction->getCheckIt() ? call::E_AR_TEST_DOESNT_MATCH : call::E_AR_TEST_SHOULDNT_MATCH;

                WARNING("test \"%s:%f %s %s:%f\" with check_it%s failed",
                    lhsName,
                    lhs,
                    currentAction->comparatorToString(currentAction->getComparator()),
                    rhsName,
                    rhs,
                    _inverse
                );
                return(result);
            }
            // "assign_to" is optional when "check_it" or "check_it_inverse" set
            if (currentAction->getVarId() ||
                (!currentAction->getCheckIt() && !currentAction->getCheckItInverse())
            ) {
                M_callVariableTable->getVar(currentAction->getVarId())->setBool(value);
            }
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_STRCMP) {
            const char *lhs = M_callVariableTable->getVar(currentAction->getVarInId())->getString();
            const char *rhs = currentAction->getVarIn2Id()
                                  ? M_callVariableTable->getVar(currentAction->getVarIn2Id())->getString()
                                  : currentAction->getStringValue();
            int value = strcmp(lhs, rhs);
            if ((currentAction->getCheckIt() && value) ||
                (currentAction->getCheckItInverse() && !value)
            ) {
                const char *lhsName = call_scenario->allocVars->getName(currentAction->getVarInId());
                const char *rhsName = "";
                if (currentAction->getVarIn2Id()) {
                    rhsName = call_scenario->allocVars->getName(currentAction->getVarIn2Id());
                }
                const char *_inverse = currentAction->getCheckIt() ? "" : "_inverse";
                call::T_ActionResult result = currentAction->getCheckIt() ? call::E_AR_STRCMP_DOESNT_MATCH : call::E_AR_STRCMP_SHOULDNT_MATCH;

                WARNING("strcmp %s:\"%s\" and %s:\"%s\" with check_it%s returned %d",
                    lhsName,
                    lhs,
                    rhsName,
                    rhs,
                    _inverse,
                    value
                );
                return(result);
            }
            // "assign_to" is optional when "check_it" or "check_it_inverse" set
            if (currentAction->getVarId() ||
                (!currentAction->getCheckIt() && !currentAction->getCheckItInverse())
            ) {
                M_callVariableTable->getVar(currentAction->getVarId())->setDouble((double)value);
            }
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_TRIM) {
            CCallVariable *var = M_callVariableTable->getVar(currentAction->getVarId());
            const char *p = var->getString();
            while (isspace(*p)) {
                p++;
            }
            const char *end = p + strlen(p);
            while (end > p && isspace(end[-1])) {
                end--;
            }
            var->setString(std::string(p, end));
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_URLDECODE) {
            CCallVariable *var = M_callVariableTable->getVar(currentAction->getVarId());
            var->setString(url_decode(var->getString()));
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_URLENCODE) {
            CCallVariable *var = M_callVariableTable->getVar(currentAction->getVarId());
            var->setString(url_encode(var->getString()));
        } else if (currentAction->getActionType() == CAction::E_AT_VAR_TO_DOUBLE) {
            double value;

            if (M_callVariableTable->getVar(currentAction->getVarInId())->toDouble(&value)) {
                M_callVariableTable->getVar(currentAction->getVarId())->setDouble(value);
            } else {
                WARNING("Invalid double conversion from $%s to $%s",
                        call_scenario->allocVars->getName(currentAction->getVarInId()),
                        call_scenario->allocVars->getName(currentAction->getVarId()));
            }
        } else if (currentAction->getActionType() == CAction::E_AT_ASSIGN_FROM_SAMPLE) {
            double value = currentAction->getDistribution()->sample();
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(value);
        } else if (currentAction->getActionType() == CAction::E_AT_ASSIGN_FROM_STRING) {
            M_callVariableTable->getVar(currentAction->getVarId())
                ->setString(createSendingString(currentAction->getMessage()));
        } else if (currentAction->getActionType() == CAction::E_AT_LOG_TO_FILE) {
            LOG_MSG("%s\n", createSendingString(currentAction->getMessage()).c_str());
        } else if (currentAction->getActionType() == CAction::E_AT_LOG_WARNING) {
            WARNING("%s", createSendingString(currentAction->getMessage()).c_str());
        } else if (currentAction->getActionType() == CAction::E_AT_LOG_ERROR) {
            ERROR("%s", createSendingString(currentAction->getMessage()).c_str());
        } else if (currentAction->getActionType() == CAction::E_AT_EXECUTE_CMD) {
            const std::string command = createSendingString(currentAction->getMessage());
            const char *x = command.c_str();
            // TRACE_MSG("Trying to execute [%s]", x);
            pid_t l_pid;
            switch(l_pid = fork()) {
            case -1:
                // error when forking !
                ERROR_NO("Forking error main");
                break;

            case 0:
                // first child process - execute the command
                // Both children _exit(): exit() would run the atexit
                // reset_stdin(), clearing O_NONBLOCK on the stdin they
                // share with SIPp, whose next getch() would then block.
                if((l_pid = fork()) < 0) {
                    WARNING_NO("Forking error child");
                } else if (l_pid == 0) {
                    int ret;
                    ret = system(x); // second child runs
                    if(ret == -1) {
                        WARNING("system call error for %s", x);
                    }
                }
                _exit(EXIT_OTHER);
            default:
                // parent process continue
                // reap first child immediately
                pid_t ret;
                while ((ret=waitpid(l_pid, nullptr, 0)) != l_pid) {
                    if (ret != -1) {
                        ERROR("waitpid returns %1ld for child %1ld", (long) ret, (long) l_pid);
                    }
                }
                break;
            }
        } else if (currentAction->getActionType() == CAction::E_AT_EXEC_LUA) {
            lua_script_exec(createSendingString(currentAction->getMessage()), M_callVariableTable,
                            call_scenario->allocVars);
        } else if (currentAction->getActionType() == CAction::E_AT_VERIFY_CMD) {
            startVerify(createSendingString(currentAction->getMessage()).c_str());
        } else if (currentAction->getActionType() == CAction::E_AT_EXEC_INTCMD) {
            switch (currentAction->getIntCmd()) {
            case CAction::E_INTCMD_STOP_ALL:
                if (!quitting) {
                    quitting = 1;
                }
                break;
            case CAction::E_INTCMD_STOP_NOW:
                sipp_exit(EXIT_TEST_RES_INTERNAL, 0, 0);
                break;
            case CAction::E_INTCMD_STOPCALL:
            default:
                return(call::E_AR_STOP_CALL);
                break;
            }
#ifdef PCAPPLAY
        } else if ((currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_AUDIO) ||
                   (currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_IMAGE) ||
                   (currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_VIDEO) ||
                   (currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_TEXT) ||
                   (currentAction->getActionType() == CAction::E_AT_PLAY_DTMF)) {
            play_args_t* play_args = 0;
            rtpstream_pcap_t stream = RTPSTREAM_PCAP_AUDIO;
            if ((currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_AUDIO) ||
                (currentAction->getActionType() == CAction::E_AT_PLAY_DTMF)) {
                play_args = &playArgs(RTPSTREAM_PCAP_AUDIO);
            } else if (currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_IMAGE) {
                play_args = &playArgs(RTPSTREAM_PCAP_IMAGE);
                stream = RTPSTREAM_PCAP_IMAGE;
            } else if (currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_VIDEO) {
                play_args = &playArgs(RTPSTREAM_PCAP_VIDEO);
                stream = RTPSTREAM_PCAP_VIDEO;
            } else if (currentAction->getActionType() == CAction::E_AT_PLAY_PCAP_TEXT) {
                play_args = &playArgs(RTPSTREAM_PCAP_TEXT);
                stream = RTPSTREAM_PCAP_TEXT;
            } else {
                ERROR("Can't find pcap data to play");
            }

            /* the playback thread plays a copy, which owns a dtmf pcap */
            if (currentAction->getActionType() == CAction::E_AT_PLAY_DTMF) {
                const std::string digits = createSendingString(currentAction->getMessage());
                play_args->pcap = (pcap_pkts *) malloc(sizeof(pcap_pkts));
                play_args->last_seq_no += parse_dtmf_play_args(digits.c_str(), play_args->pcap, play_args->last_seq_no);
                play_args->free_pcap_when_done = 1;
            } else {
                play_args->pcap = currentAction->getPcapPkts();
                play_args->free_pcap_when_done = 0;
            }

            /* port number is set in [auto_]media_port interpolation; without
             * it, send from the -mp port (+2 for video, +4 for text) rather
             * than port 0 */
            int offset = stream == RTPSTREAM_PCAP_VIDEO ? 2 : stream == RTPSTREAM_PCAP_TEXT ? 4 : 0;
            in_port_t port = htons(media_port + offset);
            if (media_ip_is_ipv6) {
                struct sockaddr_in6* from = (struct sockaddr_in6*) &(play_args->from);
                from->sin6_family = AF_INET6;
                from->sin6_addr = _RCAST(struct sockaddr_in6*, &media_sockaddr)->sin6_addr;
                if (!from->sin6_port) {
                    from->sin6_port = port;
                }
            } else {
                struct sockaddr_in* from = (struct sockaddr_in*) &(play_args->from);
                from->sin_family = AF_INET;
                from->sin_addr = _RCAST(struct sockaddr_in*, &media_sockaddr)->sin_addr;
                if (!from->sin_port) {
                    from->sin_port = port;
                }
            }
            /* Send the RTP or UDPTL packets in the call's RTP playback
             * thread, at once with its plays on the other streams */
            if (!rtpstream_play_pcap(&rtpstream_callinfo, stream, play_args)) {
                ERROR("Can't create thread to send RTP packets");
            }
            play_args->pcap = nullptr;
#endif
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_ECHO) {
            rtp_echo_state.store(currentAction->getDoubleValue() != 0, std::memory_order_relaxed);
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_PAUSE) {
            rtpstream_pause(&rtpstream_callinfo);
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RESUME) {
            rtpstream_resume(&rtpstream_callinfo);
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_WAIT) {
            /* run() holds the next message while the playback lasts */
            unsigned long play_end = rtpstream_play_end(&rtpstream_callinfo);
            if (play_end) {
                unsigned int timeout = (unsigned int)currentAction->getDoubleValue();
                rtpstream_wait_until = timeout ? clock_tick + timeout : 0;
                rtpstream_wait_msg = curmsg;
                rtpstreamWaitNextCheck(play_end);
            }
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STATS) {
            rtpstream_received_t received = rtpstream_received(&rtpstream_callinfo, currentAction->getDoubleValue() != 0);
            M_callVariableTable->getVar(currentAction->getVarId())->setDouble(received.packets);
            if (currentAction->getNbSubVarId() > 0) {
                M_callVariableTable->getVar(currentAction->getSubVarId(0))->setDouble(received.first_pt);
            }
            if (currentAction->getNbSubVarId() > 1) {
                /* the payload in hex */
                static const char digits[] = "0123456789abcdef";
                const std::string& payload = received.first_payload;
                std::string hex(2 * payload.size(), '\0');
                for (size_t i = 0; i < payload.size(); i++) {
                    hex[2 * i] = digits[(unsigned char) payload[i] >> 4];
                    hex[2 * i + 1] = digits[payload[i] & 0x0f];
                }
                M_callVariableTable->getVar(currentAction->getSubVarId(1))->setString(std::move(hex));
            }
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_DTMF) {
            rtpstream_received_t received = rtpstream_received(&rtpstream_callinfo, false);
            /* the payload type, from 0 to 127 */
            int payload_type = (int)currentAction->getDoubleValue();
            std::string digits;
            for (const auto &[pt, digit] : received.dtmf) {
                if (pt == payload_type) {
                    digits += digit;
                }
            }
            M_callVariableTable->getVar(currentAction->getVarId())->setString(std::move(digits));
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_PLAY) {
            currentAction->setRTPStreamActInfo(createSendingString(currentAction->getMessage()).c_str());
            /* A server plays with the keys of its own answer, as it echoes. */
            const bool client = sendMode == MODE_CLIENT;
            startSrtp(false, client, currentAction->getRTPStreamActInfo()->bytes_per_packet);
            rtpstream_play(&rtpstream_callinfo, currentAction->getRTPStreamActInfo(),
                           _srtpAudio.tx(client).forPlayback(), _srtpAudio.rx(client).forPlayback());
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_PAUSEAPATTERN) {
            rtpstream_pauseapattern(&rtpstream_callinfo);
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RESUMEAPATTERN) {
            rtpstream_resumeapattern(&rtpstream_callinfo);
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_PLAYAPATTERN) {
            currentAction->setRTPStreamActInfo(createSendingString(currentAction->getMessage()).c_str());
            /* A server plays with the keys of its own answer, as it echoes. */
            const bool client = sendMode == MODE_CLIENT;
            startSrtp(false, client, currentAction->getRTPStreamActInfo()->bytes_per_packet);

            logSrtpInfo("call::executeAction():  rtpstream_playapattern\n");
            rtpstream_playapattern(&rtpstream_callinfo, currentAction->getRTPStreamActInfo(),
                                   _srtpAudio.tx(client).forPlayback(), _srtpAudio.rx(client).forPlayback());
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_PAUSEVPATTERN) {
            rtpstream_pausevpattern(&rtpstream_callinfo);
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RESUMEVPATTERN) {
            rtpstream_resumevpattern(&rtpstream_callinfo);
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_PLAYVPATTERN) {
            currentAction->setRTPStreamActInfo(createSendingString(currentAction->getMessage()).c_str());
            /* A server plays with the keys of its own answer, as it echoes. */
            const bool client = sendMode == MODE_CLIENT;
            startSrtp(true, client, currentAction->getRTPStreamActInfo()->bytes_per_packet);

            logSrtpInfo("call::executeAction():  rtpstream_playvpattern\n");
            rtpstream_playvpattern(&rtpstream_callinfo, currentAction->getRTPStreamActInfo(),
                                   _srtpVideo.tx(client).forPlayback(), _srtpVideo.rx(client).forPlayback());
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RTPECHO_STARTAUDIO) {
            startUASSrtp(false, currentAction->getRTPEchoActInfo()->bytes_per_packet);

            logSrtpInfo("call::executeAction() [STARTAUDIO]:  rtpstream_rtpecho_startaudio\n");
            rtpstream_rtpecho_startaudio(&rtpstream_callinfo, _srtpAudio.rxUAS.forPlayback(),
                                         _srtpAudio.txUAS.forPlayback());
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RTPECHO_UPDATEAUDIO) {
            startUASSrtp(false, currentAction->getRTPEchoActInfo()->bytes_per_packet);

            logSrtpInfo("call::executeAction() [UPDATEAUDIO]:  rtpstream_rtpecho_updateaudio\n");
            rtpstream_rtpecho_updateaudio(&rtpstream_callinfo, _srtpAudio.rxUAS.forPlayback(),
                                          _srtpAudio.txUAS.forPlayback());
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RTPECHO_STOPAUDIO) {
            logSrtpInfo("call::executeAction() [STOPAUDIO]:  rtpstream_rtpecho_stopaudio\n");
            rc = rtpstream_rtpecho_stopaudio(&rtpstream_callinfo);
            if (rc < 0)
            {
                logSrtpInfo("call::executeAction() [STOPAUDIO]:  rtpstream_rtpecho_stopaudio() rc==%d\n", rc);
                return call::E_AR_RTPECHO_ERROR;
            }
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RTPECHO_STARTVIDEO) {
            startUASSrtp(true, currentAction->getRTPEchoActInfo()->bytes_per_packet);

            logSrtpInfo("call::executeAction() [STARTVIDEO]:  rtpstream_rtpecho_startvideo\n");
            rtpstream_rtpecho_startvideo(&rtpstream_callinfo, _srtpVideo.rxUAS.forPlayback(),
                                         _srtpVideo.txUAS.forPlayback());
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RTPECHO_UPDATEVIDEO) {
            startUASSrtp(true, currentAction->getRTPEchoActInfo()->bytes_per_packet);

            logSrtpInfo("call::executeAction() [UPDATEVIDEO]:  rtpstream_rtpecho_updatevideo\n");
            rtpstream_rtpecho_updatevideo(&rtpstream_callinfo, _srtpVideo.rxUAS.forPlayback(),
                                          _srtpVideo.txUAS.forPlayback());
        } else if (currentAction->getActionType() == CAction::E_AT_RTP_STREAM_RTPECHO_STOPVIDEO) {
            logSrtpInfo("call::executeAction() [STOPVIDEO]:  rtpstream_rtpecho_stopvideo\n");
            rc = rtpstream_rtpecho_stopvideo(&rtpstream_callinfo);
            if (rc < 0)
            {
                logSrtpInfo("call::executeAction() [STOPVIDEO]:  rtpstream_rtpecho_stopvideo() rc==%d\n", rc);
                return call::E_AR_RTPECHO_ERROR;
            }
        } else {
            ERROR("call::executeAction unknown action");
        }
    } // end for
    return(call::E_AR_NO_ERROR);
}

/* What follows matchingString on its line, "" if it is not found */
std::string call::extractSubMessage(const char *msg, const char *matchingString, bool case_indep, int occurrence,
                                    bool headers)
{

    const char *ptr, *ptr1;
    int len = strlen(matchingString);
    char mat1 = tolower(*matchingString);
    char mat2 = toupper(*matchingString);
    /* A header name (an RFC 3261 token, with or without its colon)
     * starts a line and ends at the colon: "To" is neither "Topic:" nor
     * "X-Forward-To:". Any other text ("tag=") is looked for anywhere,
     * or at the start of a line with start_line. */
    int toklen = 0;
    while (matchingString[toklen] &&
           (isalnum((unsigned char)matchingString[toklen]) || strchr("-.!%*_+`'~", matchingString[toklen]))) {
        toklen++;
    }
    bool name = toklen > 0 && (!matchingString[toklen] || !strcmp(matchingString + toklen, ":"));
    bool need_colon = name && !matchingString[toklen];
    if (name) {
        headers = true;
    }

    ptr = msg;
    while (*ptr) {
        if (!case_indep) {
            ptr = strstr(ptr, matchingString);
            if (ptr == nullptr) break;
        } else {
            if (headers) {
                if (ptr != msg) {
                    ptr = strchr(ptr, '\n');
                    if (ptr == nullptr) break;
                    ++ptr;
                    if (*ptr == 0) break;
                }
            } else {
                ptr1 = strchr(ptr, mat1);
                ptr = strchr(ptr, mat2);
                if (ptr == nullptr) {
                    if (ptr1 == nullptr) break;
                    ptr = ptr1;
                } else {
                    if (ptr1 != nullptr && ptr1 < ptr) ptr = ptr1;
                }
            }
            if (strncasecmp(ptr, matchingString, len) != 0) {
                ++ptr;
                continue;
            }
        }
        if (headers && ptr != msg && *(ptr - 1) != '\n') {
            ++ptr;
            continue;
        }
        if (need_colon) {
            ptr1 = ptr + len;
            while (*ptr1 == ' ' || *ptr1 == '\t') {
                ptr1++;
            }
            if (*ptr1 != ':') {
                ++ptr;
                continue;
            }
        }
        // here with ptr pointing to a matching string
        if (occurrence <= 1) break;
        --occurrence;
        ++ptr;
    }

    if (ptr != nullptr && *ptr != 0) {
        const char *rest = ptr + len;
        return std::string(rest, strcspn(rest, "\r\n"));
    }
    return "";
}

std::string call::getFieldFromInputFile(const std::string &fileName, int field, SendingMessage *lineMsg)
{
    if (m_lineNumber == nullptr) {
        ERROR("Automatic calls (created by -aa, -oocsn or -oocsf) cannot use input files!");
    }
    const file_map::iterator in_file = inFiles.find(fileName);
    if (in_file == inFiles.end()) {
        ERROR("Invalid injection file: %s", fileName.c_str());
    }
    int line = (*m_lineNumber)[fileName];
    if (lineMsg) {
        char lineBuffer[64];
        char *endptr;
        createSendingMessage(lineMsg, SM_UNUSED, lineBuffer, sizeof(lineBuffer));
        line = (int) strtod(lineBuffer, &endptr);
        /* Empty, not a number, or too long for the buffer. */
        if (endptr == lineBuffer || *endptr != 0 ||
                strlen(lineBuffer) == sizeof(lineBuffer) - 1) {
            ERROR("Invalid line number generated: '%s'", lineBuffer);
        }
        if (line > in_file->second->numLines()) {
            line = -1;
        }
    }
    if (line < 0) {
        return "";
    }
    return in_file->second->getField(line, field);
}

call::T_AutoMode call::checkAutomaticResponseMode(char* P_recv)
{
    if (strcmp(P_recv, "BYE")==0) {
        return E_AM_UNEXP_BYE;
    } else if (strcmp(P_recv, "CANCEL") == 0) {
        return E_AM_UNEXP_CANCEL;
    } else if (strcmp(P_recv, "PING") == 0) {
        return E_AM_PING;
    } else if (auto_answer &&
               ((strcmp(P_recv, "INFO") == 0) ||
                (strcmp(P_recv, "NOTIFY") == 0) ||
                (strcmp(P_recv, "OPTIONS") == 0) ||
                (strcmp(P_recv, "UPDATE") == 0))) {
        return E_AM_AA;
    } else {
        return E_AM_DEFAULT;
    }
}

void call::setLastMsg(const char *msg)
{
    assign_exact(last_recv_msg, msg);
}

bool call::automaticResponseMode(T_AutoMode P_case, const char* P_recv)
{

    int res ;
    std::string old_last_recv_msg;

    switch (P_case) {
    case E_AM_UNEXP_BYE: // response for an unexpected BYE
        // usage of last_ keywords
        assign_exact(last_recv_msg, P_recv);

        // The BYE is unexpected, count it
        call_scenario->messages[msg_index] -> nb_unexp++;
        if (default_behaviors & DEFAULT_BEHAVIOR_ABORTUNEXP) {
            WARNING("Aborting call on an unexpected BYE for call: %s", (id==nullptr)?"none":id);
            if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
                sendBuffer(createSendingMessage(get_default_message("200")));
            }

            // if twin socket call => reset the other part here
            if (twinSippSocket && (msg_index > 0)) {
                res = sendCmdBuffer(createSendingMessage(get_default_message("3pcc_abort")));
                if (res) {
                    WARNING("sendCmdBuffer returned %d", res);
                    return false;
                }
            }
            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_UNEXPECTED_MSG);
            delete this;
        } else {
            WARNING("Continuing call on an unexpected BYE for call: %s", (id==nullptr)?"none":id);
        }
        break ;

    case E_AM_UNEXP_CANCEL: // response for an unexpected cancel
        // usage of last_ keywords
        assign_exact(last_recv_msg, P_recv);

        // The CANCEL is unexpected, count it
        call_scenario->messages[msg_index] -> nb_unexp++;
        if (default_behaviors & DEFAULT_BEHAVIOR_ABORTUNEXP) {
            WARNING("Aborting call on an unexpected CANCEL for call: %s", (id==nullptr)?"none":id);
            if (default_behaviors & DEFAULT_BEHAVIOR_BYE) {
                sendBuffer(createSendingMessage(get_default_message("200")));
            }

            // if twin socket call => reset the other part here
            if (twinSippSocket && (msg_index > 0)) {
                res = sendCmdBuffer(createSendingMessage(get_default_message("3pcc_abort")));
                if (res) {
                    WARNING("sendCmdBuffer returned %d", res);
                    return false;
                }
            }

            computeStat(CStat::E_CALL_FAILED);
            computeStat(CStat::E_FAILED_UNEXPECTED_MSG);
            delete this;
        } else {
            WARNING("Continuing call on an unexpected CANCEL for call: %s", (id==nullptr)?"none":id);
        }
        break ;

    case E_AM_PING: // response for a random ping
        // usage of last_ keywords
        assign_exact(last_recv_msg, P_recv);

        if (default_behaviors & DEFAULT_BEHAVIOR_PINGREPLY) {
            WARNING("Automatic response mode for an unexpected PING for call: %s", (id==nullptr)?"none":id);
            sendBuffer(createSendingMessage(get_default_message("200")));
            // Note: the call ends here but it is not marked as bad. PING is a
            //       normal message.
            // if twin socket call => reset the other part here
            if (twinSippSocket && (msg_index > 0)) {
                res = sendCmdBuffer(createSendingMessage(get_default_message("3pcc_abort")));
                if (res) {
                    WARNING("sendCmdBuffer returned %d", res);
                    return false;
                }
            }

            CStat::globalStat(CStat::E_AUTO_ANSWERED);
            computeStat(CStat::E_CALL_ENDED_UNCOUNTED);
            delete this;
        } else {
            WARNING("Do not answer on an unexpected PING for call: %s", (id==nullptr)?"none":id);
        }
        break ;

    case E_AM_AA: // response for a random INFO, NOTIFY, OPTIONS or UPDATE
        // store previous last msg if msg is INFO, NOTIFY, OPTIONS or UPDATE
        // restore last_recv_msg to previous one
        // after sending ok
        old_last_recv_msg = std::move(last_recv_msg);
        // usage of last_ keywords
        assign_exact(last_recv_msg, P_recv);

        TRACE_CALLDEBUG("Automatic response mode for an unexpected INFO, NOTIFY, OPTIONS or UPDATE for call: %s",
                        (id == nullptr) ? "none" : id);
        sendBuffer(createSendingMessage(get_default_message("200")));

        // restore previous last msg
        if (!old_last_recv_msg.empty()) {
            last_recv_msg = std::move(old_last_recv_msg);
        }
        CStat::globalStat(CStat::E_AUTO_ANSWERED);
        return true;
        break;

    default:
        ERROR("Internal error for automaticResponseMode - mode %d is not implemented!", P_case);
        break ;
    }

    return false;
}

int call::logSrtpInfo(const char *fmt, ...)
{
    va_list args;

    if (_srtpctxdebugfile != nullptr)
    {
        va_start(args, fmt);
        vfprintf(_srtpctxdebugfile, fmt, args);
        va_end(args);
    }

    return 0;
}

/* The message to send again for a retransmission of the request it
 * answered stays when last_send_msg is about to change: it takes it. */
void call::keepRecvRetransMsg()
{
    if (recv_retrans_last) {
        recv_retrans_msg = std::move(last_send_msg);
        recv_retrans_last = false;
    }
}

/* The context of the call's role that sends, or receives, a media's SRTP,
 * made on use; none in any other mode */
SrtpChannel *call::srtpTx(bool video)
{
    return sendMode == MODE_CLIENT   ? &srtpMedia(video).txUAC.get()
           : sendMode == MODE_SERVER ? &srtpMedia(video).txUAS.get()
                                     : nullptr;
}

SrtpChannel *call::srtpRx(bool video)
{
    return sendMode == MODE_CLIENT   ? &srtpMedia(video).rxUAC.get()
           : sendMode == MODE_SERVER ? &srtpMedia(video).rxUAS.get()
                                     : nullptr;
}

/* The a=crypto lines of an SDP we send, and the address we receive on: the
 * lines, and only those, are the ones an answer can take. */
void call::passLocalSrtp(bool video, SrtpInfoParams &p)
{
    if (SrtpChannel *tx = srtpTx(video)) {
        tx->setCryptoTag(p.primary_cryptotag, PRIMARY_CRYPTO);
        tx->setCryptoTag(p.secondary_cryptotag, SECONDARY_CRYPTO);
        tx->setOfferedCryptoSuite(p.primary_cryptosuite, PRIMARY_CRYPTO);
        tx->setOfferedCryptoSuite(p.secondary_cryptosuite, SECONDARY_CRYPTO);
    }
    if (p.primary_cryptotag == 0) {
        return;
    }

    if (video) {
        rtpstream_set_srtp_video_local(&rtpstream_callinfo, p);
    } else {
        rtpstream_set_srtp_audio_local(&rtpstream_callinfo, p);
    }
    if (sendMode == MODE_CLIENT) {
        CryptoContextID id;
        id.ssrc = video ? rtpstream_callinfo.video_ssrc_id : rtpstream_callinfo.audio_ssrc_id;
        id.address = media_ip;
        id.port = video ? rtpstream_callinfo.local_videoport : rtpstream_callinfo.local_audioport;
        logSrtpInfo("call::createSendingMessage():  RX-UAC-%s SRTP context - ssrc:0x%08x address:%s port:%d\n",
                    video ? "VIDEO" : "AUDIO", id.ssrc, id.address.c_str(), id.port);
        srtpMedia(video).rxUAC->setID(std::move(id));
    }
}

/* An SRTP keyword of a message we send: it sets what the context that sends
 * takes from the keyword, and writes it. */
void call::appendSrtpKeyword(const SrtpKeyword &keyword, const MessageComponent &comp, std::string &out,
                             SrtpInfoParams &p)
{
    const bool primary = keyword.crypto == PRIMARY_CRYPTO;
    SrtpChannel *tx = srtpTx(keyword.video);

    p.found = true;
    switch (keyword.what) {
    case SrtpKeyword::TAG: {
        int &tag = primary ? p.primary_cryptotag : p.secondary_cryptotag;
        tag = primary ? 1 : 2;
        logSrtpInfo("call::createSendingMessage():  %s crypto tag: %d\n", primary ? "PRIMARY" : "SECONDARY", tag);
        if (tx) {
            tx->setCryptoTag(tag, keyword.crypto);
        }
        append_number(out, tag);
        break;
    }
    case SrtpKeyword::SUITE:
    case SrtpKeyword::UNENCRYPTED: {
        const bool unencrypted = keyword.what == SrtpKeyword::UNENCRYPTED;
        const SrtpSuite &suite = *keyword.suite;
        logSrtpInfo("call::createSendingMessage():  %s %s cryptosuite %s\n", keyword.video ? "VIDEO" : "AUDIO",
                    primary ? "PRIMARY" : "SECONDARY", suite.name);
        if (tx) {
            if (tx->selectCipherAlgorithm(unencrypted ? NULL_CIPHER : suite.cipher, keyword.crypto) < 0) {
                ERROR("SRTP crypto suite %s is not supported by the TLS library SIPp is built with", suite.name);
            }
            tx->selectHashAlgorithm(suite.hash, keyword.crypto);
        }
        if (unencrypted) {
            (primary ? p.primary_unencrypted_srtp : p.secondary_unencrypted_srtp) = true;
        } else if (primary) {
            SrtpChannel *rx = srtpRx(keyword.video);
            if ((getSessionStateCurrent() == eNoSession) || (getSessionStateCurrent() == eCompleted)) {
                logSrtpInfo("call::createSendingMessage():  Marking preferred OFFER cryptosuite...\n");
            } else if ((getSessionStateCurrent() == eOfferReceived) && rx && answer_swaps_crypto(*rx, suite.name)) {
                logSrtpInfo("call::createSendingMessage():  Preferred ANSWER cryptosuite mismatch -- SWAPPING...\n");
                rx->swapCrypto();
            }
        }
        snprintf(primary ? p.primary_cryptosuite : p.secondary_cryptosuite, sizeof(p.primary_cryptosuite), "%s",
                 suite.name);
        out += unencrypted ? "UNENCRYPTED_SRTP" : suite.name;
        break;
    }
    case SrtpKeyword::KEYPARAMS: {
        char *keyparams = primary ? p.primary_cryptokeyparams : p.secondary_cryptokeyparams;
        std::string mks;
        if (tx) {
            if (comp.offset >= 0) {
                tx->generateMasterKey(keyword.crypto);
                tx->generateMasterSalt(keyword.crypto);
            }
            tx->encodeMasterKeySalt(mks, keyword.crypto);
            logSrtpInfo("call::createSendingMessage():  %s %s master key/salt: %s\n", primary ? "PRIMARY" : "SECONDARY",
                        comp.offset >= 0 ? "generating new" : "reusing old", mks.c_str());
        }
        snprintf(keyparams, sizeof(p.primary_cryptokeyparams), "%s", mks.c_str());
        out += keyparams;
        break;
    }
    }
}

/* The a=crypto lines of a received SDP's media in the contexts of the role:
 * the one that sends takes the peer's address, and the one that receives
 * the keys the peer sends with. */
void call::takeRemoteSrtp(bool video, const SrtpInfoParams &p, const std::string &host, int port, bool answer)
{
    if (sendMode != MODE_CLIENT && sendMode != MODE_SERVER) {
        return;
    }
    const bool client = sendMode == MODE_CLIENT;
    SrtpMedia &media = srtpMedia(video);
    LazySrtpChannel &tx = media.tx(client);
    LazySrtpChannel &rx = media.rx(client);
    const char *name = video ? (client ? "UAC-VIDEO" : "UAS-VIDEO") : (client ? "UAC-AUDIO" : "UAS-AUDIO");

    CryptoContextID id;
    id.ssrc = video ? rtpstream_callinfo.video_ssrc_id : rtpstream_callinfo.audio_ssrc_id;
    id.address = host;
    id.port = port;
    logSrtpInfo("call::process_incoming():  TX-%s SRTP context - ssrc:0x%08x address:%s port:%d\n", name, id.ssrc,
                id.address.c_str(), id.port);
    tx->setID(std::move(id));

    if (answer) {
        logSrtpInfo("call::process_incoming():  TX-%s SRTP context -- CIPHERSUITE CHOICE...\n", name);
        take_answered_crypto(tx, p, video ? "video" : "audio");
    }

    const struct {
        ActiveCrypto crypto;
        int tag;
        const char *suite, *keyparams;
        bool unencrypted;
    } lines[] = {
        {PRIMARY_CRYPTO, p.primary_cryptotag, p.primary_cryptosuite, p.primary_cryptokeyparams,
         p.primary_unencrypted_srtp},
        {SECONDARY_CRYPTO, p.secondary_cryptotag, p.secondary_cryptosuite, p.secondary_cryptokeyparams,
         p.secondary_unencrypted_srtp},
    };
    for (const auto &line : lines) {
        std::string mks = line.keyparams;
        if (!mks.empty() && decode_srtp_key(rx, mks, line.suite, line.crypto)) {
            logSrtpInfo("call::process_incoming():  RX-%s SRTP context -- %s master key/salt: %s, crypto tag: %d, "
                        "cryptosuite: [%s]%s\n",
                        name, line.crypto == PRIMARY_CRYPTO ? "primary" : "secondary", mks.c_str(), line.tag,
                        line.suite, line.unencrypted ? " UNENCRYPTED_SRTP" : "");
            rx->setCryptoTag(line.tag, line.crypto);
            rx->setOfferedCryptoSuite(line.suite, line.crypto);
            select_srtp_suite(rx, line.suite, line.unencrypted, line.crypto);
        } else {
            // No line, or an ignored one: nothing to receive with in the slot
            rx->setCryptoTag(0, line.crypto);
            rx->setOfferedCryptoSuite("", line.crypto);
        }
    }
}

/* Derives the keys of a media's contexts of the role, now its payload size
 * is known. A call without SRTP has none to derive. The payload size of
 * the codec is assumed the same in both directions. */
void call::startSrtp(bool video, bool client, int payloadSize)
{
    SrtpMedia &media = srtpMedia(video);
    LazySrtpChannel &tx = media.tx(client);
    LazySrtpChannel &rx = media.rx(client);
    if (!tx.made() && !rx.made()) {
        return;
    }

    const char *name = video ? (client ? "UAC-VIDEO" : "UAS-VIDEO") : (client ? "UAC-AUDIO" : "UAS-AUDIO");
    logSrtpInfo("call::executeAction():  TX/RX-%s SRTP contexts - setting SRTP payload size to %d, deriving session "
                "encryption/salting/authentication keys\n",
                name, payloadSize);
    for (LazySrtpChannel *context : {&tx, &rx}) {
        (*context)->setSrtpPayloadSize(payloadSize);
        (*context)->deriveSessionEncryptionKey();
        (*context)->deriveSessionSaltingKey();
        (*context)->deriveSessionAuthenticationKey();
        (*context)->resetCipherState();
    }
    tx->selectEncryptionKey();
    rx->selectDecryptionKey();
    /* Only the playback thread's copies of the contexts, which make
     * their own, use AES once the keys are derived */
    tx->freeCiphers();
    rx->freeCiphers();
}

/* A server echoing or updating its RTP echo: its receiving context's ID, then its keys */
void call::startUASSrtp(bool video, int payloadSize)
{
    SrtpMedia &media = srtpMedia(video);
    if (sendMode != MODE_SERVER || (!media.rxUAS.made() && !media.txUAS.made())) {
        return;
    }

    CryptoContextID id;
    id.ssrc = video ? rtpstream_callinfo.video_ssrc_id : rtpstream_callinfo.audio_ssrc_id;
    id.address = media_ip;
    id.port = video ? rtpstream_callinfo.local_videoport : rtpstream_callinfo.local_audioport;
    logSrtpInfo("call::executeAction():  RX-UAS-%s SRTP context - ssrc:0x%08x address:%s port:%d\n",
                video ? "VIDEO" : "AUDIO", id.ssrc, id.address.c_str(), id.port);
    media.rxUAS->setID(std::move(id));
    startSrtp(video, false, payloadSize);
}

void call::setSessionState(SessionState state)
{
    _sessionStateOld = _sessionStateCurrent;
    _sessionStateCurrent = state;
}

SessionState call::getSessionStateCurrent()
{
    return _sessionStateCurrent;
}

SessionState call::getSessionStateOld()
{
    return _sessionStateOld;
}

#ifdef PCAPPLAY
void rtp_pcap_count(unsigned long bytes)
{
    rtp_pckts_pcap.fetch_add(1, std::memory_order_relaxed);
    rtp_bytes_pcap.fetch_add(bytes, std::memory_order_relaxed);
}
#endif

#ifdef GTEST
#include "gtest/gtest.h"
#include "gtest/gtest.h"

class mockcall : public call {
public:
    mockcall(bool is_ipv6) : listener("//testing", true), call(main_scenario, "///testing", is_ipv6, 0, nullptr) {}
    mockcall(bool is_ipv6, struct sockaddr_storage *dest) : listener("//testing", true), call(main_scenario, "///testing", is_ipv6, 0, dest) {}

    /* Helpers to poke at protected internals */
    using call::createSendingMessage;
    using call::createSendingString;
    using call::extract_rtp_remote_addr;
    void set_last_recv_msg(const char *msg)
    {
        assign_exact(last_recv_msg, msg);
    }
    void parse_media_addr(std::string const& msg) { get_remote_media_addr(msg); }
    int parse_srtp(const char *msg, SrtpInfoParams &pA, SrtpInfoParams &pV)
    {
        return extract_srtp_remote_info(msg, pA, pV);
    }
    void set_retransmission_state(const char *msg, int index, int len, unsigned int retrans_at)
    {
        msg_index = index;
        last_send_index = index;
        keepRecvRetransMsg();
        next_retrans = retrans_at;
        last_send_msg.assign(msg, len);
    }
#ifdef PCAPPLAY
    bool has_media() { return hasMediaInformation; }

    template<typename T>
    T get_addr(rtpstream_pcap_t stream) {
        T sa;
        std::memcpy(&sa, &playArgs(stream).to, sizeof(T));
        return sa;
    }

    template<typename T>
    T get_audio_addr() {
        return get_addr<T>(RTPSTREAM_PCAP_AUDIO);
    }
#endif
};

bool operator==(const struct sockaddr_in& a, const struct sockaddr_in &b) {
    return a.sin_family == b.sin_family
        && a.sin_port == b.sin_port
        && std::memcmp(&a.sin_addr, &b.sin_addr, sizeof(in_addr)) == 0;
}

bool operator==(const struct sockaddr_in6& a, const struct sockaddr_in6 &b) {
    return a.sin6_family == b.sin6_family
        && a.sin6_port == b.sin6_port
        && std::memcmp(&a.sin6_addr, &b.sin6_addr, sizeof(in_addr)) == 0;
}

const std::string test_sdp_v4 = "v=0\r\n"
                                "o=user1 53655765 2353687637 IN IP4 127.0.0.1\r\n"
                                "s=-\r\n"
                                "c=IN IP4 127.0.0.1\r\n"
                                "t=0 0\r\n"
                                "m=audio 12345 RTP/AVP 0\r\n"
                                "a=rtpmap:0 PCMU/8000\r\n";

const std::string test_sdp_v6 = "v=0\r\n"
                                "o=user1 53655765 2353687637 IN IP6 ::1\r\n"
                                "s=-\r\n"
                                "c=IN IP6 ::1\r\n"
                                "t=0 0\r\n"
                                "m=audio 12345 RTP/AVP 0\r\n"
                                "a=rtpmap:0 PCMU/8000\r\n";

static std::string call_id_body(const char *call_id)
{
    const char *separator = strchr(call_id, '@');
    if (!separator) {
        return call_id;
    }
    return std::string(call_id, separator - call_id);
}

static bool is_lower_hex_string(const std::string &value)
{
    return std::all_of(value.begin(), value.end(), [](unsigned char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
    });
}

class call_id_test_state_guard {
public:
    call_id_test_state_guard()
        : saved_call_id_string(call_id_string), saved_call_id_mode(call_id_mode), saved_pid(pid),
          saved_local_ip(local_ip)
    {
    }

    ~call_id_test_state_guard()
    {
        call_id_string = saved_call_id_string;
        call_id_mode = saved_call_id_mode;
        pid = saved_pid;
        local_ip = saved_local_ip;
    }

private:
    const char *saved_call_id_string;
    int saved_call_id_mode;
    unsigned int saved_pid;
    std::string saved_local_ip;
};

TEST(hash, sdbm_hash_four_characters_at_a_time)
{
    const char text[] = "INVITE sip:a@b SIP/2.0\r\n\xe9\x80\xff tail";
    for (size_t len = 0; len < sizeof(text); len++) {
        unsigned long expected = 0;
        for (size_t i = 0; i < len; i++) {
            int c = text[i];
            expected = c + (expected << 6) + (expected << 16) - expected;
        }
        EXPECT_EQ(expected, sdbm_hash(text, len));
    }
}

TEST(call_id, default_mode_uses_cid_str_template) {
    char call_id[MAX_HEADER_LEN];
    call_id_test_state_guard guard;

    call_id_mode = CID_MODE_FORMAT;
    call_id_string = "%u-%p@%s";
    pid = 4321;
    local_ip = "192.0.2.10";

    build_call_id(call_id, 77);
    EXPECT_STREQ("77-4321@192.0.2.10", call_id);
}

TEST(call_id, default_mode_treats_trailing_percent_as_literal) {
    char call_id[MAX_HEADER_LEN];
    call_id_test_state_guard guard;

    call_id_mode = CID_MODE_FORMAT;
    call_id_string = "call-%";

    build_call_id(call_id, 77);
    EXPECT_STREQ("call-%", call_id);
}

TEST(call_id, default_mode_keeps_unknown_conversion) {
    char call_id[MAX_HEADER_LEN];
    call_id_test_state_guard guard;

    call_id_mode = CID_MODE_FORMAT;
    call_id_string = "a%xb%%c%u";

    build_call_id(call_id, 77);
    EXPECT_STREQ("a%xb%c77", call_id);
}

TEST(call_id, uuid_mode_generates_rfc4122_value) {
    char call_id[MAX_HEADER_LEN];
    call_id_test_state_guard guard;

    call_id_mode = CID_MODE_UUID;
    pid = 9001;
    local_ip = "198.51.100.25";

    build_call_id(call_id, 15);

    std::string body = call_id_body(call_id);
    ASSERT_EQ(body.size(), 36U);
    EXPECT_EQ(body[8], '-');
    EXPECT_EQ(body[13], '-');
    EXPECT_EQ(body[18], '-');
    EXPECT_EQ(body[23], '-');
    EXPECT_EQ(body[14], '4');
    EXPECT_TRUE(body[19] == '8' || body[19] == '9' || body[19] == 'a' || body[19] == 'b');
    EXPECT_TRUE(is_lower_hex_string(body.substr(0, 8)));
    EXPECT_TRUE(is_lower_hex_string(body.substr(9, 4)));
    EXPECT_TRUE(is_lower_hex_string(body.substr(14, 4)));
    EXPECT_TRUE(is_lower_hex_string(body.substr(19, 4)));
    EXPECT_TRUE(is_lower_hex_string(body.substr(24, 12)));
    EXPECT_NE(std::string(call_id).find("@198.51.100.25"), std::string::npos);
}

TEST(call_id, uuid_compact_mode_generates_hex_value) {
    char call_id[MAX_HEADER_LEN];
    call_id_test_state_guard guard;

    call_id_mode = CID_MODE_UUID_COMPACT;
    pid = 1337;
    local_ip = "203.0.113.8";

    build_call_id(call_id, 22);

    std::string body = call_id_body(call_id);
    ASSERT_EQ(body.size(), 32U);
    EXPECT_TRUE(is_lower_hex_string(body));
    EXPECT_EQ(body[12], '4');
    EXPECT_TRUE(body[16] == '8' || body[16] == '9' || body[16] == 'a' || body[16] == 'b');
    EXPECT_NE(std::string(call_id).find("@203.0.113.8"), std::string::npos);
}

TEST(call_id, random_mode_generates_unique_token_with_call_number) {
    char call_id[MAX_HEADER_LEN];
    call_id_test_state_guard guard;

    call_id_mode = CID_MODE_RANDOM;
    pid = 5150;
    local_ip = "203.0.113.44";

    build_call_id(call_id, 31);

    std::string body = call_id_body(call_id);
    ASSERT_EQ(body.rfind("31-", 0), 0U);
    ASSERT_EQ(body.size(), 35U);
    EXPECT_TRUE(is_lower_hex_string(body.substr(3)));
    EXPECT_NE(std::string(call_id).find("@203.0.113.44"), std::string::npos);
}

TEST(call_id, timestamp_mode_embeds_call_number_and_pid) {
    char call_id[MAX_HEADER_LEN];
    call_id_test_state_guard guard;

    call_id_mode = CID_MODE_TIMESTAMP;
    pid = 2718;
    local_ip = "192.0.2.44";

    build_call_id(call_id, 52);

    std::string full_call_id(call_id);
    EXPECT_NE(full_call_id.find("-52-2718@192.0.2.44"), std::string::npos);
}

TEST(sdp, parse_valid_sdp_msg) {
    ASSERT_EQ(find_in_sdp("c=IN IP4 ", test_sdp_v4), "127.0.0.1");
    ASSERT_EQ(find_in_sdp("c=IN IP6 ", test_sdp_v6), "::1");
    ASSERT_EQ(find_in_sdp("m=audio ", test_sdp_v4), "12345");
    ASSERT_EQ(find_in_sdp("m=audio ", test_sdp_v6), "12345");
}

TEST(sdp, parse_port_count_and_ttl) {
    const std::string sdp = "v=0\r\n"
                            "c=IN IP4 224.2.1.1/127\r\n"
                            "m=audio 30000/2 RTP/AVP 0 101\r\n";
    ASSERT_EQ(find_in_sdp("c=IN IP4 ", sdp), "224.2.1.1");
    ASSERT_EQ(find_in_sdp("m=audio ", sdp), "30000");
}

TEST(sdp, parse_invalid_sdp_msg) {
    ASSERT_EQ(find_in_sdp("c=IN IP4 ", test_sdp_v6), "");
    ASSERT_EQ(find_in_sdp("c=IN IP6 ", test_sdp_v4), "");
    ASSERT_EQ(find_in_sdp("m=video ", test_sdp_v6), "");
    ASSERT_EQ(find_in_sdp("m=video ", test_sdp_v4), "");
}

TEST(sdp, extract_rtp_remote_addr_skips_zero_port) {
    const std::string msg = "INVITE sip:a@b SIP/2.0\r\n"
                            "Content-Type: application/sdp\r\n\r\n"
                            "v=0\r\n"
                            "c=IN IP6 ::1\r\n"
                            "m=audio 0 RTP/AVP 0\r\n"
                            "m=video 7000/2 RTP/AVP 31\r\n"
                            "m=audio 6000 RTP/AVP 0\r\n";
    mockcall test_call(false);
    std::string audio_host, video_host;
    int audio_port = 0, video_port = 0;

    test_call.extract_rtp_remote_addr(msg.c_str(), audio_host, audio_port, video_host, video_port);
    EXPECT_EQ("::1", audio_host);
    EXPECT_EQ(6000, audio_port);
    EXPECT_EQ("::1", video_host);
    EXPECT_EQ(7000, video_port);
}

/* The connection address of the media section at the first prefix */
static std::string media_connection(std::string_view sdp, std::string_view prefix, bool &ipv6)
{
    return sdp_media_connection(sdp, sdp_media_section(sdp, sdp.find(prefix)), ipv6);
}

TEST(sdp, media_connection_session_level_only) {
    bool ipv6 = true;
    EXPECT_EQ("127.0.0.1", media_connection(test_sdp_v4, "\nm=audio", ipv6));
    EXPECT_FALSE(ipv6);
    EXPECT_EQ("::1", media_connection(test_sdp_v6, "\nm=audio", ipv6));
    EXPECT_TRUE(ipv6);
}

TEST(sdp, media_connection_media_level_only) {
    const std::string sdp = "v=0\r\n"
                            "o=- 1 1 IN IP4 192.0.2.9\r\n"
                            "t=0 0\r\n"
                            "m=audio 6000 RTP/AVP 0\r\n"
                            "c=IN IP4 192.0.2.1\r\n"
                            "m=video 7000 RTP/AVP 31\r\n"
                            "c=IN IP4 192.0.2.2\r\n";
    bool ipv6;
    EXPECT_EQ("192.0.2.1", media_connection(sdp, "\nm=audio", ipv6));
    EXPECT_EQ("192.0.2.2", media_connection(sdp, "\nm=video", ipv6));
    EXPECT_EQ("m=video 7000 RTP/AVP 31\r\nc=IN IP4 192.0.2.2\r\n",
              sdp_media_section(sdp, sdp.find("\nm=video")).substr(1));
}

TEST(sdp, media_connection_overrides_session_level) {
    const std::string sdp = "v=0\r\n"
                            "c=IN IP4 192.0.2.1\r\n"
                            "t=0 0\r\n"
                            "m=audio 6000 RTP/AVP 0\r\n"
                            "m=video 7000 RTP/AVP 31\r\n"
                            "c=IN IP6 2001:db8::2\r\n"
                            "m=image 8000 udptl t38\r\n";
    bool ipv6;
    EXPECT_EQ("192.0.2.1", media_connection(sdp, "\nm=audio", ipv6));
    EXPECT_FALSE(ipv6);
    EXPECT_EQ("2001:db8::2", media_connection(sdp, "\nm=video", ipv6));
    EXPECT_TRUE(ipv6);
    EXPECT_EQ("192.0.2.1", media_connection(sdp, "\nm=image", ipv6));
    EXPECT_FALSE(ipv6);
}

TEST(sdp, extract_rtp_remote_addr_of_each_media_section) {
    const std::string msg = "SIP/2.0 200 OK\r\n"
                            "Content-Type: application/sdp\r\n\r\n"
                            "v=0\r\n"
                            "c=IN IP4 192.0.2.1\r\n"
                            "m=audio 0 RTP/AVP 0\r\n"
                            "c=IN IP4 192.0.2.3\r\n"
                            "m=video 7000 RTP/AVP 31\r\n"
                            "c=IN IP4 192.0.2.2\r\n"
                            "m=audio 6000 RTP/AVP 0\r\n";
    mockcall test_call(false);
    std::string audio_host, video_host;
    int audio_port = 0, video_port = 0;

    test_call.extract_rtp_remote_addr(msg.c_str(), audio_host, audio_port, video_host, video_port);
    EXPECT_EQ("192.0.2.1", audio_host);
    EXPECT_EQ(6000, audio_port);
    EXPECT_EQ("192.0.2.2", video_host);
    EXPECT_EQ(7000, video_port);
}

TEST(create_sending_message, default_ack_with_oversized_peer_headers_is_bounded) {
    /* A peer answers the INVITE with an error response whose Via, From and
     * To headers are ~20 KB each. The built-in ACK echoes all three and
     * repeats the To URI in its request line, so the rendered message is
     * larger than the send buffer. It must be truncated, never written (or
     * later sent) past the end of that buffer. */
    ASSERT_STREQ("ack", default_message_names[1]);

    const std::string big(20000, 'a');
    const std::string received =
        "SIP/2.0 486 Busy Here\r\n"
        "Via: SIP/2.0/UDP " + big + ";branch=z9hG4bK-1\r\n"
        "From: <sip:" + big + "@example.com>;tag=1\r\n"
        "To: <sip:" + big + "@example.com>;tag=2\r\n"
        "Call-ID: 1-1@127.0.0.1\r\n"
        "CSeq: 1 INVITE\r\n"
        "Content-Length: 0\r\n\r\n";
    ASSERT_LT(received.size(), (size_t)SIPP_MAX_MSG_SIZE);

    mockcall test_call(false);
    test_call.set_last_recv_msg(received.c_str());

    SendingMessage ack(main_scenario, default_message_strings[1].c_str(), true);
    int len = -1;
    char *out = test_call.createSendingMessage(&ack, -1, &len);

    ASSERT_NE(nullptr, out);
    /* The buffer holds SIPP_MAX_MSG_SIZE + 2 bytes: the message, its NUL,
     * and one byte kept free for the 3PCC delimiter. */
    EXPECT_EQ(SIPP_MAX_MSG_SIZE, len);
    EXPECT_EQ((size_t)len, strlen(out));
    EXPECT_EQ(0, strncmp(out, "ACK sip:aaaa", 12));
}

TEST(create_sending_message, truncates_to_caller_buffer) {
    mockcall test_call(false);
    SendingMessage msg(main_scenario, "OPTIONS sip:someone@example.com SIP/2.0\n", true);
    char buf[16];
    int len = -1;

    EXPECT_EQ(buf, test_call.createSendingMessage(&msg, -1, buf, sizeof(buf), &len));
    EXPECT_EQ(15, len);
    EXPECT_STREQ("OPTIONS sip:som", buf);
}

TEST(create_sending_message, content_length_counts_the_body) {
    mockcall test_call(false);
    SendingMessage msg(main_scenario, "INVITE sip:a@b SIP/2.0\nContent-Length: [len]\n\nabc\n", true);
    int len = -1;
    const char *out = test_call.createSendingMessage(&msg, -1, &len);

    EXPECT_NE(nullptr, strstr(out, "\r\nContent-Length:     5\r\n\r\nabc\r\n"));
    EXPECT_EQ((size_t)len, strlen(out));
}

TEST(create_sending_message, zero_content_length_keeps_later_headers) {
    mockcall test_call(false);
    SendingMessage msg(main_scenario, "BYE sip:a@b SIP/2.0\nContent-Length: [len]\nX-Foo: bar\n\n", true);
    int len = -1;
    const char *out = test_call.createSendingMessage(&msg, -1, &len);

    EXPECT_STREQ("BYE sip:a@b SIP/2.0\r\nContent-Length:     0\r\nX-Foo: bar\r\n\r\n", out);
    EXPECT_EQ((size_t)len, strlen(out));
}

TEST(create_sending_message, string_leaves_the_message_buffer)
{
    mockcall test_call(false);
    SendingMessage msg(main_scenario, "BYE sip:a@b SIP/2.0\nContent-Length: [len]\n\n", true);
    SendingMessage text(main_scenario, "abc", true);
    const char *out = test_call.createSendingMessage(&msg, -1);

    EXPECT_EQ("abc", test_call.createSendingString(&text));
    EXPECT_STREQ("BYE sip:a@b SIP/2.0\r\nContent-Length:     0\r\n\r\n", out);
}

TEST(call_run, stops_after_fatal_retransmission_send_error) {
    /* Run with a one-message scenario; put the real messages back after. */
    msgvec saved_messages;
    saved_messages.swap(main_scenario->messages);
    auto *msg = new message(0, "retransmission");
    main_scenario->messages.push_back(msg);

    struct sockaddr_storage peer = {};
    auto *peer4 = reinterpret_cast<struct sockaddr_in *>(&peer);
    peer4->sin_family = AF_INET;
    peer4->sin_port = htons(5060);
    ASSERT_EQ(1, inet_pton(AF_INET, "127.0.0.1", &peer4->sin_addr));
    mockcall *test_call = new mockcall(false, &peer);

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    ASSERT_GE(fd, 0);
    test_call->associate_socket(new SIPpSocket(false, T_UDP, fd, 0));
    ASSERT_EQ(0, close(fd));

    /* run() refreshes clock_tick from the monotonic ms clock, and the
     * retransmission only fires when next_retrans < clock_tick. Anchor the
     * deadline to the current tick (never 0, which would disable it) and wait
     * for the clock to move past it, so the test works no matter how early in
     * the process it runs. */
    unsigned long retrans_at = getmilliseconds() + 1;
    while (getmilliseconds() <= retrans_at) {
        usleep(500);
    }
    test_call->set_retransmission_state("REGISTER sip:test SIP/2.0\r\n\r\n", 0, 29, retrans_at);

    EXPECT_FALSE(test_call->run());
    EXPECT_EQ(0UL, msg->nb_sent_retrans);

    main_scenario->messages.swap(saved_messages);
    delete msg;
}

static const char srtp_sdp_head[] = "INVITE sip:t SIP/2.0\r\n\r\n"
                                    "v=0\r\n"
                                    "c=IN IP4 127.0.0.1\r\n"
                                    "t=0 0\r\n";

TEST(srtp_sdp, cryptos_stay_in_their_media_section) {
    std::string msg = std::string(srtp_sdp_head) +
                      "m=audio 12346 RTP/SAVP 0\r\n"
                      "a=crypto:1 AES_CM_128_HMAC_SHA1_80 inline:QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFB\r\n"
                      "a=crypto:2 AES_CM_128_HMAC_SHA1_32 inline:QkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJC UNENCRYPTED_SRTP\r\n"
                      "m=video 12348 RTP/SAVP 99\r\n"
                      "a=crypto:3 AES_CM_128_HMAC_SHA1_80 inline:Q0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0ND UNENCRYPTED_SRTP\r\n";
    SrtpInfoParams pA, pV;
    mockcall call(false);
    ASSERT_EQ(0, call.parse_srtp(msg.c_str(), pA, pV));
    EXPECT_TRUE(pA.found);
    EXPECT_STREQ("QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFB", pA.primary_cryptokeyparams);
    EXPECT_FALSE(pA.primary_unencrypted_srtp);
    EXPECT_TRUE(pA.secondary_unencrypted_srtp);
    EXPECT_TRUE(pV.primary_unencrypted_srtp);
    EXPECT_EQ(1, pA.primary_cryptotag);
    EXPECT_STREQ("AES_CM_128_HMAC_SHA1_80", pA.primary_cryptosuite);
    EXPECT_EQ(2, pA.secondary_cryptotag);
    EXPECT_STREQ("AES_CM_128_HMAC_SHA1_32", pA.secondary_cryptosuite);
    EXPECT_TRUE(pV.found);
    EXPECT_EQ(3, pV.primary_cryptotag);
    EXPECT_EQ(0, pV.secondary_cryptotag);
}

// find_srtp_keyword() indexes the table by the enum
TEST(srtp_sdp, keyword_table_follows_the_enum)
{
    const int rows = sizeof(srtp_keywords) / sizeof(srtp_keywords[0]);

    EXPECT_EQ(E_Message_CryptoSuiteAesCm256Sha1322Video - E_Message_CryptoTag1Audio + 1, rows);
    for (int i = 0; i < rows; i++) {
        EXPECT_EQ(E_Message_CryptoTag1Audio + i, srtp_keywords[i].type) << i;
    }
    EXPECT_EQ(nullptr, find_srtp_keyword(E_Message_RTPStream_Video_Port));
    EXPECT_EQ(&srtp_keywords[rows - 1], find_srtp_keyword(E_Message_CryptoSuiteAesCm256Sha1322Video));
}

TEST(srtp_sdp, rfc6188_keys_are_read_whole) {
    std::string msg = std::string(srtp_sdp_head) +
                      "m=audio 12346 RTP/SAVP 0\r\n"
                      "a=crypto:1 AES_256_CM_HMAC_SHA1_80 inline:QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQQ==\r\n"
                      "a=crypto:2 AES_192_CM_HMAC_SHA1_32 inline:QkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkI= UNENCRYPTED_SRTP\r\n"
                      "m=video 12348 RTP/SAVP 99\r\n"
                      "a=crypto:1 AES_CM_128_HMAC_SHA1_80 inline:Q0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0ND|2^20|1:32\r\n";
    SrtpInfoParams pA, pV;
    mockcall call(false);
    ASSERT_EQ(0, call.parse_srtp(msg.c_str(), pA, pV));
    EXPECT_STREQ("AES_256_CM_HMAC_SHA1_80", pA.primary_cryptosuite);
    EXPECT_STREQ("QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQQ==", pA.primary_cryptokeyparams);
    EXPECT_FALSE(pA.primary_unencrypted_srtp);
    EXPECT_STREQ("AES_192_CM_HMAC_SHA1_32", pA.secondary_cryptosuite);
    EXPECT_STREQ("QkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkI=", pA.secondary_cryptokeyparams);
    EXPECT_TRUE(pA.secondary_unencrypted_srtp);
    // The key without its lifetime and MKI
    EXPECT_STREQ("Q0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0ND", pV.primary_cryptokeyparams);
}

TEST(srtp_sdp, unencrypted_srtp_after_a_lifetime_and_mki) {
    std::string msg = std::string(srtp_sdp_head) +
                      "m=audio 12346 RTP/SAVP 0\r\n"
                      "a=crypto:1 AES_CM_128_HMAC_SHA1_80 inline:QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFB|2^20|1:32 UNENCRYPTED_SRTP\r\n"
                      "a=crypto:2 AES_CM_128_HMAC_SHA1_32 inline:QkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJC KDR=1 UNENCRYPTED_SRTP\r\n"
                      "m=video 12348 RTP/SAVP 99\r\n"
                      "a=crypto:1 AES_CM_128_HMAC_SHA1_80 inline:Q0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0ND UNENCRYPTED_SRTP\r\n"
                      "a=crypto:2 AES_CM_128_HMAC_SHA1_32 inline:RERERERERERERERERERERERERERERERERERE|1:4\r\n";
    SrtpInfoParams pA, pV;
    mockcall call(false);
    ASSERT_EQ(0, call.parse_srtp(msg.c_str(), pA, pV));
    EXPECT_STREQ("QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFB", pA.primary_cryptokeyparams);
    EXPECT_TRUE(pA.primary_unencrypted_srtp);
    EXPECT_TRUE(pA.secondary_unencrypted_srtp);
    EXPECT_TRUE(pV.primary_unencrypted_srtp);
    // The primary's UNENCRYPTED_SRTP is not the secondary's
    EXPECT_EQ(2, pV.secondary_cryptotag);
    EXPECT_STREQ("RERERERERERERERERERERERERERERERERERE", pV.secondary_cryptokeyparams);
    EXPECT_FALSE(pV.secondary_unencrypted_srtp);
}

// A received key of the length its suite takes, whether it encrypts or not
TEST(srtp_sdp, received_key_of_its_suite_length) {
    JLSRTP rx(0x12345678, "127.0.0.1", 0);
    std::string aes128 = "AQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0e";
    std::string aes192 = "AQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhIiMkJSY=";
    std::string aes256 = "AQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhIiMkJSYnKCkqKywtLg==";
    std::string odd = "AQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhIiMkJSYnKCkqKywt";

    EXPECT_TRUE(decode_srtp_key(rx, aes128, "AES_CM_128_HMAC_SHA1_80", PRIMARY_CRYPTO));
    EXPECT_TRUE(decode_srtp_key(rx, aes128, "NULL_HMAC_SHA1_32", SECONDARY_CRYPTO));
    EXPECT_TRUE(decode_srtp_key(rx, aes192, "AES_192_CM_HMAC_SHA1_32", PRIMARY_CRYPTO));
    EXPECT_TRUE(decode_srtp_key(rx, aes256, "AES_256_CM_HMAC_SHA1_80", SECONDARY_CRYPTO));
    EXPECT_EQ(32U, rx.getMasterKey(SECONDARY_CRYPTO).size());

    EXPECT_FALSE(decode_srtp_key(rx, aes256, "AES_CM_128_HMAC_SHA1_80", SECONDARY_CRYPTO));
    EXPECT_FALSE(decode_srtp_key(rx, aes128, "AES_256_CM_HMAC_SHA1_32", SECONDARY_CRYPTO));
    EXPECT_FALSE(decode_srtp_key(rx, aes256, "AES_192_CM_HMAC_SHA1_80", SECONDARY_CRYPTO));
    EXPECT_FALSE(decode_srtp_key(rx, odd, "AES_CM_128_HMAC_SHA1_80", SECONDARY_CRYPTO));
    EXPECT_EQ(32U, rx.getMasterKey(SECONDARY_CRYPTO).size());
}

TEST(srtp_sdp, answer_takes_a_line_of_its_suite) {
    JLSRTP ctx(0x12345678, "127.0.0.1", 0);

    // Neither line taken: none is of any suite, the default one included
    EXPECT_EQ(INVALID_CRYPTO, find_crypto_line(ctx, 1, "AES_CM_128_HMAC_SHA1_80"));
    EXPECT_EQ(INVALID_CRYPTO, find_crypto_line(ctx, 0, "AES_CM_128_HMAC_SHA1_80"));

    // The first line ignored, the second one taken
    ctx.setCryptoTag(2, SECONDARY_CRYPTO);
    ctx.setOfferedCryptoSuite("AES_CM_128_HMAC_SHA1_80", SECONDARY_CRYPTO);
    EXPECT_EQ(SECONDARY_CRYPTO, find_crypto_line(ctx, 1, "AES_CM_128_HMAC_SHA1_80"));
    EXPECT_EQ(INVALID_CRYPTO, find_crypto_line(ctx, 2, "AES_CM_128_HMAC_SHA1_32"));

    // Both taken: the line of the tag if it is of the suite, else by suite
    ctx.setCryptoTag(1, PRIMARY_CRYPTO);
    ctx.setOfferedCryptoSuite("AES_CM_128_HMAC_SHA1_32", PRIMARY_CRYPTO);
    EXPECT_EQ(PRIMARY_CRYPTO, find_crypto_line(ctx, 1, "AES_CM_128_HMAC_SHA1_32"));
    EXPECT_EQ(PRIMARY_CRYPTO, find_crypto_line(ctx, 2, "AES_CM_128_HMAC_SHA1_32"));
    EXPECT_EQ(SECONDARY_CRYPTO, find_crypto_line(ctx, 1, "AES_CM_128_HMAC_SHA1_80"));
    EXPECT_EQ(INVALID_CRYPTO, find_crypto_line(ctx, 1, "NULL_HMAC_SHA1_80"));
    // A whole name, not a prefix
    EXPECT_EQ(INVALID_CRYPTO, find_crypto_line(ctx, 1, "AES_CM_128"));
    EXPECT_EQ(INVALID_CRYPTO, find_crypto_line(ctx, 1, ""));
    ctx.setOfferedCryptoSuite("AES_CM_128_HMAC_SHA1_32", SECONDARY_CRYPTO);
    EXPECT_EQ(SECONDARY_CRYPTO, find_crypto_line(ctx, 2, "AES_CM_128_HMAC_SHA1_32"));
    EXPECT_EQ(PRIMARY_CRYPTO, find_crypto_line(ctx, 3, "AES_CM_128_HMAC_SHA1_32"));

    // Only the first line taken
    ctx.setCryptoTag(0, SECONDARY_CRYPTO);
    EXPECT_EQ(INVALID_CRYPTO, find_crypto_line(ctx, 2, "AES_CM_128_HMAC_SHA1_80"));
    EXPECT_FALSE(answer_swaps_crypto(ctx, "AES_CM_128_HMAC_SHA1_32"));
}

TEST(srtp_sdp, offerer_sends_with_the_answered_line) {
    SrtpInfoParams p = {};
    p.primary_cryptotag = 1;
    strcpy(p.primary_cryptosuite, "AES_CM_128_HMAC_SHA1_32");
    JLSRTP tx(0x12345678, "127.0.0.1", 0);
    tx.setCryptoTag(1, PRIMARY_CRYPTO);
    tx.setOfferedCryptoSuite("AES_CM_128_HMAC_SHA1_80", PRIMARY_CRYPTO);

    // One line offered, another suite answered: no SRTP
    take_answered_crypto(tx, p, "audio");
    EXPECT_EQ(0U, tx.getCryptoTag(PRIMARY_CRYPTO));

    // Two lines offered, the second one's suite answered with tag 1
    tx.setCryptoTag(1, PRIMARY_CRYPTO);
    tx.setCryptoTag(2, SECONDARY_CRYPTO);
    tx.selectHashAlgorithm(HMAC_SHA1_32, SECONDARY_CRYPTO);
    tx.setOfferedCryptoSuite("AES_CM_128_HMAC_SHA1_32", SECONDARY_CRYPTO);
    take_answered_crypto(tx, p, "audio");
    EXPECT_EQ(2U, tx.getCryptoTag(PRIMARY_CRYPTO));
    EXPECT_EQ("AES_CM_128_HMAC_SHA1_32", tx.getCryptoSuite(PRIMARY_CRYPTO));
    EXPECT_EQ(HMAC_SHA1_32, tx.getHashAlgorithm(PRIMARY_CRYPTO));
    EXPECT_EQ("AES_CM_128_HMAC_SHA1_80", tx.getCryptoSuite(SECONDARY_CRYPTO));
}

TEST(srtp_sdp, plain_audio_does_not_take_the_video_crypto) {
    std::string msg = std::string(srtp_sdp_head) +
                      "m=audio 12346 RTP/AVP 0\r\n"
                      "a=rtpmap:0 PCMU/8000\r\n"
                      "m=video 12348 RTP/SAVP 99\r\n"
                      "a=crypto:3 AES_CM_128_HMAC_SHA1_80 inline:Q0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0ND\r\n";
    SrtpInfoParams pA, pV;
    mockcall call(false);
    ASSERT_EQ(0, call.parse_srtp(msg.c_str(), pA, pV));
    EXPECT_EQ(0, pA.primary_cryptotag);
    EXPECT_STREQ("", pA.primary_cryptosuite);
    EXPECT_EQ(3, pV.primary_cryptotag);
}

TEST(srtp_sdp, plain_video_first_does_not_take_the_audio_crypto) {
    std::string msg = std::string(srtp_sdp_head) +
                      "m=video 12348 RTP/AVP 99\r\n"
                      "m=audio 12346 RTP/SAVP 0\r\n"
                      "a=crypto:1 AES_CM_128_HMAC_SHA1_80 inline:QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFB\r\n"
                      "a=crypto:2 AES_CM_128_HMAC_SHA1_32 inline:QkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJC\r\n";
    SrtpInfoParams pA, pV;
    mockcall call(false);
    ASSERT_EQ(0, call.parse_srtp(msg.c_str(), pA, pV));
    EXPECT_EQ(1, pA.primary_cryptotag);
    EXPECT_EQ(2, pA.secondary_cryptotag);
    EXPECT_EQ(0, pV.primary_cryptotag);
    EXPECT_EQ(0, pV.secondary_cryptotag);
}

#ifdef PCAPPLAY
TEST(sdp, good_remote_media_addr_v4) {
    media_ip_is_ipv6 = false;
    pcap_plays = true;

    struct sockaddr_in reference;
    reference.sin_family = AF_INET;
    reference.sin_port = htons(12345);
    inet_pton(AF_INET, "127.0.0.1", &reference.sin_addr);

    mockcall call(false);
    call.parse_media_addr(test_sdp_v4);
    ASSERT_EQ(call.has_media(), true);
    ASSERT_EQ(reference, call.get_audio_addr<struct sockaddr_in>());
}

TEST(sdp, good_remote_media_addr_v6) {
    media_ip_is_ipv6 = true;
    pcap_plays = true;

    struct sockaddr_in6 reference;
    reference.sin6_family = AF_INET6;
    reference.sin6_port = htons(12345);
    inet_pton(AF_INET6, "::1", &reference.sin6_addr);

    mockcall call(true);
    call.parse_media_addr(test_sdp_v6);
    ASSERT_EQ(call.has_media(), true);
    ASSERT_EQ(reference, call.get_audio_addr<struct sockaddr_in6>());
}

TEST(sdp, remote_media_addr_of_each_media_section) {
    media_ip_is_ipv6 = false;
    pcap_plays = true;

    struct sockaddr_in audio, video;
    audio.sin_family = video.sin_family = AF_INET;
    audio.sin_port = htons(6000);
    video.sin_port = htons(7000);
    inet_pton(AF_INET, "192.0.2.1", &audio.sin_addr);
    inet_pton(AF_INET, "192.0.2.2", &video.sin_addr);

    mockcall call(false);
    call.parse_media_addr("v=0\r\n"
                          "c=IN IP4 192.0.2.1\r\n"
                          "m=audio 6000 RTP/AVP 0\r\n"
                          "m=video 7000 RTP/AVP 31\r\n"
                          "c=IN IP4 192.0.2.2\r\n");
    ASSERT_EQ(call.has_media(), true);
    ASSERT_EQ(audio, call.get_addr<struct sockaddr_in>(RTPSTREAM_PCAP_AUDIO));
    ASSERT_EQ(video, call.get_addr<struct sockaddr_in>(RTPSTREAM_PCAP_VIDEO));
}

TEST(sdp, remote_media_addr_of_text)
{
    media_ip_is_ipv6 = false;
    pcap_plays = true;

    struct sockaddr_in text;
    text.sin_family = AF_INET;
    text.sin_port = htons(8000);
    inet_pton(AF_INET, "192.0.2.1", &text.sin_addr);

    mockcall call(false);
    call.parse_media_addr("v=0\r\n"
                          "c=IN IP4 192.0.2.1\r\n"
                          "m=audio 6000 RTP/AVP 0\r\n"
                          "m=video 0 RTP/AVP 31\r\n"
                          "m=text 8000 RTP/AVP 98 100\r\n"
                          "a=rtpmap:98 t140/1000\r\n"
                          "a=rtpmap:100 red/1000\r\n");
    ASSERT_EQ(call.has_media(), true);
    ASSERT_EQ(text, call.get_addr<struct sockaddr_in>(RTPSTREAM_PCAP_TEXT));
}

TEST(sdp, remote_media_addr_skips_zero_port) {
    media_ip_is_ipv6 = false;
    pcap_plays = true;

    struct sockaddr_in audio;
    audio.sin_family = AF_INET;
    audio.sin_port = htons(6000);
    inet_pton(AF_INET, "192.0.2.3", &audio.sin_addr);

    mockcall call(false);
    call.parse_media_addr("v=0\r\n"
                          "c=IN IP4 192.0.2.1\r\n"
                          "m=audio 0 RTP/AVP 0\r\n"
                          "m=video 7000 RTP/AVP 31\r\n"
                          "m=audio 6000 RTP/AVP 8\r\n"
                          "c=IN IP4 192.0.2.3\r\n");
    ASSERT_EQ(audio, call.get_addr<struct sockaddr_in>(RTPSTREAM_PCAP_AUDIO));
}

/* The RTP payload type of packet n of a play_dtmf; the first 20 are
 * no-ops. */
static int dtmf_payload_type(const char* args, int n)
{
    pcap_pkts* pkts = (pcap_pkts*) malloc(sizeof(pcap_pkts));
    parse_dtmf_play_args(args, pkts, 0);
    int pt = pkts->pkts[n].data[sizeof(struct udphdr) + 1] & 0x7f;
    free_pcaps(pkts);
    return pt;
}

TEST(extract_cseq_method, method) {
    char method[16];
    call::extract_cseq_method(method, sizeof(method), "SIP/2.0 200 OK\r\nCSeq: 2 BYE\r\n\r\n");
    EXPECT_STREQ("BYE", method);
    call::extract_cseq_method(method, sizeof(method), "SIP/2.0 200 OK\r\n\r\n");
    EXPECT_STREQ("", method);
}

TEST(extract_cseq_method, only_the_cseq_header)
{
    char method[16];
    call::extract_cseq_method(method, sizeof(method), "SIP/2.0 200 OK\r\ncseq: 2 BYE\r\n\r\n");
    EXPECT_STREQ("BYE", method);
    call::extract_cseq_method(method, sizeof(method),
                              "SIP/2.0 200 OK\r\nX-Orig-CSeq: 1 OPTIONS\r\nCSeq: 2 BYE\r\n\r\n");
    EXPECT_STREQ("BYE", method);
    call::extract_cseq_method(method, sizeof(method), "SIP/2.0 200 OK\r\nCSEQ: 2 BYE\r\n\r\nCSeq: 1 INFO\r\n");
    EXPECT_STREQ("BYE", method);
    call::extract_cseq_method(method, sizeof(method), "SIP/2.0 200 OK\r\n\r\nCSeq: 1 INFO\r\n");
    EXPECT_STREQ("", method);
}

TEST(extract_cseq_method, long_method_is_truncated) {
    std::string msg = "SIP/2.0 200 OK\r\nCSeq: 1 " + std::string(3000, 'X') + "\r\n\r\n";
    char method[16];
    call::extract_cseq_method(method, sizeof(method), msg.c_str());
    EXPECT_STREQ(std::string(sizeof(method) - 1, 'X').c_str(), method);
}

TEST(play_dtmf, payload_type) {
    EXPECT_EQ(96, dtmf_payload_type("1", 20));
    EXPECT_EQ(96, dtmf_payload_type("1,100", 20));
    EXPECT_EQ(101, dtmf_payload_type("1,100,101", 20));
    EXPECT_EQ(97, dtmf_payload_type("1,100,101", 0));
    EXPECT_EQ(96, dtmf_payload_type("1,100,97", 0));
    EXPECT_EQ(96, dtmf_payload_type("1,100,", 20));
    /* an invalid one falls back to the default */
    EXPECT_EQ(96, dtmf_payload_type("1,100,foo", 20));
    EXPECT_EQ(96, dtmf_payload_type("1,100,128", 20));
}

/* What parse_dtmf says of args, NULL if it is valid, with the values
 * it parsed. */
static const char *dtmf_error(std::string args, unsigned long *tone_len = nullptr, uint8_t *payload_type = nullptr)
{
    unsigned long len;
    uint8_t pt;
    const char *error = parse_dtmf(args.data(), &len, &pt);
    if (tone_len) {
        *tone_len = len;
    }
    if (payload_type) {
        *payload_type = pt;
    }
    return error;
}

TEST(play_dtmf, parse) {
    unsigned long len;
    uint8_t pt;

    EXPECT_EQ(nullptr, dtmf_error("1", &len, &pt));
    EXPECT_EQ(200u, len);
    EXPECT_EQ(96, pt);
    EXPECT_EQ(nullptr, dtmf_error("x1,,", &len, &pt));
    EXPECT_EQ(200u, len);
    EXPECT_EQ(96, pt);
    EXPECT_EQ(nullptr, dtmf_error("*#ABCD,50,0", &len, &pt));
    EXPECT_EQ(50u, len);
    EXPECT_EQ(0, pt);
    EXPECT_EQ(nullptr, dtmf_error("1,2000,127", &len, &pt));
    EXPECT_EQ(2000u, len);
    EXPECT_EQ(127, pt);

    EXPECT_NE(nullptr, dtmf_error(""));
    EXPECT_NE(nullptr, dtmf_error("abc,100"));
    EXPECT_NE(nullptr, dtmf_error(",100"));

    EXPECT_NE(nullptr, dtmf_error("1,49", &len, &pt));
    EXPECT_EQ(200u, len);
    EXPECT_NE(nullptr, dtmf_error("1,2001"));
    EXPECT_NE(nullptr, dtmf_error("1,foo"));
    EXPECT_NE(nullptr, dtmf_error("1,100x"));

    EXPECT_NE(nullptr, dtmf_error("1,100,foo", &len, &pt));
    EXPECT_EQ(100u, len);
    EXPECT_EQ(96, pt);
    EXPECT_NE(nullptr, dtmf_error("1,100,101x"));
    EXPECT_NE(nullptr, dtmf_error("1,100,128"));
    EXPECT_NE(nullptr, dtmf_error("1,100,-1"));
    EXPECT_NE(nullptr, dtmf_error("1,100,101,1"));

    /* the first problem is the one told */
    EXPECT_NE(nullptr, strstr(dtmf_error("1,10,128"), "tone length"));
}

/* The packets that arrive on a UDP socket, until none does for 50 ms */
static int count_packets(int sock)
{
    char buffer[PCAP_MAXPACKET];
    struct pollfd pfd = {sock, POLLIN, 0};
    int n = 0;
    while (poll(&pfd, 1, 50) > 0 && recv(sock, buffer, sizeof(buffer), 0) > 0) {
        n++;
    }
    return n;
}

TEST(send_packets_due, capture_pacing) {
    /* a capture that starts at 0, and whose 4th packet appears before
     * the 3rd one: played from 1 ms, it starts at 20 ms, where the 1st
     * two leave, the 3rd and 4th 20 ms later, and the 5th 30.5 ms after
     * the 4th, in that millisecond */
    const long ts_us[] = {0, 0, 20000, 10000, 40500};
    pcap_pkt pkts_list[5];
    u_char data[5][sizeof(struct udphdr) + 4] = {};
    for (int i = 0; i < 5; i++) {
        pkts_list[i].data = data[i];
        pkts_list[i].pktlen = sizeof(data[i]);
        pkts_list[i].ts.tv_sec = ts_us[i] / 1000000;
        pkts_list[i].ts.tv_usec = ts_us[i] % 1000000;
        pkts_list[i].partial_check = 0;
    }
    pcap_pkts pkts = {};
    pkts.pkts = pkts_list;
    pkts.max = pkts_list + 5;

    /* sent on a UDP socket to another, the UDP header in the payload */
    int receiver = socket(AF_INET, SOCK_DGRAM, 0);
    int sender = socket(AF_INET, SOCK_DGRAM, 0);
    ASSERT_GE(receiver, 0);
    ASSERT_GE(sender, 0);
    play_args_t play = {};
    struct sockaddr_in* to = (struct sockaddr_in*) &play.to;
    to->sin_family = AF_INET;
    to->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    ASSERT_EQ(0, bind(receiver, (struct sockaddr*) to, sizeof(*to)));
    socklen_t len = sizeof(*to);
    ASSERT_EQ(0, getsockname(receiver, (struct sockaddr*) to, &len));
    play.from.ss_family = AF_INET;
    play.pcap = &pkts;
    const bool was_ipv6 = media_ip_is_ipv6;
    media_ip_is_ipv6 = false;

    unsigned long long due = 0;
    EXPECT_EQ(1, send_packets_due(sender, &play, 1000, &due));
    EXPECT_EQ(20000u, due);
    EXPECT_EQ(0, count_packets(receiver));
    EXPECT_EQ(1, send_packets_due(sender, &play, 20000, &due));
    EXPECT_EQ(40000u, due);
    EXPECT_EQ(2, count_packets(receiver));
    EXPECT_EQ(1, send_packets_due(sender, &play, 39999, &due));
    EXPECT_EQ(40000u, due);
    EXPECT_EQ(0, count_packets(receiver));
    EXPECT_EQ(1, send_packets_due(sender, &play, 40000, &due));
    EXPECT_EQ(70000u, due);
    EXPECT_EQ(2, count_packets(receiver));
    EXPECT_EQ(0, send_packets_due(sender, &play, 70000, &due));
    EXPECT_EQ(1, count_packets(receiver));

    media_ip_is_ipv6 = was_ipv6;
    close(sender);
    close(receiver);
}

TEST(send_packets_due, full_send_buffer) {
    /* two packets at once */
    pcap_pkt pkts_list[2];
    u_char data[2][sizeof(struct udphdr) + 4] = {};
    for (int i = 0; i < 2; i++) {
        pkts_list[i].data = data[i];
        pkts_list[i].pktlen = sizeof(data[i]);
        pkts_list[i].ts.tv_sec = 0;
        pkts_list[i].ts.tv_usec = 0;
        pkts_list[i].partial_check = 0;
    }
    pcap_pkts pkts = {};
    pkts.pkts = pkts_list;
    pkts.max = pkts_list + 2;

    /* sent on a TCP connection, which ignores the address, and whose
     * send buffer fills up as the other end reads none */
    int listener = socket(AF_INET, SOCK_STREAM, 0);
    int sender = socket(AF_INET, SOCK_STREAM, 0);
    ASSERT_GE(listener, 0);
    ASSERT_GE(sender, 0);
    int small = 4096;
    setsockopt(listener, SOL_SOCKET, SO_RCVBUF, &small, sizeof(small));
    setsockopt(sender, SOL_SOCKET, SO_SNDBUF, &small, sizeof(small));
    play_args_t play = {};
    struct sockaddr_in* to = (struct sockaddr_in*) &play.to;
    to->sin_family = AF_INET;
    to->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    ASSERT_EQ(0, bind(listener, (struct sockaddr*) to, sizeof(*to)));
    socklen_t len = sizeof(*to);
    ASSERT_EQ(0, getsockname(listener, (struct sockaddr*) to, &len));
    ASSERT_EQ(0, listen(listener, 1));
    ASSERT_EQ(0, connect(sender, (struct sockaddr*) to, sizeof(*to)));
    int receiver = accept(listener, nullptr, nullptr);
    ASSERT_GE(receiver, 0);
    char buffer[4096] = {};
    while (send(sender, buffer, sizeof(buffer), MSG_DONTWAIT) > 0) {
    }
    play.from.ss_family = AF_INET;
    play.pcap = &pkts;
    const bool was_ipv6 = media_ip_is_ipv6;
    media_ip_is_ipv6 = false;

    /* the play, started on a multiple of 20 ms, waits for the socket,
     * 1 ms at a time */
    unsigned long long due = 0;
    EXPECT_EQ(1, send_packets_due(sender, &play, 20000, &due));
    EXPECT_EQ(21000u, due);
    EXPECT_EQ(pkts_list, play.next);
    EXPECT_EQ(1, send_packets_due(sender, &play, 21000, &due));
    EXPECT_EQ(22000u, due);
    EXPECT_EQ(pkts_list, play.next);

    /* and sends both packets once the other end has read */
    struct pollfd pfd = {receiver, POLLIN, 0};
    while (poll(&pfd, 1, 50) > 0 && recv(receiver, buffer, sizeof(buffer), 0) > 0) {
    }
    EXPECT_EQ(0, send_packets_due(sender, &play, 22000, &due));
    EXPECT_EQ(pkts.max, play.next);

    media_ip_is_ipv6 = was_ipv6;
    close(sender);
    close(receiver);
    close(listener);
}
#endif /* PCAP_PLAY */
#endif
