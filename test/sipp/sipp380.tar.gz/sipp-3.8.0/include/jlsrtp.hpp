/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA
 *
 *  Author: Jeannot Langlois (jeannot.langlois@gmail.com) -- 2016-2020
 */

#ifndef __JLSRTP__
#define __JLSRTP__

#if defined(USE_OPENSSL)
#include <openssl/aes.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/hmac.h>
#elif defined(USE_WOLFSSL)
#include <wolfssl/options.h>
#include <wolfssl/openssl/aes.h>
#include <wolfssl/openssl/evp.h>
#include <wolfssl/openssl/rand.h>
#include <wolfssl/openssl/hmac.h>
#endif

#include <array>
#include <memory>
#include <string>

#if defined(USE_OPENSSL) || defined(USE_WOLFSSL)

#include <vector>

#define JLSRTP_VERSION              0.7
#define JLSRTP_ENCRYPTION_KEY_LENGTH        16  // bytes
#define JLSRTP_AES_192_KEY_LENGTH           24  // bytes
#define JLSRTP_AES_256_KEY_LENGTH           32  // bytes
#define JLSRTP_SALTING_KEY_LENGTH           14  // bytes
#define JLSRTP_AUTHENTICATION_KEY_LENGTH    20  // bytes

#define JLSRTP_MAX_SEQUENCE_NUMBERS         65536

#define JLSRTP_PSEUDORANDOM_BITS        128
#define JLSRTP_KEY_ENCRYPTION_LABEL     0x00
#define JLSRTP_KEY_AUTHENTICATION_LABEL     0x01
#define JLSRTP_KEY_SALTING_LABEL        0x02

#define JLSRTP_SHA1_HASH_LENGTH         20

#define JLSRTP_SRTP_DEFAULT_HEADER_SIZE     12  // bytes

#define JLSRTP_AUTHENTICATION_TAG_SIZE_SHA1_80  10  // bytes
#define JLSRTP_AUTHENTICATION_TAG_SIZE_SHA1_32  4   // bytes

static const std::string base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

typedef struct _CryptoContextID
{
    unsigned int ssrc;    // SSRC
    std::string address;  // IP address
    unsigned short port;  // port
} CryptoContextID;

/* An AES context, made with its first key: AES-ECB, or AES-CTR for the
 * keystream of packets. */
class AESCipher
{
public:
    /* Makes the context if there is none. False if it cannot be made. */
    bool make();
    /* Sets the key for AES-ECB, switching to the AES variant of its
     * length. Returns 1 on success, as EVP_EncryptInit_ex() does. */
    int setKey(const std::vector<unsigned char>& key);
    int setKey(const unsigned char *key, size_t length);
    /* Whether the TLS library has AES-CTR for a key of length bytes */
    static bool hasCtr(size_t length);
    /* AES-CTR of length bytes of in to out with key, from the counter
     * block iv. Returns 1 on success. */
    int ctr(const unsigned char *key, size_t key_length, const unsigned char *iv, const unsigned char *in,
            unsigned char *out, int length);
    EVP_CIPHER_CTX* get() const { return ctx.get(); }
    void free() { ctx.reset(); }

private:
    int init(const unsigned char *key, size_t length, const unsigned char *iv, bool ctr);

    struct Free
    {
        void operator()(EVP_CIPHER_CTX* c) const { EVP_CIPHER_CTX_free(c); }
    };
    std::unique_ptr<EVP_CIPHER_CTX, Free> ctx;
};

typedef struct _AESState
{
    unsigned char ivec[AES_BLOCK_SIZE];   // ivec[0..13] (high-order bytes): 'IV' / ivec[14..15] (low-order bytes): 'counter'
    unsigned int num;                     // block byte offset
    unsigned char ecount[AES_BLOCK_SIZE]; // encrypted ivec
    AESCipher cipher;                     // Cipher context
} AESState;

typedef enum _CipherType
{
    AES_CM_128,
    NULL_CIPHER,
    AES_CM_192, // RFC 6188
    AES_CM_256, // RFC 6188
    INVALID_CIPHER
} CipherType;

typedef enum _HashType
{
    HMAC_SHA1_80,
    HMAC_SHA1_32,
    NULL_HASH,
    INVALID_HASH
} HashType;

typedef struct _CryptoAttribute
{
    CipherType              cipher_algorithm;
    HashType                hmac_algorithm;
    bool                    MKI;
    unsigned int            MKI_length;
    unsigned long           active_MKI;
    std::vector<unsigned char>      master_key;
    unsigned long           master_key_counter;
    unsigned short          n_e;
    unsigned short          n_a;
    std::vector<unsigned char>      master_salt;
    /* The suite as a peer's a=crypto line named it, which differs from
     * the cipher in use for an UNENCRYPTED_SRTP line. */
    std::string             offered_suite;
    unsigned long           master_key_derivation_rate;
    unsigned long           master_mki_value;
    unsigned short          n_s;
    unsigned int                        tag;
} CryptoAttribute;

typedef enum _ActiveCrypto
{
    PRIMARY_CRYPTO,
    SECONDARY_CRYPTO,
    ACTIVE_CRYPTO,
    INVALID_CRYPTO
} ActiveCrypto;

class JLSRTP
{
    private:
        CryptoContextID _id;
        CryptoAttribute         _primary_crypto;
        CryptoAttribute                 _secondary_crypto;
        ActiveCrypto            _active_crypto;
        std::vector<unsigned char>  _session_enc_key;
        std::vector<unsigned char>  _session_salt_key;
        std::vector<unsigned char> _session_auth_key;
        AESState _pseudorandomstate;
        unsigned int            _srtp_header_size;
        unsigned int            _srtp_payload_size;

        /**
         * isBase64
         *
         * Checks whether the given character satisfies base64 criteria (true) or not (false)
         *
         * @param[in]   c   Unsigned character to examine
         *
         * @return  TRUE    Given character satisfies base64 criteria
         * @return  FALSE   Given character DOES NOT satisfy base64 criteria
         */
        bool isBase64(unsigned char c);

        /**
         * resetPseudoRandomState
         *
         * Resets the state of the AES counter mode pseudo random function
         *
         * @param[in]       iv  Input vector to use
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int resetPseudoRandomState(const std::vector<unsigned char> &iv);

        /**
         * pseudorandomFunction
         *
         * Generates the given number of key stream bits from the given master key and input vector
         *
         * @param[in]   iv      Input vector to use
         * @param[in]   n       Number of keystream bits to generate
         * @param[out]  output      Generated keystream bits
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Incorrect salting key length
         * @return  -2  FAILURE -- Incorrect encryption key length
         * @return  -3  FAILURE -- Could not set encryption key
         * @return  -4  FAILURE -- Invalid crypto attribute specified
         */
        int pseudorandomFunction(const std::vector<unsigned char> &iv, int n, std::vector<unsigned char> &output);

        /**
         * shiftVectorRight
         *
         * Shifts a given vector to the right by a predetermined number of bytes
         *
         * @param[out]  shifted_vec Shifted vector
         * @param[in]   original_vec    Original vector to shift
         * @param[in]   shift_value Number of bytes to shift original vector by
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int shiftVectorRight(std::vector<unsigned char> &shifted_vec, std::vector<unsigned char> &original_vec, int shift_value);

        /**
         * xorVector
         *
         * Performs bitwise exclusive-OR operation between the two given vectors
         *
         * @param[in]   a       First vector to use for exclusive-OR operation
         * @param[in]   b       Second vector to use for exclusive-OR operation
         * @param[out]  result      Result of exclusive-OR operation
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Input vector sizes do not match
         */
        int xorVector(std::vector<unsigned char> &a, std::vector<unsigned char> &b, std::vector<unsigned char> &result);

        /**
         * base64Encode
         *
         * Encodes the given bytes to a base64 string
         *
         * @param[in]       s       Decoded bytes to encode
         *
         * @return      Encoded base64 string
         */
        std::string base64Encode(std::vector<unsigned char> const& s);

        /**
         * base64Decode
         *
         * Decodes the given base64 string to bytes
         *
         * @param[in]       s       Encoded base64 string to decode
         *
         * @return      Decoded bytes
         */
        std::vector<unsigned char> base64Decode(std::string const& s);

        /**
         * setAESPseudoRandomFunctionKey
         *
         * Sets the AES key used by the pseudorandom function
         *
         * @param[in]       crypto_attrib   Crypto attribute whose pseudo random function key is to be set (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return 0    SUCCESS
         * @return -1   FAILURE -- Pseudorandom function EVP_CIPHER_CTX context is NULL
         * @return -2   FAILURE -- Internal EVP_EncryptInit_ex() error encountered while attempting to set AES key for primary crypto pseudorandom function
         * @return -3   FAILURE -- Internal EVP_EncryptInit_ex() error encountered while attempting to set AES key for secondary crypto pseudorandom function
         * @return -4   FAILURE -- Invalid crypto attribute specified
         */
        int setAESPseudoRandomFunctionKey(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * AES_ctr128_increment
         *
         * Increments the given AES counter
         *
         * @param[in]       counter     AES counter to increment
         */
        void AES_ctr128_increment(unsigned char* counter);

        /**
         * AES_ctr128_pseudorandom_EVPencrypt
         *
         * Encrypts given input using AES 128-bit counter mode algorithm for pseudorandom function context
         *
         * @param[in]       in          Input plaintext
         * @param[out]      out         Output ciphertext
         * @param[in]       length      Input/output size
         * @param[in]       counter     Concatenated IV/counter array
         * @param[in]       ecount_buf  Encrypted IV/counter
         * @param[in]       num         Block byte offset
         *
         * @return 0    SUCCESS
         * @return -1   FAILURE -- Internal EVP_EncryptInit_ex() error encountered
         * @return -2   FAILURE -- Internal EVP_EncryptUpdate() error encountered
         * @return -3   FAILURE -- Invalid crypto attribute specified
         */
        int AES_ctr128_pseudorandom_EVPencrypt(const unsigned char* in,
                                               unsigned char* out,
                                               const unsigned long length,
                                               unsigned char counter[AES_BLOCK_SIZE],
                                               unsigned char ecount_buf[AES_BLOCK_SIZE],
                                               unsigned int* num);

    public:

        /**
         * resetCryptoContext
         *
         * Resets crypto context
         *
         * @param[in]       ssrc        SSRC ID
         * @param[in]       ipAddress   IP address
         * @param[in]       port        Port
         */
        void resetCryptoContext(unsigned int ssrc, std::string ipAddress, unsigned short port);

        /**
         * resetCipherState
         *
         * Checks the salting key a stream that takes the context starts
         * its AES counter mode encryption/decryption with
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Incorrect salting key length
         */
        int resetCipherState();

        /**
         * freeCiphers
         *
         * Frees the AES cipher context of the key derivation: every use of
         * a key sets it in one, and makes it first if there is none
         */
        void freeCiphers();

        /**
         * deriveSessionEncryptionKey
         *
         * Derives the session encryption key from the given master key / master salt
         *
         * @li Assumes the key derivation rate is ZERO
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Incorrect salting key length
         * @return  -2  FAILURE -- Incorrect encryption key length
         * @return  -3  FAILURE -- Could not set encryption key
         * @return  -4  FAILURE -- Invalid crypto attribute specified
         */
        int deriveSessionEncryptionKey();

        /**
         * deriveSessionSaltingKey
         *
         * Derives the session salting key from the given master key / master salt
         *
         * @li Assumes the key derivation rate is ZERO
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Incorrect salting key length
         * @return  -2  FAILURE -- Incorrect encryption key length
         * @return  -3  FAILURE -- Could not set encryption key
         * @return  -4  FAILURE -- Invalid crypto attribute specified
         */
        int deriveSessionSaltingKey();

        /**
         * deriveSessionAuthenticationKey
         *
         * Derives the session authentication key from the given master key / master salt
         *
         * @li Assumes the key derivation rate is ZERO
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Incorrect salting key length
         * @return  -2  FAILURE -- Incorrect encryption key length
         * @return  -3  FAILURE -- Could not set encryption key
         * @return  -4  FAILURE -- Invalid crypto attribute specified
         */
        int deriveSessionAuthenticationKey();

        /**
         * displaySessionEncryptionKey
         *
         * Displays the session encryption key
         */
        void displaySessionEncryptionKey();

        /**
         * displaySessionSaltingKey
         *
         * Displays the session salting key
         */
        void displaySessionSaltingKey();

        /**
         * displaySessionAuthenticationKey
         *
         * Displays the session authentication key
         */
        void displaySessionAuthenticationKey();

        /**
         * selectEncryptionKey
         *
         * Checks the session key used for encryption is one AES takes
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Empty session encryption key
         * @return  -2  FAILURE -- Could not set encryption key
         */
        int selectEncryptionKey();

        /**
         * selectDecryptionKey
         *
         * Checks the session key used for decryption is one AES takes
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Empty session encryption key
         * @return  -2  FAILURE -- Could not set encryption key
         */
        int selectDecryptionKey();

        /**
         * getCipherAlgorithm
         *
         * Gets the cipher algorithm currently in use
         *
         * @param[in]       crypto_attrib   Crypto attribute whose cipher algorithm is to be obtained (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  <cipher_algorithm>  Cipher algorithm currently in use (AES_CM_128, AES_CM_192, AES_CM_256 or NULL_CIPHER)
         */
        CipherType getCipherAlgorithm(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * selectCipherAlgorithm
         *
         * Selects the cipher algorithm to use
         *
         * @param[in]   cipherType  Cipher algorithm to use (AES_CM_128, AES_CM_192, AES_CM_256 or NULL_CIPHER)
         * @param[in]   crypto_attrib   Crypto attribute whose cipher algorithm is to be set (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Invalid cipher algorithm specified, or one the TLS library lacks
         * @return  -2  FAILURE -- Invalid crypto attribute specified
         */
        int selectCipherAlgorithm(CipherType cipherType, ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * getHashAlgorithm
         *
         * Gets the hashing algorithm currently in use
         *
         * @param[in]       crypto_attrib   Crypto attribute whose hash algorithm is to be obtained (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  <hash_algorithm>    Hashing algorithm currently in use (HMAC_SHA1_80 or HMAC_SHA1_32)
         */
        HashType getHashAlgorithm(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * selectHashAlgorithm
         *
         * Selects the hashing algorithm to use
         *
         * @param[in]   hashType    Hashing algorithm to use (HMAC_SHA1_80 or HMAC_SHA1_32)
         * @param[in]       crypto_attrib   Crypto attribute whose hash algorithm is to be set (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE -- Invalid HMAC algorithm specified
         * @return  -2  FAILURE -- Invalid crypto attribute specified
         */
        int selectHashAlgorithm(HashType hashType, ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * getAuthenticationTagSize
         *
         * Gets the authentication tag size
         *
         * @return  >0  SUCCESS -- Authentication tag size (bytes)
         * @return  -1  FAILURE -- Empty session authentication key
         * @return  -2  FAILURE -- Invalid HMAC algorithm specified
         * @return  -3  FAILURE -- Invalid crypto attribute specified
         */
        int getAuthenticationTagSize();

        /**
         * displayAuthenticationTag
         *
         * Displays the given authentication tag
         *
         * @param[in]   authtag     Authentication tag to display
         */
        void displayAuthenticationTag(std::vector<unsigned char> &authtag);

        /**
         * getSSRC
         *
         * Gets the SSRC currently in use
         *
         * @return  <ssrc>      SSRC ID currently in use
         */
        unsigned int getSSRC();

        /**
         * getIPAddress
         *
         * Gets the IP address currently in use
         *
         * @return  <ip_address>    IP address currently in use
         */
        std::string getIPAddress();

        /**
         * getPort
         *
         * Gets the port currently in use
         *
         * @return  <port>      Port currently in use
         */
        unsigned short getPort();

        /**
         * setSSRC
         *
         * Sets the SSRC currently in use
         *
         * @param[in]    ssrc       SSRC ID currently in use
         */
        void setSSRC(unsigned int ssrc);

        /**
         * setIPAddress
         *
         * Sets the IP address currently in use
         *
         * @param[in]    ipAddress  IP address currently in use
         */
        void setIPAddress(std::string ipAddress);

        /**
         * setPort
         *
         * Sets the port currently in use
         *
         * @param[in]    port       Port currently in use
         */
        void setPort(unsigned short port);

        /**
         * setID
         *
         * Sets the cryptographic context ID (<SSRC, IPAddress, Port>) to use
         *
         * @param[in]   id  Cryptographic context ID (<SSRC, IPAddress, Port>) to use
         */
        void setID(CryptoContextID id);

        /**
         * getSrtpHeaderSize
         *
         * Gets the current SRTP header size
         *
         * @return  <size>  Current SRTP header size in use
         */
        unsigned int getSrtpHeaderSize();

        /**
         * setSrtpHeaderSize
         *
         * Sets the current SRTP header size
         *
         * @param[in]   size    Current SRTP header size to use
         */
        void setSrtpHeaderSize(unsigned int size);

        /**
         * getSrtpPayloadSize
         *
         * Gets the current SRTP payload size
         *
         * @return  <size>  Current SRTP payload size in use
         */
        unsigned int getSrtpPayloadSize();

        /**
         * setSrtpPayloadSize
         *
         * Sets the current SRTP payload size
         *
         * @param[in]   size    Current SRTP payload size to use
         */
        void setSrtpPayloadSize(unsigned int size);

        /**
         * setCryptoTag
         *
         * Sets the crypto tag parameter value
         *
         * @param[in]       tag             Crypto tag value to use
         * @param[in]       crypto_attrib   Crypto attribute whose tag is to be set (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int setCryptoTag(unsigned int tag, ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * getCryptoTag
         *
         * Gets the crypto tag parameter value
         *
         * @param[in]       crypto_attrib   Crypto attribute whose tag is to be obtained (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  <crypto_tag>    Crypto tag value currently in use
         */
        unsigned int getCryptoTag(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO) const;

        /**
         * getCryptoSuite
         *
         * Fetches the string description of the crypto suite currently in use (e.g. "AES_CM_128_HMAC_SHA1_80" or "AES_CM_128_HMAC_SHA1_32")
         *
         * @param[in]       crypto_attrib   Crypto attribute whose suite is to be obtained (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  <cryptosuite_string>    String description of the crypto suite currently in use
         */
        std::string getCryptoSuite(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * setOfferedCryptoSuite
         *
         * Records the crypto suite as the peer's a=crypto line named it, which
         * getCryptoSuite() then returns: for an UNENCRYPTED_SRTP line the
         * cipher in use is NULL although the line names an AES_CM suite.
         *
         * @param[in]       suite           Crypto suite name from the SDP
         * @param[in]       crypto_attrib   PRIMARY_CRYPTO or SECONDARY_CRYPTO
         */
        void setOfferedCryptoSuite(const std::string& suite, ActiveCrypto crypto_attrib);

        /**
         * encodeMasterKeySalt
         *
         * Encodes the current unencoded master key/salt of the context for use in a RFC4568-compliant crypto attribute
         *
         * @param[out]  mks     Encoded master key/salt string (for use in an RFC-4568-compliant crypto attribute)
         * @param[in]   crypto_attrib   Crypto attribute whose master key/salt is to be encoded (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int encodeMasterKeySalt(std::string &mks, ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * decodeMasterKeySalt
         *
         * Decodes the given encoded master key/salt string from an RFC4568-compliant crypto attribute for use in the context
         *
         * @param[in]   mks     Encoded RFC4568-compliant master key/salt value (for use in the context)
         * @param[in]   crypto_attrib   Crypto attribute whose master key/salt is to be decoded (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         * @param[in]   keyLength       Master key length in bytes the suite takes (0 for any AES key length)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE (not a key of that length and a 14-byte salt)
         */
        int decodeMasterKeySalt(std::string &mks, ActiveCrypto crypto_attrib = ACTIVE_CRYPTO, size_t keyLength = 0);

        /**
         * displayCryptoContext
         *
         * Displays current CryptoContext
         */
        void displayCryptoContext();

        /**
         * dumpCryptoContext
         */
        std::string dumpCryptoContext();

        /**
         * generateMasterKey
         *
         * Generates a master key of the length the cipher algorithm takes (24 or
         * 32 bytes for AES_CM_192 or AES_CM_256, else 16)
         *
         * @param[in]   crypto_attrib   Crypto attribute whose master key is to be generated (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int generateMasterKey(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * generateMasterSalt
         *
         * Generates a master salt
         *
         * @param[in]   crypto_attrib   Crypto attribute whose master salt is to be generated (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int generateMasterSalt(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * getMasterKey
         *
         * Gets the MASTER KEY
         *
         * @param[in]   crypto_attrib   Crypto attribute whose master key is to be fetched (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  <master_key>        Master key
         */
        std::vector<unsigned char> getMasterKey(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * getMasterSalt
         *
         * Gets the MASTER SALT
         *
         * @param[in]   crypto_attrib   Crypto attribute whose master salt is to be fetched (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  <master_salt>       Master salt
         */
        std::vector<unsigned char> getMasterSalt(ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * setMasterKey
         *
         * Sets the MASTER KEY
         *
         * @param[in]   key     Master key to use
         * @param[in]   crypto_attrib   Crypto attribute whose master key is to be set (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int setMasterKey(std::vector<unsigned char> &key, ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * setMasterSalt
         *
         * Sets the MASTER SALT
         *
         * @param[in]   salt        Master salt to use
         * @param[in]   crypto_attrib   Crypto attribute whose master salt is to be set (PRIMARY_CRYPTO, SECONDARY_CRYPTO or ACTIVE_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int setMasterSalt(std::vector<unsigned char> &salt, ActiveCrypto crypto_attrib = ACTIVE_CRYPTO);

        /**
         * swapCrypto
         *
         * Swaps the PRIMARY and SECONDARY crypto attributes
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int swapCrypto();

        /**
         * selectActiveCrypto
         *
         * Selects the crypto attribute to use (PRIMARY or SECONDARY)
         *
         * @param[in]   activeCrypto    Crypto attribute to use (PRIMARY_CRYPTO or SECONDARY_CRYPTO)
         *
         * @return  0   SUCCESS
         * @return  -1  FAILURE
         */
        int selectActiveCrypto(ActiveCrypto activeCrypto);

        /**
         * getActiveCrypto
         *
         * Gets the crypto attribute currently in use (PRIMARY or SECONDARY)
         *
         * @return  PRIMARY_CRYPTO      Primary crypto attribute is currently in use
         * @return  SECONDARY_CRYPTO    Secondary crypto attribute is currently in use
         * @return  INVALID_CRYPTO      Internal error occurred
         */
        ActiveCrypto getActiveCrypto();

        /**
         * operator=
         *
         * Assigns a given JLSRTP object to the implicit one
         *
         * @param[in]   that        JLSRTP object to assign to the implicit one
         *
         * @return  <JLSRTP_reference>  Reference to the implicit JLSRTP object
         */
        JLSRTP& operator=(const JLSRTP& that);

        /**
         * operator==
         *
         * Compares a given JLSRTP object to the implicit one for equality
         *
         * @param[in]   that        JLSRTP object to compare to the implicit one for equality
         *
         * @return  TRUE    Given JLSRTP object is equal to the implicit one
         * @return  FALSE   Given JLSRTP object is NOT equal to the implicit one
         */
        bool operator==(const JLSRTP& that);

        /**
         * operator!=
         *
         * Compares a given JLSRTP object to the implicit one for inequality
         *
         * @param[in]   that        JLSRTP object to compare to the implicit one for inequality
         *
         * @return  TRUE    Given JLSRTP object is inequal to the implicit one
         * @return  FALSE   Given JLSRTP object is NOT inequal to the implicit one
         */
        bool operator!=(const JLSRTP& that);

        /**
         * JLSTRP
         *
         * Default constructor
         */
        JLSRTP();

        /**
         * JLSRTP
         *
         * Custom constructor
         *
         * @param[in]       ssrc        SSRC ID
         * @param[in]       ipAddress   IP address
         * @param[in]       port        Port
         */
        JLSRTP(unsigned int ssrc, const std::string& ipAddress, unsigned short port);

        /**
         * ~JLSRTP
         *
         * Default destructor
         */
        ~JLSRTP();

        /* takes the session keys of the active crypto */
        friend class SrtpStream;
#ifdef GTEST
        friend class JLSRTPTest;
#endif
};

#else // !USE_OPENSSL && !USE_WOLFSSL

class JLSRTP
{
    public:

        /**
         * JLSTRP
         *
         * Default constructor
         */
        JLSRTP();

        /**
         * JLSRTP
         *
         * Custom constructor
         *
         * @param[in]       ssrc        SSRC ID
         * @param[in]       ipAddress   IP address
         * @param[in]       port        Port
         */
        JLSRTP(unsigned int ssrc, const std::string& ipAddress, unsigned short port);

        /**
         * ~JLSRTP
         *
         * Default destructor
         */
        ~JLSRTP();
};

#endif // USE_OPENSSL || USE_WOLFSSL

#endif // __JLSRTP__

