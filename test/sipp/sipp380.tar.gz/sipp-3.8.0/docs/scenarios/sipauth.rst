SIP authentication
``````````````````

SIPp supports SIP authentication. These authentication algorithms are
supported: Digest/MD5 ("algorithm="MD5""), Digest/SHA-256
("algorithm="SHA-256"") and Digest/SHA-512-256
("algorithm="SHA-512-256""), each also as a session variant
("MD5-sess", "SHA-256-sess" and "SHA-512-256-sess", RFC 7616 and RFC
8760), and Digest/AKA ("algorithm="AKAv1-MD5"", as specified by 3GPP
for IMS). A session variant needs a qop in the challenge, as its
response is of the cnonce. SHA-512-256 needs an SSL library with
SHA-512/256: OpenSSL has it, and wolfSSL unless built without it.
The algorithm is echoed as the challenge has it.

Enabling authentication is simple. When receiving a 401 (Unauthorized)
or a 407 (Proxy Authentication Required), you must add auth="true" in
the <recv> command to take the challenge into account. Then, the
authorization header can be re-injected in the next message by using
[authentication] keyword. Of several challenges, the first Digest one
with a supported algorithm is answered (a session variant only with a
qop).

Computing the authorization header is done through the usage of the
"[authentication]" keyword. Depending on the algorithm (AKAv1-MD5 or
another), different parameters must be passed next to the
authentication keyword:


+ Digest/MD5, Digest/SHA-256 and Digest/SHA-512-256, and their session
  variants (example: [authentication username=joe password=schmo])

    + username : username: if no username is specified, the username is
      taken from the '-au' (authentication username) or '-s' (service)
      command line parameter
    + password : password: if no password is specified, the password is
      taken from the '-ap' (authentication password) command line parameter

+ Digest/AKA: (example: [authentication username=HappyFeet
  aka_OP=0xCDC202D5123E20F62B6D676AC72CB318
  aka_K=0x465B5CE8B199B49FAA5F0A2EE238A6BC])

    + username : username: if no username is specified, the username is
      taken from the '-au' (authentication username) or '-s' (service)
      command line parameter
    + aka_K : Permanent secret key. If no aka_K is provided, the
      "password" attributed is used as aka_K.
    + aka_OP : OPerator variant key
    + aka_AMF : ignored: the Authentication Management Field is the one
      in the challenge's AUTN, as a USIM uses it

A value can also be a keyword, such as
[authentication username=[field0] password=[field1]].


In case you want to use authentication with a different
username/password or aka_K for each call, you can do this:


+ Make a CSV like this::

    SEQUENTIAL
    User0001;[authentication username=joe password=schmo]
    User0002;[authentication username=john password=smith]
    User0003;[authentication username=betty password=boop]


+ And an XML like this (the [field1] will be substituted with the full
  auth string, which is the processed as a new keyword)::

    <send retrans="500">
      <![CDATA[

        REGISTER sip:[remote_ip] SIP/2.0
        Via: SIP/2.0/[transport] [local_ip]:[local_port]
        To: <sip:[field0]@sip.com:[remote_port]>
        From: <sip:[field0]@[remote_ip]:[remote_port]>
        Contact: <sip:[field0]@[local_ip]:[local_port]>;transport=[transport]
        [field1]
        Expires: 300
        Call-ID: [call_id]
        CSeq: 2 REGISTER
        Content-Length: 0

      ]]>
    </send>



Example::

    <recv response="407" auth="true">
    </recv>

    <send>
      <![CDATA[

        ACK sip:[service]@[remote_ip]:[remote_port] SIP/2.0
        Via: SIP/2.0/[transport] [local_ip]:[local_port]
        From: sipp <sip:sipp@[local_ip]:[local_port]>;tag=[call_number]
        To: sut <sip:[service]@[remote_ip]:[remote_port]>[peer_tag_param]
        Call-ID: [call_id]
        CSeq: 1 ACK
        Contact: sip:sipp@[local_ip]:[local_port]
        Max-Forwards: 70
        Subject: Performance Test
        Content-Length: 0

      ]]>
    </send>

    <send retrans="500">
      <![CDATA[

        INVITE sip:[service]@[remote_ip]:[remote_port] SIP/2.0
        Via: SIP/2.0/[transport] [local_ip]:[local_port]
        From: sipp <sip:sipp@[local_ip]:[local_port]>;tag=[call_number]
        To: sut <sip:[service]@[remote_ip]:[remote_port]>
        Call-ID: [call_id]
        CSeq: 2 INVITE
        Contact: sip:sipp@[local_ip]:[local_port]
        [authentication username=foouser]
        Max-Forwards: 70
        Subject: Performance Test
        Content-Type: application/sdp
        Content-Length: [len]

        v=0
        o=user1 53655765 2353687637 IN IP[media_ip_type] [media_ip]
        s=-
        t=0 0
        c=IN IP[media_ip_type] [media_ip]
        m=audio [media_port] RTP/AVP 0
        a=rtpmap:0 PCMU/8000

      ]]>
    </send>
